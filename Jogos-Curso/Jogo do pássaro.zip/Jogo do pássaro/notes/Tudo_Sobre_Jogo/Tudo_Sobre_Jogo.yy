{
  "resourceType": "GMNotes",
  "resourceVersion": "1.1",
  "name": "Tudo_Sobre_Jogo",
  "parent": {
    "name": "Notes",
    "path": "folders/Notes.yy",
  },
}