/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(!global.Trancicao){	
	//Coletaveis coletados
	draw_text(20, 45, global.Colecionaveis_Totais);

	//Sprite na tela
	draw_sprite(spr_Colecionavel, 0, 30, 40);
}