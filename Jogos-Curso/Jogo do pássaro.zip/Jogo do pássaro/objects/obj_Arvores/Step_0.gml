/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Velocidade da arvore horizontal
hspeed = global.Velocidade_Arvore;

//Destruindo objeto.
if(x < -50){
	instance_destroy();
}

//Se a variável perdeu for true a velocidade da arvore vai ser zerada.
if(global.Perdeu){
	hspeed = 0;
}