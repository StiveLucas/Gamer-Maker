/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


//Velocidade Animação
image_speed = 0.1