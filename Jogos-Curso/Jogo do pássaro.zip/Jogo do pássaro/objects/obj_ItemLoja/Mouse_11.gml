/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


if(global.itensLoja[index_Item]){
	image_speed = 0;
}else{
	image_speed = 0.1;
}