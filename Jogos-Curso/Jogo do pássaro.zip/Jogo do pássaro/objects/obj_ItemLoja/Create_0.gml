/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definindo sprite.
sprite_index = sprite;
if(Bloqueado){
	image_speed = 0;
}else{
	image_speed = 0.2;
}