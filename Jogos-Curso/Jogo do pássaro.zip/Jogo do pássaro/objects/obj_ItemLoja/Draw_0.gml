/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_sprite_ext(spr_PainelFundo, Bloqueado, x, y, 2.5, 2.5, 0, c_white, 1);

//Fazendo tudo aparecer
draw_self();

if(Bloqueado){
	//Valores dos personagens.
	draw_text(x - 5, y + 50, Custo);
	
	//Desenho da sprite
	draw_sprite(spr_Colecionavel, 0, x - 70, y + 45);
}

