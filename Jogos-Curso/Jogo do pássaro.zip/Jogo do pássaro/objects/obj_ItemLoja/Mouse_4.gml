/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Desbloqueando Personagem
if(Bloqueado && global.Colecionaveis_Totais >= Custo){
	Bloqueado = false;
	global.itensLoja[index_Item] = false
	global.Colecionaveis_Totais -= Custo;
	Custo =  0;
	
	//Definindo sprite
	global.Sprite_Player = sprite;
}