 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Fazendo o spawm das arvores
alarm[0] = 60;
//Fazendo spawm das aguias 
alarm[1] = 160;
//Fazendo spawm do  Coletavel
alarm[2] = 60 * 3;

casa_array = 0;

//Definindo velocidade do fundo.
vel_fundo = -1