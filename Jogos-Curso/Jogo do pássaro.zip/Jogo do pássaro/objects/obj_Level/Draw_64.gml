/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definindo fonte
draw_set_font(fnt_Pontos);

//Escreve na tela os pontos.
draw_text(xstart, ystart, "Pontuação: "+string(pontos)+ "\nproximo level: "+string(global.Levels[casa_array]));

//Escreve na tela o level que está.
draw_sprite(spr_level, casa_array + 1, 640/2, 360/4);

//Mostra o total de colecionaveis coletados e o desenho ao lado.
draw_text(20, 75, global.Colecionaveis)
draw_sprite(spr_Colecionavel, 0, 25, 70)

//Resetando Fonte
draw_set_font(-1);