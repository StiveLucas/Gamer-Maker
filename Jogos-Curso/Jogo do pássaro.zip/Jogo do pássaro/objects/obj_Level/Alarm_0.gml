  /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Posição y determinada pela variável.
posicaoY_Arvore = irandom_range(300, 350);

//Gera obstaculos automaticamente.
instance_create_layer(640, posicaoY_Arvore, "ins_Obstaculo", obj_Arvores);

//O Randao_range escolhe numeros aleatorios entre o menor e o maior digitado
alarm[0] = game_get_speed(gamespeed_fps) * random_range(2, 5);