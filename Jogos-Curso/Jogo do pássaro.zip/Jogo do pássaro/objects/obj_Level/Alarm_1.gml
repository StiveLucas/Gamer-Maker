/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Posição da Aguia determinada pela variavel. 
posicaoY_Aguia = irandom_range(-6, 6); 

//Gera obstaculos definido automaticamente
instance_create_layer(690, posicaoY_Aguia, "ins_Obstaculo", obj_Inimigo);

alarm[1] = 60 * random_range(7, 10)
