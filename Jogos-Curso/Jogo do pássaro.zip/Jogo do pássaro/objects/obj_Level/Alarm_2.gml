  /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
posicaoY_Coletavel = irandom_range(80, 175);

instance_create_layer(650, posicaoY_Coletavel, "ins_Coletaveis", obj_Colecionavel);

alarm[2] = 60 * irandom_range(6, 12) ;