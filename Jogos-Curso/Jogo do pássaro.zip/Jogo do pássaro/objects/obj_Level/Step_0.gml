/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Verifica se o player perdeu.
if(!global.Perdeu){
	global.Ponto += 0.2;
}

//Arredonda os pontos.
pontos = round(global.Ponto);

//Passando os niveis e aumentando a velocidade de tudo.
if(!global.Perdeu){
	if(pontos >= global.Levels[casa_array] && casa_array <=7){
		casa_array++;
		//Aumentando a velocidade dos obstaculos.
		global.Velocidade_Aguia += -1;
		global.Velocidade_Arvore += -1;
	
		//Aumentando velocidade do fundo
		vel_fundo -= 0.5;
	}
	
}else{
	vel_fundo = 0;
}

//Velocidade do fundo
layer_hspeed("bg_Arvores", vel_fundo);