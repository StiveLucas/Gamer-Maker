/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destruindo objeto.
if(x < -10){
	instance_destroy()
}

//Velocidade do inimigo
if(!global.Perdeu){
	hspeed = global.Velocidade_Aguia;
	image_xscale = -1;
	image_speed = 0.1;
}else{
	hspeed = 0
	image_speed = 0;
}