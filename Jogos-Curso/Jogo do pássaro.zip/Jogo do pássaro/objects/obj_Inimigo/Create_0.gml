/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Controlando sprites
image_speed = 0;
image_index = 0;