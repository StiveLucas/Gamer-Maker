/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Use pra verificar se está sendo destroido.
//show_debug_message("Morri")