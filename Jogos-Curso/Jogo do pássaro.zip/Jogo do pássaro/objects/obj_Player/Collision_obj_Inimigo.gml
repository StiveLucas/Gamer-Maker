/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

gamer_over();

alarm[0] = 120;