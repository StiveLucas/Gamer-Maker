/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Zerando a velocidade do sprite quando zerar a animação.
image_speed = 0;