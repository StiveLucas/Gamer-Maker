/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Sprite do player.
sprite_index = global.Sprite_Player

//Vouo do player para cima
global.Voar_Player = -5;

//Controlando a sprite do player;
image_speed = 0;
image_index = 0;

//Gravidade para puxar pra baixo.
gravity = 0.1