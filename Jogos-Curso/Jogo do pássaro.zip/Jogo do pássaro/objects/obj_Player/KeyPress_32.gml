/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(image_index < 1){
	image_speed = 1.5;
	image_index = 1;
}

vspeed = global.Voar_Player;