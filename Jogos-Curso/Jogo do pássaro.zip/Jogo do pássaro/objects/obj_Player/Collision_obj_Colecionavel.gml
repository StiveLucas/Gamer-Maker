/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Adicinar mais um na conta.
global.Colecionaveis++;

audio_play_sound(snd_pegouCole, 50, 0);

instance_destroy(other);