/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(global.Perdeu){
	image_angle += 2;
}