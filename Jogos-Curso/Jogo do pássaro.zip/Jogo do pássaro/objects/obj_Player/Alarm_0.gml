/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Quando reinicia o game torna o perdeu false e reseta o jogo
global.Perdeu = false;
global.Ponto = 0;
global.Colecionaveis = 0;
global.Velocidade_Aguia = -2;
global.Velocidade_Arvore = -2;
game_restart()