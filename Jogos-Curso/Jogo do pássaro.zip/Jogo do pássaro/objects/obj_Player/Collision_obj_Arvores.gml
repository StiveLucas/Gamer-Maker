/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Função de derrotay
gamer_over();

alarm[0] = 120;