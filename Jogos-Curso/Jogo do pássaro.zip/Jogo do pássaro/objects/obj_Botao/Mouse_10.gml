/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deformando imagem para causar efeito
image_xscale = escala_x * 1.2;
image_yscale = escala_y * 1.2;

escala_xText = 1.5;
escala_yText = 1.5;