 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Desenhando botão
draw_self();

//Centralizando no objeto
draw_set_halign(1);
draw_set_valign(1);

//fonte e cor da palavra
draw_set_font(font_Texto);
draw_set_color(cor_texto);

//Texto do botão
//draw_text(x, y, txt_botao);
draw_text_transformed(x, y, txt_botao, escala_xText, escala_yText, 0);

//Zerando os Draw
draw_set_halign(-1);
draw_set_valign(-1);
draw_set_font(-1);
draw_set_color(-1);