/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Fazendo a escala volatr ao normal definido nas escalas.
image_xscale = lerp(image_xscale, escala_x, 0.1);
image_yscale = lerp(image_yscale, escala_y, 0.1);

escala_xText = lerp(escala_xText, 1, 0.1);
escala_yText = lerp(escala_yText, 1, 0.1);