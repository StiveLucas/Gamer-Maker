/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deformando imagem para causar efeito
image_xscale = escala_x * 0.7;
image_yscale = escala_y * 0.8;

//Deformando Texto para causar efeito.
escala_xText = 1.4
escala_yText = 1.4

//Definindo Situação
global.Perdeu = false;

if(global.Trancicao == false){
	layer_sequence_create("ass_Transicoes", 0, 0, sq_trancisaoInicio);

	room_goto(destino_btn);
	
	global.Trancicao = true;
}