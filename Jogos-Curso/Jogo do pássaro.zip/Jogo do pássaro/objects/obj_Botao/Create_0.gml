/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definindo escalas da imagem 
escala_x = image_xscale;
escala_y = image_yscale;

escala_xText = 1
escala_yText = 1