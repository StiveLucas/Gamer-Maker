/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(global.ItemComprado){
	image_index = 1;
}