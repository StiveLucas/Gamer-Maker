 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


image_xscale += 0.1;
image_yscale = image_xscale;

image_alpha = lerp(image_alpha, 0, 0.1);

if(x <= -30){
	instance_destroy();
	exit;
}
if(image_alpha <= 0.1){	
	instance_destroy();
}