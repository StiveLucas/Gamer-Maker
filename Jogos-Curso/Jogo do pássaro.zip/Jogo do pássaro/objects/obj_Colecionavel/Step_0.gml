/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(!global.Perdeu){
	vel_x = -1;
	hspeed = vel_x;
}else{
	vel_x = 0;
	hspeed = vel_x;
}

if(x <= -150){
	instance_destroy();
}