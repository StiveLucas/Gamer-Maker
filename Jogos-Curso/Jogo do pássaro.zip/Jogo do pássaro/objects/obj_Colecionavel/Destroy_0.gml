/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

instance_create_layer(x, y, "ins_Coletaveis", obj_efeitoColecionavel);

show_debug_message("Peixeee")