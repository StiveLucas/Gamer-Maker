//Efeito de Transição.
layer_sequence_create("ass_Transicao", 0, 0, sq_trancisaoFinal);