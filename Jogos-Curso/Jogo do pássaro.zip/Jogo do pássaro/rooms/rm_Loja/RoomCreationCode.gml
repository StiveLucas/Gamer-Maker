//Efeito da transição.
layer_sequence_create("ass_Transicoes", 0, 0, sq_trancisaoFinal);