// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Variáveis Globais.

//Iniciando debug pra ver o fps
show_debug_overlay(true)

//Sprite do player.
global.Sprite_Player = spr_Player

//Player
global.Voar_Player = 0;

//Derrota
global.Perdeu = false

//Inimigos
//Velocidae dos inimigos
global.Velocidade_Aguia = -2;
global.Velocidade_Arvore = -2;

//Pontos.
global.Ponto = 0;

//Colecionaveis.
global.Colecionaveis = 0;
global.Colecionaveis_Totais = 30;

//Leveis.
global.Levels = [100, 200, 300, 400, 500, 600, 700, 800, 900];

//Loja
global.Animacao_Loja = false;

//Itens da loja.
global.itensLoja = [false, true, true];