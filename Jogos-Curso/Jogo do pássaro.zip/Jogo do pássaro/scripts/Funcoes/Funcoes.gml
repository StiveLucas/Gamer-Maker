// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Função quando perde.
function gamer_over(){
	global.Perdeu = true;
	
	layer_hspeed("bg_Arvores", 0);
	
	vspeed = -2;
	hspeed = -1
	
	//Player
	global.Voar_Player = 0;

	//Inimigos
	//Velocidae dos inimigos
	global.Velocidade_Aguia = -2;
	global.Velocidade_Arvore = -2;

	//Pontos.
	global.Ponto = 0;

	//Colecionaveis.
	global.Colecionaveis_Totais += global.Colecionaveis;
	global.Colecionaveis = 0;

	//Leveis.
	global.Levels = [100, 200, 300, 400, 500, 600, 700, 800, 900];
	
	
	layer_sequence_create("ass_Transicao", 0, 0, sq_trancisaoInicio);
	
}

function JogarGame(){
	if(global.Perdeu){
		room_goto(rm_TelaInicial);
	}else{
		room_goto(rm_Jogo)
	}
	
}

function Fim_Trancicao(){
	global.Trancicao = false;
}
