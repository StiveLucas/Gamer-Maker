{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "Tarncicoes",
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
}