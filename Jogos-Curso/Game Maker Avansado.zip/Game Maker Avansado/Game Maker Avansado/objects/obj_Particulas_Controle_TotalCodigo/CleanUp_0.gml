//Sempre Limpe a particula para não acumular lixo no jogo.

//Limpando Particula.
part_type_destroy(Particula_Propria);

//Limpando o emiter.
part_emitter_destroy(global.Sistema_Particula, Emisor_Particulas);

//Limpando o Sistema de Particulas.
part_system_destroy(global.Sistema_Particula);