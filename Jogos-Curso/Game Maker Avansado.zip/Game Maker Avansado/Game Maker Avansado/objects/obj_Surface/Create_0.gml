
//Surface é tipo um superfície para poder desenhar, ao invés de criar objetos para fazer efeitos de
//sangue ou outros, ocupandando a memória da máquina, use a surface.

//Criando minha Surface
Surf = surface_create(room_width, room_height);

Desenha_Surface = function(){
    
    //Sempre que for mecher na Surface verifique se ela existe.
    if (!surface_exists(Surf)) {
    	
        //Crio a Surface.
        Surf = surface_create(room_width, room_height);
        
        //Definindo o algo da Surface.
        surface_set_target(Surf);
        
        //Limpando a Surface.
        draw_clear_alpha(c_black, 0);
        
        //Resetando o meu alvo (Volta a ver o alvo corretamente).
        surface_reset_target();
        
    }else {
    	draw_surface(Surf, 0, 0);
    }
}

Desenhando_Na_Surface = function(){
    
    var _Mouse_Clik = mouse_check_button_pressed(mb_left);
    
    if (_Mouse_Clik) {
    	
        //Desenhando na Surface.
        if (surface_exists(Surf)) {
        	surface_set_target(Surf);
            draw_set_colour(c_red);
            
            //Desenhando uma bolinha vermelha.
            draw_circle(mouse_x, mouse_y, 20, false);
            
            draw_set_colour(c_white);
            
            //Reseta o algo.
            surface_reset_target();
        }
    }
}

//Criando um efeito de sangue usando Surface.
Efeito_Sangue = function(){
    
    if (surface_exists(Surf)) {
    	surface_set_target(Surf);
        
        var _Mouse_Click = mouse_check_button_pressed(mb_left);
        
        if (_Mouse_Click) {
            repeat (irandom_range(5, 45)) {
                var _Sangue = instance_create_depth(mouse_x, mouse_y, 0, obj_Sangue);
                _Sangue.direction = irandom(359);
                _Sangue.image_blend = c_red;	
            }
        }
        
        //Reseta o algo.
        surface_reset_target();
    }
}