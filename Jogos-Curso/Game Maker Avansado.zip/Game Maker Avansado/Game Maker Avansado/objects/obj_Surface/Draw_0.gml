Desenha_Surface();
//Desenhando_Na_Surface();
Efeito_Sangue();