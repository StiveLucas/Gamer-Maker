
if (keyboard_check_pressed(vk_enter)) Salvar_Nome();

if (keyboard_check_pressed(vk_up)) Carrega_Nome();
