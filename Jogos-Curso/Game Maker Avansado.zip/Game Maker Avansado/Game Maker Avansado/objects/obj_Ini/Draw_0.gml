//Exibindo nome salvo.
draw_text(0 + 50, 0 + 50, Nome);