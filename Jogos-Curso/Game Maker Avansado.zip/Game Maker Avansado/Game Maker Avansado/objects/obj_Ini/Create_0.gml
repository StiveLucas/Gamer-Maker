

Nome = "";
// INI é um otimo arquivo para salvar pequenos dados do jogo.
//Em geral, podemos salvar valores como string ou reais(numeros).

// 1. Abrimos o arquivo INI, se o arquivo não existe ele cria o arquivo com o nome dado.
// ini_open("<Nome do arquivo>");
ini_open("Savi.ini");

// 2. Salvando dados. Temos duas maneiras de salvar, em String e Real. Escolha dependendo do que irá salvar.
//ini_write_string("<Titulo ou nome que desejar>", "<Nome do que está guardando>", "<Valor em String>");
ini_write_string("Player", "Nome", "Goku");

//ini_write_real("<Titulo ou nome que desejar>", "<Nome do que está guardando>", "<Valor em Real>");
ini_write_real("Idade", "Goku", 43);

//3. Fechamos o arquivo depois de salvar tudo. Nunca esqueca de fechar.
ini_close();

//Podemos criar funcões.
Salvar_Nome = function(){
    
    //Essa funcao get_string é apenas para teste, não use ela em projetos finais
    Nome = get_string("Digite seu nome: ", "");
    
    ini_open("SaveNome.ini");
    
    ini_write_string("Player", "Nome", Nome);
    
    ini_close();
}

// 4. Lendo Dados Salvos
//Para isso, temos duas maneiras de ler os dados, em String e Real. Escolha dependendo do que irá ler.

//Use para localizar dados em String - ini_read_string(<Nome do Titulo ou nome que colocou>, <Nome do que está procurando>, <Mensagem que irá exibir caso não encontrar>);
//ini_read_string("Player", "Nome", "Valor não encontrado.");

//Use para localizar dados em Real - ini_read_real(<Nome do Titulo ou nome que colocou>, <Nome do que está procurando>, <Número que irá exibir caso não encontrar>);
//ini_read_real("Player", "Nome", 0);

//Funcão de exemplo.
Carrega_Nome = function(){
    
    ini_open("SaveNome.ini");
    
    Nome = ini_read_string("Player", "Nome", "Nome não encontrado.");
    
    ini_close();
}