{
  "$GMNotes":"v1",
  "%Name":"Level 1",
  "name":"Level 1",
  "parent":{
    "name":"Função no Draw",
    "path":"folders/Documentações/Função no Draw.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}