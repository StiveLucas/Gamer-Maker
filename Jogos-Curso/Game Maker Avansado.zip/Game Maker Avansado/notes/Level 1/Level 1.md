OBS: Essas funções normalmente é usada no draw, mas talvez você possa usar algumas dela fora.

draw_text_ext()

    Com essa função você consegue controlar mais ainda seus textos, definindo altura entre os textos e distancia entre 
    as palavras.

    Formula:

        draw_text_ext(<Posição x>, <Posição y>, <Texto>, <Espaçamento vertical>, <Espaçamento horizontal>);


string_height()

    Essa função você consegue definir ou pegar a altura do seu texto.

    Formula:

        var _AturaTexto = string_height(<Você pode usar a variável que guarda seu texto ou usar uma letra Maiuscula para definir>);


string_copy()

    Com essa função você pode fazer um efeito de máquina de escrever com o seu texto, ele usa um contador para colocar
    os caracteres.

    Formula:

                                            TABELA DE INSTRUÇÕES DE PREENCHIMENTO

        Seu texto - Coloque seu texto.

        Caracter inicial - De qual Caracter ele vai começar(colo um número para determinar)

        Caracteres - Aqui você coloca a quantidade de Caracter que ele vai escrever.(obs: você pode pegar a quantidade de
                    caracter usando string_length()).

        var _MeuTexto = string_copy(<Seu texto>, <Caracter inicial>, <Caracteres>)