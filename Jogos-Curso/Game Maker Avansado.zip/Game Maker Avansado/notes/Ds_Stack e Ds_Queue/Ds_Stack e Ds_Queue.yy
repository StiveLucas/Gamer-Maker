{
  "$GMNotes":"v1",
  "%Name":"Ds_Stack e Ds_Queue",
  "name":"Ds_Stack e Ds_Queue",
  "parent":{
    "name":"Estruturas de Dados",
    "path":"folders/Documentações/Estruturas de Dados.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}