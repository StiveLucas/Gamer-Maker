
Obs: Isso são estruturas de dados, lembrese de deletalas no Clean UP.

Ds Stack e Ds Queue

    Ambos os ds fazem as mesmo a coisa, a diferença é a ordem. Veja o documento inteiro para entender por completo.

Ds Stack

    Também conhecido como Pilha, porque o último dado a entrar vai ser o primeiro dado a sair. Para entender 
    melhor pense em uma pilha de pratos, quando você for lavar a pilha você vai começar pelo topo da pilha no caso o 
    último a ser colocado.

    Ds_stack_create()

        Primeiro vamos criar nossa Pilha para poder usar.

        Formula:

            //Criando minha pilha.
            <Variável> = ds_stack_create();


    Ds_stack_push()

        Com essa função adcionamos valores a Pilha.
        
        OBS:Você pode salvar o dado salva em uma variável se quiser.

        Formula:

            ds_stack_push(<Sua Pilha>, <Valor1>, <Valor2>, <Valor3>, ...);
    

    Ds_stack_pop()
    
        Com essa função você remove o último dado sua Pilha(seu ds_stack).
        
        Formula:
        
            //Removendo o ultimo dado adcionado na  Pilha.
            <Variável> = ds_stack_pop(<sua Pilha>);
            
            Aqui você está removendo da Pilha e guardando o dado removido em uma variável.
            
            Obs: Se quiser você pode apenas remover o dado sem colocá-lo em uma variável você pode.
            

Ds Queue

    Também conhecido como Fila, porque o primeiro dado que entrou vai ser o primeiro a sair. Para entender 
    melhor pense em uma fila de banco ou supermercado, o primeiro que for ao caixa vai ser o primeiro a sair.

    Ds_queue_create()

        Primeiro vamos criar nossa Fila.

        Formula:

            //Criando minha Fila.
            <Variável> = ds_queue_create();


    Ds_queue_enqueue()

        Com essa função adcionamos valores a Fila.

        OBS:Você pode salvar o dado salva em uma variável se quiser.

        Formula:

            ds_queue_enqueue(<Sua Fila>, <Valor1>, <Valor2>, <Valor3>, ...);


    Ds_queue_dequeue()
    
        Com essa função você remove o primeiro dado adcionado da sua Fila.

        Formula:

        <Variável> = ds_queue_dequeue(<Sua Fila>);

        Aqui você está removendo da Fila e guardando o dado removido em uma variável.

        Obs: Se quiser você pode apenas remover o dado sem colocá-lo em uma variável você pode.


Destruindo o Ds Stack e o Ds Queue

    Quando você não precisar mais dos Ds lembre-se de destruilos para não ocupar espaço na memória do PC.

    OBS: Use a função dentro de um Clean UP, normalmente é executado lá, e Coloque uma condição
    para a função rodar.

    Formula do Ds Stack:

        ds_stack_destroy(<Sua Pilha>);

    Formula do Ds Queue:

        ds_queue_destroy(<Sua Fila>);