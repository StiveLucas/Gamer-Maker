
Obs: Isso são estruturas de dados, lembrese de deletalas no Clean UP.

DS Grid

    É um vetor 2D com mais recursos

    Ds_grid_create()

        Primeiro criamos nossa Grid. Para criar nossa grid precisamos saber quantas colunas e linhas nossa room
        possue. Para saber isso, modifique sua o tamnho da sua room pra ser divisivel por um tamnho que não entregue
        números quebrados.

        Formula:

            //Descobrindo quantas colunas e linhas eu tenho.
            TamanhoCelula = 48; 
            Colunas = room_width div TamanhoCelula;
            Linhas = room_height div TamanhoCelula;

            <Variável> = ds_grid_create(Colunas, Linhas);