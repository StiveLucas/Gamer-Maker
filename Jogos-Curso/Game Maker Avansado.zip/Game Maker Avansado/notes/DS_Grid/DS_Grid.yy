{
  "$GMNotes":"v1",
  "%Name":"DS_Grid",
  "name":"DS_Grid",
  "parent":{
    "name":"Estruturas de Dados",
    "path":"folders/Documentações/Estruturas de Dados.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}