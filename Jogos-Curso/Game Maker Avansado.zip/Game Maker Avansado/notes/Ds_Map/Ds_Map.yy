{
  "$GMNotes":"v1",
  "%Name":"Ds_Map",
  "name":"Ds_Map",
  "parent":{
    "name":"Estruturas de Dados",
    "path":"folders/Documentações/Estruturas de Dados.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}