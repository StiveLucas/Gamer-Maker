
Static
    
    Com essa função você pode fazer uma variável ou função ser chamada apenas uma vez dentro de 
    uma função, ou local(Step, Draw).

    Formula:

            static <Variável> = <Valor da variável>;

            //Se for uma função.
            static <Nome da função> = function(){
                //Bloco de codigo.
            }