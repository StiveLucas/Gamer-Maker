{
  "$GMNotes":"v1",
  "%Name":"Static",
  "name":"Static",
  "parent":{
    "name":"Funções no GameMaker",
    "path":"folders/Documentações/Funções no GameMaker.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}