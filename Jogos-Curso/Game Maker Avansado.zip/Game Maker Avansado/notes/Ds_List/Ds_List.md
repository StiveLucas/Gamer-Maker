
Obs: Isso são estruturas de dados, lembrese de deletalas no Clean UP.

Estrutura de Dados

Data Structure

    Também conhecido como DS, É um vetor 1d com funcionalidades a mais. Para começar temos que criar a nossa lista.


Ds_list_create()

    Aqui definimos/criamos nossa lista.

    Formula:

        <Variável> = ds_list_create()

    Com a lista ds_list criada, podemos usar uma series de funções.

Ds_list_add()

    Aqui podemos adcionar valores na nossa lista. Existe duas formas.

    Primeira forma, você pode adcionar vários valores na lista de uma vez só.

      Formula:
  
          ds_list_add(<ListaCriada>, <Valor1>, <Valor2>, <Valor3>, ...);

    Segunda forma, você pode usar essa forma para adcionar um novo valor ou substituir o valor que já esta na sua lista.

        Formula:

            <ListaCriada>[| <Indece que você quer Adcionar/Substituir>] = <NovoValor>;

            OBS: O indice começa sempre no 0.


Acesando ds_lists

    Para acessar os valores da lista use:

    Formula:

        <ListaCriada>[| <indice do valor>];


Ds_list_delete()

    Com essa função você pode deletar os valores dentro da lista.

    Formula:

        ds_list_delete(<ListaCriada>, <Indice do valor que vai deletar>);


Destruindo o Ds Stack e o Ds Queue

    Quando você não precisar mais do Ds_list lembre-se de destruilo para não ocupar espaço na memória do PC.

    OBS: Use a função dentro de um Clean UP, normalmente é executado lá.

    Formula:

        ds_list_destroy(<ListaCriada>);

        OBS: Coloque uma condição para a função rodar.