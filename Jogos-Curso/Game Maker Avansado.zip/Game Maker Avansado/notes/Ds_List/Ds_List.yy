{
  "$GMNotes":"v1",
  "%Name":"Ds_List",
  "name":"Ds_List",
  "parent":{
    "name":"Estruturas de Dados",
    "path":"folders/Documentações/Estruturas de Dados.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}