Funções Basicas e fáceis de entender.

Max e Min

    Com essas funções você consegue pegar o maior ou menor valor em um conjunto de valores. Podendo usar de variáveis até
    números negativos.

    Max - Retorna o maior valor do conjunto. Exemplo:

        var _Valor = max(5, 7 , 8, 9, -2, -22);


        show_mensagem(_Valor) = 9

    Min - retorna o menor valor do conjunto. Exemplo:

        var _Valor = min(8, 9, -4, 7, 4);

        show_mensagem(_Valor) = -4


Funções de Arredondamento(Ceil, Floor, Round)

    Ceil - Ele arredonda o número sempre para cima. Exemplo:

        var _Teste = ceil(2.01);

        show_mensagem(_Teste) = 3

    Floor - Ele arredonda para baixo. Exemplo:

        var _Teste = floor(2.99);

        show_mensagem(_Teste) = 2

    Round - Ele arredonda para o número mais próximo. Exemplo:

        var _Teste = round(2,6);

        show_mensagem(_Teste) = 3

Frac

    O frac pega apenas o valor decimal do valor. Exemplo:

        var _Valor = frac(2.98);

        show_mensagem(_Valor) = 0.98

    Pode parecer inutil mas da para fazer efeitos bem legais. Por exemplo manipulando valores como image alpha, image xscala etc...

Funções de Tempo

    Deta_time - Pega o FPS do jogo.

    Get_Timer - Pega o tempo já passado desde o começo do jogo.