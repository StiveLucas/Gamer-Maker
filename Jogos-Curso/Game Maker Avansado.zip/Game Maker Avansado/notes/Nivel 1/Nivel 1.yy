{
  "$GMNotes":"v1",
  "%Name":"Nivel 1",
  "name":"Nivel 1",
  "parent":{
    "name":"Funções no GameMaker",
    "path":"folders/Documentações/Funções no GameMaker.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}