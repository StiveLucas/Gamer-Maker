Laços de Repetição.

OBS: Escreva no jogo o nome do codigo e busque na documentação para entender melhor.

Repeat - Nesse é só colocar o número de vezes que você quer que o codigo repita.

    Formula: 
        
            repeat (<Quntidade de vezes que você quer repetir>) { 
                <Bloco de Codigo>
            }

While - Nesse você consegue colocar uma condição para repetir, enquanto essa condição for verdadeira ele irá repetir.

    Formula:

            while (<Condição>) {
                <Bloco de Codigo>
            }

    Você tambem pode usar o Continue ele faz o parar onde ele está e todo codigo abaixo dele não é executado.

    Exemplo:

        while (<Condição>) { 
            <Bloco de Codigo>
            
            if(<Condicão> > <Condição>){
                <Bloco de Codigo>
                
                continue
            }
            
            <Bloco de Codigo>
        }

    Se o continue for executado e bloco abaixo dele não é executado e volta para o começo do laço de repetição.

For - Nesse já vem imbutido uma condição para ele parar, você pode deixar o i mesmo ou mudar para um variavel desejavel.

    Formula: 

            for (var i = 0; i < <Quantidade de vezes que você quer que repita(Pode ser em uma variável1)>; i++) {
	
            }

    Você também pode fazer um for aninhado, é pode usar um for dentro do outro.

    Exemplo:

    for (var i = 0; i <= 10; i++) {
	
        for (var j = 0; j <= 10; j++) {
    
        }
    }