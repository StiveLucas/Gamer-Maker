{
  "$GMNotes":"v1",
  "%Name":"Laços de Repetição",
  "name":"Laços de Repetição",
  "parent":{
    "name":"Nivel 2",
    "path":"folders/Documentações/Nivel 2.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}