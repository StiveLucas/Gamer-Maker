Sin e Cos

    Essas funções são basicamente na matematica o Seno e o Coseno. Aqui ambas funções retornam 1 e -1, com uma
    pequena diferença.

    Ambas fazem o movimento chamado de onda senoidal, que é o movimento de subir e descer formando uma onda, a 
    diferença entre eles é que o sin() ele começa no 0(na metade da onda) e o cos() começa no 1(no topo da onda).
    
    Quem decide onde vai começar é você.

    Formula:

        A formula serve para ambos, já que fazem a mesma coisa.
        
        Essa formula já traz o uso completo da função, mostrando o melhor jeito de usar a função.

                                    TABELA DE INSTRUÇÕES DE PREENCHIMENTO

        valor do espaçamento - aqui você vai ta colocando a distancia entre o início e o fim da onda.

        valor da velocidade - aqui você define a velocidade que vai ter para cruzar o espaçamento(distancia).

        valor constante - esse é o mais importante, você pode usar uma variável que cresce o valor dela constantemente ou
                            usar a função get_timer(Ela pega o tempo que já possou desde o jogo foi iniciado) e dividir
                            por 1000000. Teste para perceber a diferença entre eles.

        <valor do espaçamento> * sin(<valor da velocidade> * (valor constante));


Lengthdir_x e Lengthdir_y

    Com eles, você consegue definir a distancia e a direção de algo. Use cada um dos Lengthdir nos eixos corrtos,
    Lengthdir_x() no eixo x e o lengthir_y() no eixo y.

    Formula:

        A formula serve para ambos.

        lengthdir_x(<distancia que vai andar>, <direção que vai(em graus)>);

    Exemplo de uso:

        Nesse exemplo estou fazendo o objeto se mover pelas setas no teclado. usando os lengthdir_ podemos evitar o bug do
        objeto se mover mais rápido pelas diagonais.    

        //Variável de velocidade.
        Vel = 15;

        MovendoObjeto = function(){
           
            ////Inputs de direção.
            var _Left, _Rigth, _Up, _Down;
           
            _Left = keyboard_check(vk_left);
            _Rigth = keyboard_check(vk_right);
            _Up = keyboard_check(vk_up);
            _Down = keyboard_check(vk_down);
           
            //O uso do xor faz ele retornar true se os dois são diferentes.
            if ((_Left xor _Rigth) || (_Up xor _Down)) {
                
                //Fazendo a direção acontecer.
               	var _Direcao = point_direction(0, 0, (_Rigth - _Left), (_Down - _Up));
               
                x += lengthdir_x(Vel, _Direcao);
                y += lengthdir_y(Vel, _Direcao);
            }
        }