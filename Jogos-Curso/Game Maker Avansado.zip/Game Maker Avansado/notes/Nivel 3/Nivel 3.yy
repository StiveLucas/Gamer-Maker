{
  "$GMNotes":"v1",
  "%Name":"Nivel 3",
  "name":"Nivel 3",
  "parent":{
    "name":"Funções no GameMaker",
    "path":"folders/Documentações/Funções no GameMaker.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}