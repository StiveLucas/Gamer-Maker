

Tipos de dados do Game Maker

Booleano - retorna true ou false

Real - Um dado real pode ser um número inteiro ou quebrado. Exemplo: 10 ou 10.07

Integer - Apenas números inteiros. Exemplo: 1, 2, 3, etc..

String - São texos dentro de aspas. Exemplo: "Hello Word"

Underfined - É um dado que não tem valor, não existe.


Operadores aritméticos.

" + " Soma

" - " Subtração

" * " Multiplicação

" / " Divisão

" % " Resto da divisão

" div " Retorna a divisão em número inteiro


Operadores Lógicos.

&& / and - Retorna true se todas os valores for true.

|| / or - Retorna true se pelo menos um dos valores for true.

^^ / xor - Retornar true se os valores entre si são diferentes.

? - Ele checa apenas se uma condição é verdadeira. Exemplo: 5 > 2 ? <ValorVerdadeiro> : <ValorFalso>;


Escopo de Variáveis.

  Tipos de Variáveis.
    
    <NomeVariavel> - Uma Variavel normal que você já conhece.

    var <NomeVariavel> - Variável Temporaria, ela só existe na parte do codigo onde ela está.

    global.<NomeVariável> - Variável Global, ela existe no jogo para sempre, e ela pertence a todo mundo.