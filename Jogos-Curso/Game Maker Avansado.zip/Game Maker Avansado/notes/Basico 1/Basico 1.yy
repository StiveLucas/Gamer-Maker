{
  "$GMNotes":"v1",
  "%Name":"Basico 1",
  "name":"Basico 1",
  "parent":{
    "name":"Nivel 1",
    "path":"folders/Documentações/Básico do GameMaker/Nivel 1.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}