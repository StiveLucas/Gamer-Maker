
Obs: Isso são estruturas de dados, lembrese de deletalas no Clean UP.

Struct

    É outra estrutura de dados, onde podemos guardar dados e organizar, podendo até guardar funções para depois usar.
    
    Devemos primeiro criar a o Struct, dessa maneira.
    
    Formula:
    
            <Nome que desejar para o Struct> = {
                
                //Crie quantas  variáveis e funções que você desejar.
                
                <Variável>: <Valor da variável>,
                <Variável>: <Valor da variável>,
                <Variável>: <Valor da variável>,
                <Nome da Função>: function(){
                    
                },
                
                etc...
            }

    Por exemplo:

                Estrutura = {
    
                    Foto_Personagem: spr_Goku,
                    Nome: "Goku",
                    Idade: 43,
                    Ataque_Principal: "Kamehamehá",
                    Ki_Atual: 10,
                  
                    //Você também pode criar funcões.
                    Aumentando_Ki: function(){
                        
                        if (mouse_check_button_pressed(mb_left)) {
                          	Ki_Atual += 35;
                        }
                    }
                }

    Usando ou exibindo os dados de um Struct.

    Para usar ou exibir os dados de um Struct, basta chamar o strcut e usar colocar ponto e decidir o dado ou função
    que deseja usar.

    Formula: 

            <Nome do Struct>.<Variável que deseja do Struct>;

            Se for uma função

            <Nome do Struct>.<Nome da Função>();


Constructor

    Muito parecido com o Struct. Com ele podemos definir tipo uma funcão para agiizar a criação de estruturas de
    dados, além de ser mais organizados.

    Você também pode criar funções e usar. porém terá que chamar uma por uma.

    Formula:

            <Nome que desejar> = function(<Parametros que desejar>,<Parametros que desejar>, etc ...) constructor{
    
                <Variavel> = <Parametro que decidiu>;
                <Variavel> = <Valor que desejar>;
                
                <Variavel> = function(){
                    //Escreva sua função.
                }
            }

    Exemplo de uso:

            Cria_Personagem = function(_Foto_Personagem, _Nome, _Idade, _Ataque_Principal, _Poder_Luta) constructor{

                Foto_Personagem = _Foto_Personagem;
                Nome = _Nome;
                Idade = _Idade;
                Ataque_Principal = _Ataque_Principal;
                Poder_Luta = _Poder_Luta;
                
                Grito_Personagem = function(){
                    show_message("GOKUUU");
                }
                
                Apresentacao_Personagem = function(_Fala_Personagem){
                    show_message(_Fala_Personagem);
                }
            }

    Usando o Constructor.

        Agora criamos a variável que vai carregar todos aqueles dados.

        Formula:

                <NomeVariavel> = new <Nome da Função>(<se tiver, seus parâmetros>);

        Por exemplo:

                Personagem_1 = new Cria_Personagem(spr_Goku, "Goku", 43, "Kamehamehá", 8000);

    Usando as funções do constructor.

        Como eu disse, com constructor temos chamar a função de forma individual para cada variável.

        Formula:

                <NomeVariavel>.<Nome da função no construtor>();

        Exemplo de uso:

            Personagem_1.Grito_Personagem();

            Personagem_1.Apresentacao_Personagem("OIII");