{
  "$GMNotes":"v1",
  "%Name":"Struct e Constructor",
  "name":"Struct e Constructor",
  "parent":{
    "name":"Estruturas de Dados",
    "path":"folders/Documentações/Estruturas de Dados.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}