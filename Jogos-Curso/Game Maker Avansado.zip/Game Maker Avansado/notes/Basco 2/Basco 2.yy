{
  "$GMNotes":"v1",
  "%Name":"Basco 2",
  "name":"Basco 2",
  "parent":{
    "name":"Nivel 1",
    "path":"folders/Documentações/Nivel 1.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}