
Métodos

Métodos são funções de um objeto que ao executar pode gerar uma ou várias ações, ou, retornar um ou vários valores.

Com os Métodos você pode fazer um que faz o player abrir uma porta, dar um tira, perder vida ect....
Por exemplo:

    Aqui está um método que retorna uma string informando se é impar ou par.

    Impar_Par = function(){
        
        var _Numero = 7;
        
        if (_Numero % 2 = 0) {
        	return show_message("O Número é par!");
        }else {
        	return show_message("O Número é Impar!");
        }
    }

    Para usar, apenas chame no proprio objeto.
    Assim:

        Impar_Par();

    Você pode literalmente criar vários tipos de métodos para entregar vários resultados.
    Você pode usar o método em varias vezes e com valores diferente usando variáveis dentro do método.
    
    Por Exemplo:

        Impar_Par = function(_Numero){
    
           if (_Numero % 2 = 0) {
          	    return show_message("O Número é par!");
           }else {
              	return show_message("O Número é Impar!");
           }
        }

    E na hora de usar, coloque o valor que deseja.
    Assim:
   
        Impar_Par(5);

Funções

    Diferente do método, a função pode ser usada por vários objetos ela se torna global. 
    Normalmente sendo inicializada em um script. 

    Por Exemplo:

        function Impar_Par(_Numero){
    
            if (_Numero % 2 = 0) {
    	       show_message("O Número é par!");
            }else {
    	       return show_message("O Número é Impar!");
            }
        }

    Para usar não muda nada. apenas chame no objeto onde você quer usar.
    Assim:
    
    Impar_Par(5);


    Função Recursiva

        Ela é uma função normal, a diferença que ela chama ela mesma, executando ela novamente.
        Atenção: Coloque uma condição para ela parar de chamar ela mesma, se não vai travar o jogo.

        Por exemplo:

            Aqui estamos fazendo potenciação, pegando a _Base e  multiplicando pelo _Expoente, se o _expoente for maior que um
            a função é chamada de novo mais diminui o _Expoente em menos 1, essa repetição só acaba quando o _Expoente for igual
            a um. Ficando basicamente por exemplo: _Base = 1 _Expoente 5:

            1 x 5 = 5,  5 x 4 = 20, 20 x 3 = 60, 60 x 2 = 120

            function Potenciacao(_Base, _Expoente){
    
                _Base *= _Expoente;
               
                if (_Expoente <= 1) {
                   	return show_message(_Base);
                }else {
                   	return Potenciacao(_Base, _Expoente - 1);
                }
            }

            Para usar não muda em nada, apenas de o valor da _Base e o do _Expoente
            Assim:

            Potenciacao(1, 5);