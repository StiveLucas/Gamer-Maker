{
  "$GMNotes":"v2",
  "%Name":"Sistema de Particulas",
  "name":"Sistema de Particulas",
  "parent":{
    "name":"Documentações",
    "path":"folders/Documentações.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}