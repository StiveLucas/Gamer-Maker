
Sistemas de Particulas

Usando um Sistemas de Particulas, você pode usar um sistema de particula para criar particulas do seu agrado, desde
partículas de fogo à particulas de poeiras. Seja criativo!

Incremento - Isso faz a particula encrementar a cada frame, ou seja aumentar ou diminuir o valor. Para diminuir deixe 
             o valor negativo.

Direção - Muda a direção que as particulas vão.

Orientação - Muda o angulo da particula em si.


Você também pode editar e colocar outros efeitos na particula, basta ir no inspetor e ir no asset onde a particula
está.