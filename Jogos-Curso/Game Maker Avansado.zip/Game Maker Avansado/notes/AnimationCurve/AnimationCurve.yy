{
  "$GMNotes":"v1",
  "%Name":"AnimationCurve",
  "name":"AnimationCurve",
  "parent":{
    "name":"Usando AnimationCurve",
    "path":"folders/Documentações/Usando AnimationCurve.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}