
Animation Curve

    Essa função pode ser bem util para fazer movimentos ou eventos bem únicas.

    Para usar primeiro crie ela na seu Asset Browser, defina um nome para a curva e configure a seu gosto.
    Agora para usar eu seu objeto você vai criar ela primeiro, usando:

    Curva = animcurve_get_channel(<Nome da AnimationCurve>, <Nome da curva que você pois>);

    Depois de criada, você vai usa-lá, usando: 

                                    TABELA DE INSTRUÇÕES DE PREENCHIMENTO

        Curva criada - Use a curva que criou

        Variável de Crescente - Crie/Use uma variável de cresça constantemente até o valor máximo da curva.

    ValorCurva = animcurve_channel_evaluate(<Curva criada>, <Variável de Crescente>);

    Com isso você poder usar em várias coisas, teste para ver as possibilidades.