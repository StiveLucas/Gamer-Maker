{
  "$GMNotes":"v1",
  "%Name":"Vetores e Matrizes",
  "name":"Vetores e Matrizes",
  "parent":{
    "name":"Nivel 2",
    "path":"folders/Documentações/Básico do GameMaker/Nivel 2.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}