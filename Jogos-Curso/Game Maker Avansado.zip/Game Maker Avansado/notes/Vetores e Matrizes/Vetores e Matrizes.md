Vetores/Arrays.

    Arrays é uma variável que consegue guarda varías informações dentro dela.

    Exemplo:
    
            <NomeVariavel> = [<Valor1>, <Valor2>, <Valor3> ...];

    Colocando assim você exibi todas as informações do Array.

    show_message(<NomeArray>);

    Para vizualizar o valor unico de um Array apenas coloque o cochetes depois da variavel e um numero dentro dos cochetes,
    esse número representa o indece onde ele vai pegar o valor do Array. 

    Obs: O primeiro valor de um array começã com no zero.

    Exemplo:

            <NomeVariavel> = [<Valor1(0)>, <Valor2(1)>, <Valor3(2)> ...];

        Se você for exibir o valor <NomeArray[2]> o resultado seria o Valor3.

Vetores 2D.

    Isso é Basicamente um vetor dentro do outro, formando uma matriz.

    Formula:

            <NomeVariavel>[0][0] = <Valor da Matriz>;

    O primeiro zero representa a coluna, já o segundo é a linha. Pensando desse jeito fica melhor de entender.
    O melhor exemplo de uso para os Veteros 2d(Matriz) é a criação de um inventario simples.

    Exemplo:

        Inventario que vamos criar.

        Armas   Itens   Equipamentos
        Espada  Maçã    Capacete
        Machado Pedra   Anel
        Cajado  Semente Brinco

            //Categorias.
            Inventario[0][0] = "Armas";
            Inventario[1][0] = "Itens";
            Inventario[2][0] = "Equipamentos";
            
            //Armas.
            Inventario[0][1] = "Espada";
            Inventario[0][2] = "Machadao";
            Inventario[0][3] = "Cajado";
            
            //Itens.
            Inventario[1][1] = "Maçã";
            Inventario[1][2] = "Pedra";
            Inventario[1][3] = "Semente";
            
            //Equipamentos.
            Inventario[2][1] = "Capacete";
            Inventario[2][2] = "Anel";
            Inventario[2][3] = "Brinco";