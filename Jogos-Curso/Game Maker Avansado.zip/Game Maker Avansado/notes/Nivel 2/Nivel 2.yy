{
  "$GMNotes":"v1",
  "%Name":"Nivel 2",
  "name":"Nivel 2",
  "parent":{
    "name":"Funções no GameMaker",
    "path":"folders/Documentações/Funções no GameMaker.yy",
  },
  "resourceType":"GMNotes",
  "resourceVersion":"2.0",
}