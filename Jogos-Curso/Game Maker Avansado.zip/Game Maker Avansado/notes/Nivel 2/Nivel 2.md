
Sign()

    Normalmente usado no -  Step

    Ela retorna 1, -1 ou 0. Funciona assim:

        Se o valor for acima de 0, ela vai entregar 1

        Se o valor for abaixo de 0, ele vai entregar -1

        Se o valor for 0, ele vai entregar 0

    Exemplo:

    var _Valor = sign(-90);

    show_mensagem(_Valor) = -1


Abs()

    Ele pegar o Valor e deixa absoluto, deixa ele sempre positivo. Exemplo:

    var _Valor = abs(-634);

    show_mensagem(_Valor) = 634

    Mas se você colocar um sinal de negativo antes do abs, ele se torna negativo. Exemplo:

    var _Valor = -abs(-94);

    show_mensagem(_Valor) = -94


Clamp()

    Normalmente usado no -  Step

    Essa função dar um limite nos valores, tendo o mínimo que ele pode chegar, e o máximo que ele pode alcançar.

    Formula:  
    
        clamp(<Valor que deseja colocar um limite>, <Valor mínino que pode chegar>, <Valor máximo que pode alcançar>);

    Exemplo:

        var _Poder = clamp(6, 0, 10);

        Se você colocar o poder acima de 10, ele vai retornar o máximo(no caso 10), se for abaixo de zero ele vai retornar o
        mínimo(no caso 0).


Lerp()

    Normalmente usado no -  Step

    Essa função aproxima um valor para outro valor aos poucos.

    Formula:

        <Variavel> = lerp(<Variavel>, <Valor que deseje que ele chegue>, <valor que ele vai somar até se aproximar dele>);

    Exemplo:

        VelH = 10;
            
        VelH = lerp(VelH, 0, 0.02);

        O exemplo mostra o VelH se aproximar do zero.


Make_colour_hsv()