/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_self();

var _TamanhoLista = ds_list_size(Lista);
for (var i = 0; i < _TamanhoLista; i++) {
	
    draw_text(20, 50 * i, Lista[| i]);
}