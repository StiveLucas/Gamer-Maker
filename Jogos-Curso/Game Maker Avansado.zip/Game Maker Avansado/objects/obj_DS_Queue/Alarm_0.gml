/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deletando o ultimo dado da Fila.
var _UltimaDirecao = ds_queue_dequeue(Fila);

//Deletando da lista o Primeiro dado que entrou.
ds_list_delete(Lista, 0);

Mover_Objeto(_UltimaDirecao);

var _TamanhoLista = ds_queue_size(Fila);

if(_TamanhoLista > 0) alarm[0] = 60 / 2;