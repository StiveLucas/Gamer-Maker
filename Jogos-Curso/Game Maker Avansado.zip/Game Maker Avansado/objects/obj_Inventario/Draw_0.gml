/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//draw_set_colour(ConfigCor);
//
//draw_text(x, y, global.Textoo);
//
//draw_set_colour(c_white);