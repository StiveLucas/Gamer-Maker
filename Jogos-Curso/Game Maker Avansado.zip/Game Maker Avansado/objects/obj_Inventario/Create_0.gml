/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

ConfigCor = c_white;
global.Textoo = "Texto";


Categoria = 0;
Item = 1;

//Categorias.
Inventario[0][0] = "Armas";
Inventario[1][0] = "Itens";
Inventario[2][0] = "Equipamentos";

//Armas.
Inventario[0][1] = "Espada";
Inventario[0][2] = "Machadao";
Inventario[0][3] = "Cajado";

//Itens.
Inventario[1][1] = "Maçã";
Inventario[1][2] = "Pedra";
Inventario[1][3] = "Semente dos Deuses";

//Equipamentos.
Inventario[2][1] = "Capacete";
Inventario[2][2] = "Anel";
Inventario[2][3] = "Brinco";