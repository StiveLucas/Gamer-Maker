/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

var _MudarEsquerda_Categoria = keyboard_check_pressed(vk_left);
var _MudarDireita_Categoria = keyboard_check_pressed(vk_right);

var _MudarCima_Item = keyboard_check_pressed(vk_up);
var _MudarBaixo_Item = keyboard_check_pressed(vk_down);

if (_MudarEsquerda_Categoria) {
    
    if(Categoria > 0) Categoria--;
    Item = 1;
}

if (_MudarDireita_Categoria) {
	if(Categoria < array_length(Inventario) - 1) Categoria++;
    Item = 1;
}

if (_MudarCima_Item) {
	if(Item > 1) Item--;
}

if (_MudarBaixo_Item) {
	if(Item < array_length(Inventario)) Item++;
}