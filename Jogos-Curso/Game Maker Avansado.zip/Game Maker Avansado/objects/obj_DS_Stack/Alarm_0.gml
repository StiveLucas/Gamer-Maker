/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deletando o ultimo dado da Pilha.
var _UltimaDirecao = ds_stack_pop(Pilha);

//Deletando da lista o ultimo dado que saiu.
ds_list_delete(Lista, ds_list_size(Lista) - 1);

Mover_Objeto(_UltimaDirecao);

var _TamanhoLista = ds_stack_size(Pilha);

if(_TamanhoLista > 0) alarm[0] = 60 / 2;