/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando Pilha.
Pilha = ds_stack_create();

//Criando uma lista.
Lista = ds_list_create()

//Adcionando dados a pilha e a lista.
Adcionando_Pilha = function(_Valor, _Texto){
    
    ds_stack_push(Pilha, _Valor);
    ds_list_add(Lista, _Texto);
}

//Movimentando o objeto com base no valor da lista.
Movimentando_Objeto = function(){

    var _Enter = keyboard_check_pressed(vk_enter);
    var _TamanhoLista = ds_stack_size(Pilha);
    
    if(_Enter && alarm[0] <= 0){
        
        if(_TamanhoLista > 0) alarm[0] = 60 / 2;
    }
}

Mover_Objeto = function(_Direcao){
    
    x += lengthdir_x(64, _Direcao);
    y += lengthdir_y(64, _Direcao);
}