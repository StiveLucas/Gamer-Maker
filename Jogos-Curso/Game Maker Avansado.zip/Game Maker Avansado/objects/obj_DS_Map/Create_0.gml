/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando o ds map.
Mapa = ds_map_create();

//Adcionando valores ao ds_mapa.

ds_map_add(Mapa, "Foto", spr_Foto_Jinx);

ds_map_add(Mapa, "Nome", "Jinx");

Mapa[? "Idade"] = 43;

Mapa[? "Poder"] = 5000;

Mapa[? "Ataque"] = "Kameha";

Exibindo_Info = function(){
    
    var _Largura = 400;
    var _Altura = 250;
    var _Xscale = _Largura / sprite_get_width(spr_Moldura);
    var _Yscale = _Altura / sprite_get_height(spr_Moldura);
    var _X1 = room_width / 2;
    var _Y1 = room_height / 2;
    
    draw_sprite_ext(spr_Moldura, 0, _X1, _Y1, _Xscale, _Yscale, 0, c_white, 1);
    
    var _Altura_Txt = string_height("T");
    var _Margem_Txt = _Altura_Txt + 5;
    
    draw_set_colour(c_red);
    
    _X1 = room_width / 2 - _Largura / 2 + _Margem_Txt;
    _Y1 = room_height / 2 - _Altura / 2 + _Margem_Txt; 
    
    draw_set_valign(1);
    
    draw_text(_X1, _Y1, "Nome: " + Mapa[? "Nome"]);
    draw_text(_X1, _Y1 + _Altura_Txt * 1, "Idade: " + string(Mapa[? "Idade"]));
    draw_text(_X1, _Y1 + _Altura_Txt * 2, "Poder: " + string(Mapa[? "Poder"]));
    draw_text(_X1, _Y1 + _Altura_Txt * 3, "Ataque: " + Mapa[? "Ataque"]);
                      
    draw_set_colour(-1);
    draw_set_valign(-1);
    
}