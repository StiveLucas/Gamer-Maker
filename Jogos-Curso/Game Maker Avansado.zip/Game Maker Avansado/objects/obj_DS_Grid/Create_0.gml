/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

///Criando a ds_grid.

//Descobrindo quantas colunas e linhas eu tenho.
TamanhoCelula = 40;
Colunas = room_width div TamanhoCelula;
Linhas = room_height div TamanhoCelula;

Gride = ds_grid_create(Colunas, Linhas);
Posicoes = ds_map_create();

//Depois de preencher a grid, "limpamos ela".
ds_grid_clear(Gride, 0);

//Alfabeto inteiro.
Alfabeto = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
                "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
            ]

//Preenchendo o Ds_map.
Posicoes[? "x1"] = 0;
Posicoes[? "y1"] = 0;
Posicoes[? "x2"] = 0;
Posicoes[? "y2"] = 0;

//Função para preencher a Gride.
Preencher_Gride = function(){
    
    var _TamanhoAlfabeto = array_length(Alfabeto) - 1;
    
    //Rodando pelas Colunas.
    for (var i = 0; i < Colunas; i++) {
    	
        //Rodando pelas Linhas.
        for (var j = 0; j < Linhas; j++) {
        
            Gride[# i, j] = Alfabeto[irandom(_TamanhoAlfabeto)];
        }
    }
}

Preencher_Gride();


Desenhando_Gride = function(){
    
    for (var i = 0; i < Colunas; i++) {
    	
        for (var j = 0; j < Linhas; j++) {
        	
            //Variáveis para determinar o tamanho de cada célula.
            var _x1, _y1, _x2, _y2, _cor, _valor;
            
            _x1 = i * TamanhoCelula;
            _y1 = j * TamanhoCelula;
            _x2 = (i + 1) * TamanhoCelula;
            _y2 = (j + 1) * TamanhoCelula;
            _cor = c_yellow;
            _valor = Gride[# i, j];
            
            //Alterando o valor da grid  com base na posição do mouse.
            var _mouse_x = mouse_x div TamanhoCelula;
            var _mouse_y = mouse_y div TamanhoCelula;
            var _Click = mouse_check_button_pressed(mb_left);
            
            if(_mouse_x == i && _mouse_y == j){
                
                _cor = c_orange;
                
                if(_Click) Gride[# i, j] = 43;
            }
            
            var _pos_x1 = Posicoes[? "x1"];
            var _pos_y1 = Posicoes[? "y1"];
            var _intervalo_i = i == clamp(i, min(_pos_x1, _mouse_x), max(_mouse_x, _pos_x1));
            var _intervalo_j = j == clamp(j, min(_pos_y1, _mouse_y), max(_mouse_y, _pos_y1));
            
            if(_intervalo_i && _intervalo_j){
                if(mouse_check_button(mb_left)) _cor = c_orange;
                    
                if(mouse_check_button(mb_right)) _cor = c_red;
            }
            
            //Célula
            draw_rectangle_colour(_x1, _y1, _x2, _y2, _cor, _cor, _cor, _cor, false);
            
            //Bordas das células.
            _cor = c_black;
            draw_rectangle_colour(_x1, _y1, _x2, _y2, _cor, _cor, _cor, _cor, true);
            
            ///Desenhando Alfabeto.
            
            //Ajustando para ficar no centro.
            _x1 = (i * TamanhoCelula) + (TamanhoCelula/2);
            _y1 = (j * TamanhoCelula) + (TamanhoCelula/2);
            
            draw_set_color(_cor);
            draw_set_halign(1);
            draw_set_valign(1);
            
            draw_text(_x1, _y1, _valor);
            
            draw_set_color(c_white);
            draw_set_halign(-1);
            draw_set_valign(-1);
        }
    }
}

Preenche = function(_Mapa, _Botao){
    var _X1, _Y1, _X2, _Y2, _Valor;
    
    _X1 = _Mapa[? "x1"];
    _Y1 = _Mapa[? "y1"];
    _X2 = _Mapa[? "x2"];
    _Y2 = _Mapa[? "y2"];
    
    _Valor = _Botao == mb_left ? "X" : "";
    
    if (_Botao) {
    	
        ds_grid_set_region(Gride, _X1, _Y1, _X2, _Y2, _Valor);
    }
}

//Função de seleção.
Selecionando_Grid = function(_Botao){
    
    var _mouse_x = mouse_x div TamanhoCelula;
    var _mouse_y = mouse_y div TamanhoCelula;
    var _clickSegurado = mouse_check_button_pressed(_Botao);
    var _clickLargado = mouse_check_button_released(_Botao);
    
    if (_clickSegurado) {
    	Posicoes[? "x1"] = _mouse_x;
    	Posicoes[? "y1"] = _mouse_y;
    }
    
    if (_clickLargado) {
    	Posicoes[? "x2"] = _mouse_x;
        Posicoes[? "y2"] = _mouse_y;
        
        Preenche(Posicoes, _Botao);
        
        Posicoes[? "x1"] = 0;
    	Posicoes[? "y1"] = 0;
        Posicoes[? "x2"] = 0;
        Posicoes[? "y2"] = 0;
    }                     
}