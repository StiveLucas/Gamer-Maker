//Usando uma Funcão.
Estrutura.Aumentando_Ki();