//Usando uma Funcão.
Estrutura.Exibindo_Personagem();