/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando o Struct
Estrutura ={
    
    Nome: "Goku",
    Idade: 43,
    Status: "Bom"
}

//Exibindo o Struct
show_message(Estrutura.Nome);