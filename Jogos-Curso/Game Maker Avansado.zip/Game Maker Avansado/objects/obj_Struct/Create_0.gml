/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando o Struct
Estrutura ={
    
    Foto_Personagem: spr_Goku,
    Nome: "Goku",
    Idade: 43,
    Ataque_Principal: "Kamehamehá",
    Ki_Atual: 10,
    
    //Você também pode criar funcões.
    Aumentando_Ki: function(){
        
        if (mouse_check_button_pressed(mb_left)) {
        	Ki_Atual += 35;
        }
    },
    
    Exibindo_Personagem: function(){
        
        var _Foto_Personagem = Foto_Personagem;
        var _Nome = Nome;
        var _Idade = Idade;
        var _Ataque_Principal = Ataque_Principal;
        var _Ki_Atual = Ki_Atual;
        
        var _Largura = 520;
        var _Altura = 400;
        
        var _X1 = (room_width div 2) - (_Largura div 2);
        var _Y1 = (room_height div 2) - (_Altura div 2);
        var _X2 = _X1 + _Largura;
        var _Y2 = _Y1 + _Altura;
        
        var _Cor = c_white;
        var _Margem_FotoX = _Largura div 2;
        var _Margem_FotoY = 80;
        
        var _Margem_X = _Largura div 3;
        var _Margem_Y = 80;
        
        draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
        
        draw_set_font(fnt_CaixaDialogo);
        
        draw_sprite_ext(_Foto_Personagem, 0, _X1 + (_Margem_FotoX div 3), _Y1 + (_Margem_FotoY + 120), 0.1, 0.3, 0, c_white, 1);
        
        draw_text(_X1 + _Margem_X, _Y1 + _Margem_Y, "Nome: " + _Nome);
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 50), "Idade: " + string(_Idade));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 100), "Ataque Principal: " + string(_Ataque_Principal));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 150), "Poder de Luta: " + string(_Ki_Atual));
        
        draw_set_font(-1);
    }
}

//Exibindo o Struct
show_message(Estrutura.Nome);