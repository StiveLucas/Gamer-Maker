//Sempre lempe a particula, para não ficar acumulando lixo na memória.
part_system_clear(Particula_Fogo);
part_system_destroy(Particula_Fogo);