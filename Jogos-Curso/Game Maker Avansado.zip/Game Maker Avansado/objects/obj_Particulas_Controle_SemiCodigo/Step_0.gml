//Fazendo a particula seguir o mouse.
part_system_position(Particula_Fogo, mouse_x, mouse_y);