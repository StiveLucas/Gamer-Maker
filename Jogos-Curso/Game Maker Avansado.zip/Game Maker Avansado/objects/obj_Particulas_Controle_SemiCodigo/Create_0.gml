
//Criando minha particula na room.
Particula_Fogo = part_system_create(ps_Particulas);

//Alterando posição da particula.
part_system_position(Particula_Fogo, x, y);

//Alterando profundidade da particula. Você pode definir uma layer ou usar o Deph.
//part_system_layer();
part_system_depth(Particula_Fogo, 0);