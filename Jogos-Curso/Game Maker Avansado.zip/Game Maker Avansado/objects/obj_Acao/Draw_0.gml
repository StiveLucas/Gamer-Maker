/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_self();

draw_set_colour(c_black);
draw_set_halign(fa_center);
draw_set_valign(fa_center);

if(position_meeting(mouse_x, mouse_y, id)) image_blend = c_gray else image_blend = c_white;

draw_text(x, y, Direcao);

draw_set_colour(-1);
draw_set_halign(-1);
draw_set_valign(-1);