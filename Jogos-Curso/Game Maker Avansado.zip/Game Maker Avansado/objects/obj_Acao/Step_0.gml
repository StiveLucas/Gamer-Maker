/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

var _MouseSobre = position_meeting(mouse_x, mouse_y, id);
var _MouseClick = mouse_check_button_pressed(mb_left);

if (_MouseSobre) {
    
    if (_MouseClick) {
    	
        var _Dir;
        
        switch (Direcao) {
        	
            case "Esquerda":
                _Dir = 180;
            break;
            
            case "Direita":
                _Dir = 0;
            break;
            
            case "Cima":
                _Dir = 90;
            break;
        
            case "Baixo":
                _Dir = 270;
            break;
        }

        if (instance_exists(obj_DS_Stack)) {
            with (obj_DS_Stack) Adcionando_Pilha(_Dir, other.Direcao);
        }else if (instance_exists(obj_DS_Queue)) {
        	with (obj_DS_Queue) Adcionando_Fila(_Dir, other.Direcao);
        }
    }
}