Caracteres = 0;

Alinhando_Texto = function(_Horizontal, _Vertical){
    
    draw_set_halign(_Horizontal);
    draw_set_valign(_Vertical);
}

Desenhado_TituloAnimado = function(_Titulo){
    
    //Definindo fonte.
    draw_set_font(fnt_Titulo);
    
    //Centralizando texto.
    Alinhando_Texto(fa_center, fa_center);
    
    //Meu timer para controlar a  onda.
    var _tempo = 5 * get_timer() / 1000000;

    //Variáveis.
    var _x1, _y1, _angulo, _cor, _alpha;    
    _x1 = room_width / 2 + (4 * sin(2 * _tempo));
    _y1 = 200 + (2 * sin(2 * _tempo));
    _angulo = 0;
    _cor = c_orange;
    _alpha = 1;
    
    draw_text_transformed_colour(_x1, _y1, _Titulo, 1, 1, _angulo, _cor, _cor, _cor, _cor, _alpha);
    
    _cor = c_yellow;
    
    draw_text_transformed_colour(_x1, _y1, _Titulo, 1, 1, _angulo, _cor, _cor, _cor, _cor, _alpha);
    //Resetando
    draw_set_font(-1);
    draw_set_halign(-1);
    draw_set_valign(-1);
}

Desenhando_Texto = function(_Testo){
    
    var _X1, _Y1, _X2, _Y2, _Larg = 400, _Altura = 50, _Margem = 4;
    
    //Funções de alinhamento de texto e fonte.
    draw_set_font(fnt_CaixaDialogo);
    draw_set_halign(fa_center);
    draw_set_valign(fa_center);
    
    if(Caracteres < string_length(_Testo)){
        if(keyboard_check(vk_space)) Caracteres+= 0.5; else Caracteres += 0.1;
    }
    
    //Cria um efeito de máquina de escrever no texto.
    var _MeuTexto = string_copy(_Testo, 1, Caracteres);
    
    //Essa função pega a altura do texto.
    var _AlturaTexto = string_height(_Testo);
    
    //Já essa função faz o calculo para manter o tamnho da caixa de dialogo maior que a altura do texto.
    _Altura = string_height_ext(_MeuTexto, _AlturaTexto, _Larg - _Margem);
    _X1 = room_width/2 - _Larg/2;
    _Y1 = room_height/2 - _Altura/2;
    _X2 = _X1 + _Larg;
    _Y2 = _Y1 + _Altura;
    
    draw_rectangle_colour(_X1 - _Margem, _Y1 - _Margem, _X2 + _Margem, _Y2 + _Margem, c_aqua, c_aqua, c_aqua, c_aqua, false);
    draw_rectangle_colour(_X1, _Y1, _X2, _Y2, c_dkgray, c_dkgray, c_dkgray, c_dkgray, false);
    
    var _TextLargura = string_width_ext(_Testo, _AlturaTexto, _Larg - _Margem) / 2;
    var _TextAltura = string_height_ext(_MeuTexto, _AlturaTexto, _Larg - _Margem) / 2;
    
    draw_text_ext(_X1 + _Margem +_TextLargura, _Y1 + _Margem + _TextAltura, _MeuTexto, _AlturaTexto, _Larg - _Margem);
    
    draw_set_halign(-1);
    draw_set_valign(-1);
    draw_set_font(-1);
}


Titulo = "Dragon ball Super!";
Texto = "Posso precentir o perigo e o caos! E com minha mente vou a mil lugares. Imaginação me da forças pra voar!";