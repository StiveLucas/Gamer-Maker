/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Use essa função para deletar a lista da memória.
ds_list_destroy(Meses);