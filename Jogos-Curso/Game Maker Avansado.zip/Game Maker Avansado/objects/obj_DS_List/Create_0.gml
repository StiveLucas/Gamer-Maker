/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando a DS_lista.
Meses = ds_list_create()

//Preenchendo a lista.
ds_list_add(Meses, "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho",
                "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
            );

//Acessando a lista.
//show_message(Meses[| 2]);

Indece = 0;

ExibindoMeses = function(){
    
    //Pega o tamanho da lista.
    var _Tamanho_Lista = ds_list_size(Meses) - 1;
    
    for (var i = 0; i <= _Tamanho_Lista; i++) {
    	
        var _EspacamentoY = 30;

        var _Cor = c_white;
        
        if(Indece == i) _Cor = c_red;
            
        draw_set_colour(_Cor);
        var _NomeMes = draw_text(room_width / 2, (room_height / 2 - 100) + (_EspacamentoY * i), Meses[| i]);
        draw_set_colour(-1);
    }
    
    if (keyboard_check_pressed(vk_enter)) {
        //Deixando a ordem da lista aleatória.
    	ds_list_shuffle(Meses);
    }
    
    var _Cima = keyboard_check_pressed(vk_up);
    var _Baixo = keyboard_check_pressed(vk_down);
    
    if (_Cima) {
        if(Indece > 0) Indece--;
    }
    
    if (_Baixo) {
        if(Indece < _Tamanho_Lista) Indece++;
    }
    
    var _Deletar = keyboard_check_pressed(vk_delete);
    
    if (_Deletar) {
    	ds_list_delete(Meses, Indece);
    }
}