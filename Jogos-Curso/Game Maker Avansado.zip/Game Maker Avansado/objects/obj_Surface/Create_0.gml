
//Surface é tipo um superfície para poder desenhar, ao invés de criar objetos para fazer efeitos de
//sangue ou outros, ocupandando a memória da máquina, use a surface.

//Criando minha Surface
Surf = surface_create(room_width, room_height);

//Definindo a Surface.
Desenha_Surface = function(){
    
    //Sempre que for mecher na Surface verifique se ela existe.
    if (!surface_exists(Surf)) {
    	
        //Crio a Surface.
        Surf = surface_create(room_width, room_height);
        
        //Definindo o algo da Surface.
        surface_set_target(Surf);
        
        //Limpando a Surface.
        draw_clear_alpha(c_black, 0);
        
        //Resetando o meu alvo (Volta a ver o alvo corretamente).
        surface_reset_target();
        
    }else {
    	draw_surface(Surf, 0, 0);
    }
}

Desenhando_Na_Surface = function(){
    
    var _Mouse_Clik = mouse_check_button_pressed(mb_left);
    
    if (_Mouse_Clik) {
    	
        //Desenhando na Surface.
        if (surface_exists(Surf)) {
        	surface_set_target(Surf);
            draw_set_colour(c_red);
            
            //Desenhando uma bolinha vermelha.
            draw_circle(mouse_x, mouse_y, 20, false);
            
            draw_set_colour(c_white);
            
            //Reseta o algo.
            surface_reset_target();
        }
    }
}

//Criando um efeito de sangue usando Surface.
Cria_Efeito_Sangue = function(){
    
    if (surface_exists(Surf)) {
        
    	surface_set_target(Surf);
        
        var _Mouse_Click = mouse_check_button_pressed(mb_left);
        
        if (_Mouse_Click) {
            repeat (irandom_range(5, 45)) {
                var _Sangue = instance_create_depth(mouse_x, mouse_y, 0, obj_Sangue);
            }
        }
        
        //Reseta o algo.
        surface_reset_target();
    }
}

//Desenhando na tela efeito de sangue.
Surface_Efeito_Sangue = function(){
    
    if (instance_exists(obj_Sangue)) {
    	
        if (surface_exists(Surf)) {
        	
            surface_set_target(Surf);
            
            with (obj_Sangue) {
            	draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
            }
            
            surface_reset_target();
        }
    }
}

//Fazendo efeito de Luz.
Desenhando_Efeito_Luz = function(){
    
    //Verificando se a surface existe.
    if (surface_exists(Surf)) {
    	 
        //Definindo alvo da surface.
        surface_set_target(Surf);
        
        //Limpando a surface.
        draw_clear_alpha(c_black, 0.8);
        
        ///Desenhand a luz ou mascara de luz.
        
        //Com esse efeito podemos deixar o efeito mais realista.
        gpu_set_blendmode(bm_subtract);
        draw_sprite_ext(spr_Luz, 0, mouse_x, mouse_y, 2.5, 2.5, 0, c_white, 1);
        
        //Resete tudo.
        gpu_set_blendmode(bm_normal);
        surface_reset_target();
    }
}