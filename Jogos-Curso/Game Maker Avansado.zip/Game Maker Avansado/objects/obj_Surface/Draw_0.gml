Desenha_Surface();
////Desenhando_Na_Surface();
//Cria_Efeito_Sangue();
//Surface_Efeito_Sangue();
Desenhando_Efeito_Luz()