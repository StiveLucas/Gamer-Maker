//Limpando da mémoria para não pesar o jogo.
surface_free(Surf);