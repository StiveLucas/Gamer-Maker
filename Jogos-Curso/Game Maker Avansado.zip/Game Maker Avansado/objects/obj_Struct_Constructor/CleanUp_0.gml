//Lembrese  de deletar as estruturas de dados para não acumular lixo.
for (var i = 0; i < array_length(Personagens); i++) {
	delete Personagens[i];
}