//Usando uma Funcão com Struct.
//Estrutura.Exibindo_Personagem();

//Usando uma função com Construct.
//Personagem_1.Exibindo_Personagem(Largura_Caixa, Altura_Caixa);

for (var i = 0; i < Indece; i++) {
	Personagens[i].Exibindo_Personagem(Largura_Caixa, Altura_Caixa);
}
