/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Largura_Caixa = 520;
Altura_Caixa = 400;

//Criando o Struct
Estrutura = {
    
    Foto_Personagem: spr_Goku,
    Nome: "Goku",
    Idade: 43,
    Ataque_Principal: "Kamehamehá",
    Ki_Atual: 10,
    
    //Você também pode criar funcões.
    Aumentando_Ki: function(){
        
        if (mouse_check_button_pressed(mb_left)) {
        	Ki_Atual += 35;
        }
    },
    
    Exibindo_Personagem: function(_Largura_Caixa, _Altura_Caixa){
        
        var _Foto_Personagem = Foto_Personagem;
        var _Nome = Nome;
        var _Idade = Idade;
        var _Ataque_Principal = Ataque_Principal;
        var _Ki_Atual = Ki_Atual;
        
        var _X1 = (room_width div 2) - (_Largura_Caixa div 2);
        var _Y1 = (room_height div 2) - (_Altura_Caixa div 2);
        var _X2 = _X1 + _Largura_Caixa;
        var _Y2 = _Y1 + _Altura_Caixa;
        
        var _Cor = c_white;
        var _Margem_FotoX = _Largura_Caixa div 2;
        var _Margem_FotoY = 80;
        
        var _Margem_X = _Largura_Caixa div 3;
        var _Margem_Y = 80;
        
        draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
        
        draw_set_font(fnt_CaixaDialogo);
        
        draw_sprite_ext(_Foto_Personagem, 0, _X1 + (_Margem_FotoX div 3), _Y1 + (_Margem_FotoY + 120), 0.1, 0.3, 0, c_white, 1);
        
        draw_text(_X1 + _Margem_X, _Y1 + _Margem_Y, "Nome: " + _Nome);
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 50), "Idade: " + string(_Idade));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 100), "Ataque Principal: " + string(_Ataque_Principal));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 150), "Poder de Luta: " + string(_Ki_Atual));
        
        draw_set_font(-1);
    }
}

//Exibindo o Struct
//show_message(Estrutura.Nome);

//Criando o Constructor.
Cria_Personagem = function(_Foto_Personagem, _Nome, _Idade, _Ataque_Principal, _Poder_Luta, _Largura_Caixa = 520, _Altura_Caixa = 400) constructor{
    
    Foto_Personagem = _Foto_Personagem;
    Nome = _Nome;
    Idade = _Idade;
    Ataque_Principal = _Ataque_Principal;
    Poder_Luta = _Poder_Luta;
    
    Apresentacao_Personagem = function(_Fala_Personagem){
        show_message(_Fala_Personagem);
    }
    
    static Pos_X = (room_width div 2) - (_Largura_Caixa div 2); 
    static Pos_Y = (room_height div 2) - (_Altura_Caixa div 2);
    
    Movendo = function(_Largura_Caixa, _Altura_Caixa){
        
        //Mudando a Posicao da caixa com o mouse.
        var _Posicao_MouseX = mouse_x == clamp(mouse_x, Pos_X - _Largura_Caixa, Pos_X + _Largura_Caixa);
        var _Posicao_MouseY = mouse_y == clamp(mouse_y, Pos_Y - _Altura_Caixa, Pos_Y + _Altura_Caixa);
        
        if (mouse_check_button(mb_left) && _Posicao_MouseX && _Posicao_MouseY) {
        	Pos_X = mouse_x - (_Largura_Caixa div 2);
            Pos_Y = mouse_y - (_Altura_Caixa div 2);
        }
    }
    
    Exibindo_Personagem = function(_Largura_Caixa = 520, _Altura_Caixa = 400){
        
        var _Foto_Personagem = Foto_Personagem;
        var _Nome = Nome;
        var _Idade = Idade;
        var _Ataque_Principal = Ataque_Principal;
        var _Ki_Atual = Poder_Luta;
        
        var _X1 = Pos_X;
        var _Y1 = Pos_Y;
        var _X2 = _X1 + _Largura_Caixa;
        var _Y2 = _Y1 + _Altura_Caixa;
        
        var _Cor = c_white;
        var _Margem_FotoX = _Largura_Caixa div 2;
        var _Margem_FotoY = 80;
        
        var _Margem_X = _Largura_Caixa div 3;
        var _Margem_Y = 80;
        
        draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
        
        draw_set_font(fnt_CaixaDialogo);
        
        draw_sprite_ext(_Foto_Personagem, 0, _X1 + (_Margem_FotoX div 3), _Y1 + (_Margem_FotoY + 120), 0.1, 0.3, 0, c_white, 1);
        
        draw_text(_X1 + _Margem_X, _Y1 + _Margem_Y, "Nome: " + _Nome);
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 50), "Idade: " + string(_Idade));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 100), "Ataque Principal: " + string(_Ataque_Principal));
        draw_text(_X1 + _Margem_X, _Y1 + (_Margem_Y + 150), "Poder de Luta: " + string(_Ki_Atual));
        
        draw_set_font(-1);
    }
}

//Usando o Constructor.
Personagem_1 = new Cria_Personagem(spr_Goku, "Goku", 43, "Kamehamehá", 9000);
Personagem_2 = new Cria_Personagem(spr_Vegeta, "Vegeta", 45, "Big bang atack", 9000);
Personagem_3 = new Cria_Personagem(spr_Freeza, "Freeza", 80, "Bola Mortal", 8200);
Personagem_4 = new Cria_Personagem(spr_Bills, "Bils", 100000, "Hakai", 900000000);
Personagem_5 = new Cria_Personagem(spr_Broly, "Broly", 41, "AHHHHHHHHHHHHHHHH", 00);

Personagens = [Personagem_1, Personagem_2, Personagem_3, Personagem_4, Personagem_5];
Indece = 0;