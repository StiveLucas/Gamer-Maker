//Usando uma Funcão com Struct.
Estrutura.Aumentando_Ki();

//Usando uma função com Construct.
//Personagem_1.Apresentacao_Personagem("OIII");

if(keyboard_check_pressed(vk_enter) && Indece < 5) Indece++;
    
for (var i = 0; i < Indece; i++) {
	Personagens[i].Movendo(Largura_Caixa, Altura_Caixa);
}