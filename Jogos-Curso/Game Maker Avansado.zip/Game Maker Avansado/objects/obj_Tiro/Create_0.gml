/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

speed = 10;
direction = 0;

Efeito_Onda = function(){
    
    var _OndaX = 20 * (sin( 8 * (get_timer() / 1000000)));
    
    show_debug_message(_OndaX)
    
    x += _OndaX;
}