

//Um sistema de partículas consiste em 3 elementos.
// 1. Sistema de partículas - Cuida de tudo.
// 2. Emissor de partículas - Cria as partículas.
// 3. A Partícula


//Criando o sistema de particulas.
global.Sistema_Particula = part_system_create();

//Criando o Emissor de particulas.
Emisor_Particulas = part_emitter_create(global.Sistema_Particula);

///Configurando o emisso de particulas.
//Aqui definimos o local da room onde as particulas serão geradas.
var _Meio_X = room_width / 2;
var _Meio_Y = room_height / 2;

var _Espalhar_Particulas = 200;

// O ps_distr é a forma como a particula é distribuida.
//O ps_shape é o formato q as particulas vai ser geradas.
//Use a documentação neles e veja como funciona os outros.
part_emitter_region(global.Sistema_Particula, Emisor_Particulas, _Meio_X - _Espalhar_Particulas, 
                    _Meio_X + _Espalhar_Particulas, _Meio_Y - _Espalhar_Particulas, 
                    _Meio_Y + _Espalhar_Particulas, ps_distr_gaussian, ps_shape_diamond);

///Criando a particula.
//Temos dois tipos de particulas:
//Burst - Cria as particulas de um vez, como se fose uma explosão.
//Stream - Cria as particulas de forma contínua, sem parar.
//part_emitter_stream(global.Sistema_Particula, Emisor_Particulas, particle1, 100);


//Criando a própria particula
Particula_Propria = part_type_create();

///Configurando a minha própria particula.
//Formato ou tipo da particula - No segundo argumento coloque pt_shape e escolha uma das opções a seu agrado.
part_type_shape(Particula_Propria, pt_shape_flare);

//Tempo de vida em segundos da particula.
part_type_life(Particula_Propria, 60, 60 * 4);

//Tamanho da particula.
part_type_size(Particula_Propria, 0.5, 1, 0.01, 0);

//Mechendo na cor - Aqui existe três tipo de part_type_colour: part_type_colour1, part_type_colour2, part_type_colour3
//Cada um aumenta as cores que a particula irá exibir durante seu tempo de vida. quanto maior for o collour, maior
//é a quantidade de cores ele irá exibir.(Máximo de 3 cores).
part_type_colour3(Particula_Propria, c_black, c_blue, c_aqua);

//Mechendo no Alpha - Aqui existe três tipo de part_type_alpha: part_type_alpha1, part_type_alpha2, part_type_alpha3
//Cada um define o ciclo do alpha da particula durante seu tempo de vida.
part_type_alpha3(Particula_Propria, 0.2, 0.5, 1);

//Velocidade de movimento da particula.
part_type_speed(Particula_Propria, 0, 2, 0.01, 0);

//Direção de movimento da particula.
part_type_direction(Particula_Propria, 0, 359, 1, 0);

//Gravidade nas particulas - Agurmentos(<Força da gravidade>, <Direção pra onde vai ser puxada>);]
part_type_gravity(Particula_Propria, 0.4, 240);

//Define a orientação da particura.
part_type_orientation(Particula_Propria, 0, 359, 0, 0, false);

//Mistura as cores se desejar.
part_type_blend(Particula_Propria, true);

//Essa função cria um nova particula toda vez quando uma particula morre. OBS: Tome cuidado pois pode travar o jogo.
//Argumentos(<A Particula>, <Quantas vezes ela vai criar>, <Qual particula ela vai criar>);
part_type_death(Particula_Propria, 1, particle1);


Exibindo_Particulas = function(){
    
    var _Mouse_Click = mouse_check_button(mb_left);
    
    if (_Mouse_Click) {
        
        //Definindo posição das particulas.
        
        var _Espalhando_ParticulasX = 20;
        var _Espalhando_ParticulasY = 10;
        
        part_emitter_region(global.Sistema_Particula, Emisor_Particulas, mouse_x - _Espalhando_ParticulasX,
                            mouse_x + _Espalhando_ParticulasX, mouse_y - _Espalhando_ParticulasY,
                            mouse_y + _Espalhando_ParticulasY, ps_shape_diamond, ps_distr_gaussian);
        
    	part_emitter_stream(global.Sistema_Particula, Emisor_Particulas, Particula_Propria, 1);
    }
}