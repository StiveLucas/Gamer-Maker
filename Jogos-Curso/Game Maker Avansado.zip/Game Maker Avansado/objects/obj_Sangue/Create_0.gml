image_speed = 0;

Escala_X = random_range(0.1, 0.8);
Escala_Y = random_range(0.1, 0.8);
direction = irandom(359);
image_blend = c_red;
speed = random_range(4, 9);

Efeito_Sangue = function(){
    
    image_xscale = Escala_X;
    image_yscale = image_xscale;
    
    Escala_X = lerp(Escala_X, 0, 0.04);
    
    image_alpha = lerp(image_alpha, 0, 0.06);
    
    if (image_alpha <= 0) {
    	instance_destroy();
    }
}