/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando um Quiz.
//Perguntas/Respostas.
//01.
Quiz[0][0] = "5 + 5";
Quiz[0][1] = 10;
Quiz[0][2] = 2;
Quiz[0][3] = 0;
Quiz[0][4] = 40;

//02.
Quiz[1][0] = "Qual foi a primeira capital do Brazil?";
Quiz[1][1] = "Salvador";
Quiz[1][2] = "São Paulo";
Quiz[1][3] = "Brasília";
Quiz[1][4] = "Rio de Janeiro";

//03.
Quiz[2][0] = "3 x 2";
Quiz[2][1] = 6;
Quiz[2][2] = 7;
Quiz[2][3] = 4;
Quiz[2][4] = 13;

//Controles.
RespostaCerta = false;

//Fazendo uma Pergunta aleatória.
global.Pergunta = irandom(array_length(Quiz) - 1);

/*Essa parte é bem complicada, vamos por parte aqui*/

//Agora vamos Criar os botôes que irá conter as respostas de forma aleatória.
CriandoBotoes = function(){
    
    //Tamanho do Array para saber quantas opções tem e criar a quantidade de botões com base nisso.
    var _Tamanho = array_length(Quiz[global.Pergunta]);

    //A Opção usando o irandom para deixar as perguntas alatórias.
    var _Opcao = irandom(_Tamanho);
    
    //Um for para criar os botões usando o _Tamanho para saber quantas vezes repetir.
    for (var i = 1; i < _Tamanho; i++) {
        
        var _BotaoResposta = instance_create_layer(10 + i * 250, 400, "ins_Botoes", obj_Botao);
        
        //A Opção não pode ser 0 se não opção vai carregar a pergunta e não a possivel resposta, por isso incrementamos mais 1.
        _Opcao++;
        
        /*Aqui a parte mais importante, com isso podemos fazer o codigo rodar por todas as opções disponiveis.
         * Pegamos o tamanho diminuimos o tamanho para menos um para ficar no amanho exato do array.*/
        _Opcao %= _Tamanho - 1;
        
        // Se o valor da opçao for 0 ele marca o botão como a resposta certa.
        if (_Opcao == 0) {
        	_BotaoResposta.OpcaoCerta = true;
        }
        
        //Por final, exibimos a opção mas aumentando em um a opção para n correr o risco de a opção vir no valor de zero e entregar a pergunta.
        _BotaoResposta.TextoBotao = Quiz[global.Pergunta][_Opcao + 1];
    }
}

CriandoBotoes();