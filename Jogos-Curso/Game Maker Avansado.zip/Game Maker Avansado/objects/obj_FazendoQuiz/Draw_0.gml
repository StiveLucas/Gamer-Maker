/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_text(room_width / 2 - 150, 200, "Pergunta: " + string(Quiz[global.Pergunta][0]));