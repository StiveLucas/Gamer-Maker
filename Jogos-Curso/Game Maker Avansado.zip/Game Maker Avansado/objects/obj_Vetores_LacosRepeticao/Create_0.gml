/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

/*Aqui vamos Colocar Botões com os nomes dos personagens de Dragon ball, que estão dentro de um Array.
 * Vamos preencher o mapa todo do jogo com esses botões, e cada botão vai ter o nome de algum
 * Personagem. Vamos usar o for aninhado.*/

//Array
GuerreirosZ = ["Goku", "Gohan", "Picolo", "Vegeta", "Broly", "Freza"];

var _Altura = sprite_get_height(spr_Botao);
var _Largura = sprite_get_width(spr_Botao);

//Dividindo a room em linhas e colunas com base no tamanho da minha sprite do botao
//Conta quantos botões cabem na room na Vertical(Use o div para retornar um número inteiro na divisão).
var _QndColunas = room_height div _Altura;

//Conta quantos botões cabem na room na Horizontal.
var _QndLinhas = room_width div _Largura;

//Rodando pelas Colunas.
for (var coluna = 0; coluna < _QndColunas; coluna++) {
	
    //Rodando pelas Linhas.
    for (var linha = 0; linha < _QndLinhas; linha++) {
    	
        //Criando um botão.
        var _Botao = instance_create_layer(linha * _Largura, coluna * _Altura, "ins_Botoes", obj_Botao);
        
        var _TamnhoArray = array_length(GuerreirosZ);
        
        //Impedindo o indece de passar do limite do Array
        var _Indece = coluna % _TamnhoArray;
        
        _Botao.TextoBotao = GuerreirosZ[_Indece];
    }
}