/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_self();

//Mudando a cor do texto do botão;
draw_set_colour(c_white);

draw_set_valign(1);

draw_set_halign(1);

var _Largura = sprite_width / 2;
var _Altura = sprite_height / 2;

draw_text(x, y, TextoBotao);
draw_set_colour(c_white);

draw_set_valign(0);

draw_set_halign(0);