/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

TextoBotao = "";
Cor = c_white;
OpcaoCerta = false;

Interacao_Botao = function(){
    
    if(BotaoPergunta) return;
    
    var _MouseSobre = instance_position(mouse_x, mouse_y, id);
    var _MouseClick = mouse_check_button_pressed(mb_left);
    
    if (_MouseSobre) {
    	
        if (_MouseClick) {
            
            image_xscale = 0.2;
            image_yscale = 0.2;
            
            if (OpcaoCerta) {
                
                global.Pergunta++;
                
                global.Pergunta %= 3;
                
                room_restart();
            }else {
            	show_message("Resposta Errada!");
            }

        }
    }
    
    image_xscale = lerp(image_xscale, 1, 0.05);
    image_yscale = lerp(image_yscale, 1, 0.05);
}

function Potenciacao(_Base, _Expoente){
    
    _Base *= _Expoente;
    
    if (_Expoente <= 1) {
    	return show_message(_Base);
    }else {
    	return Potenciacao(_Base, _Expoente - 1);
    }
}


Potenciacao(1, 5);