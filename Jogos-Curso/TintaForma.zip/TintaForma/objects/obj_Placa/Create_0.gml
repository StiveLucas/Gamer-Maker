/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

CaixaTexto = noone;

ExibirTexto = function(){
    var _Player = place_meeting(x, y, obj_Player);
    
    if (_Player) {
        
        if (!instance_exists(CaixaTexto)) {
        	CaixaTexto = instance_create_layer(x, y, "ins_Texto", obj_CaixaTexto);
            obj_CaixaTexto.Texto = _Texto;
        }
        
    }else {
    	if (instance_exists(CaixaTexto)) {
        	CaixaTexto.Me_Destruir = true;
        }
    }
}
