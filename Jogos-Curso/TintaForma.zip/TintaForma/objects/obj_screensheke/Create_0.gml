/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis
Potencia_Tremer = 0;

//Efeito de tremer.
Efeito_Tremer = function(){
    if (Potencia_Tremer != 0) {
        
        var _X = irandom_range(Potencia_Tremer, -Potencia_Tremer);
        var _Y = irandom_range(Potencia_Tremer, -Potencia_Tremer);
        
        view_set_xport(view_current, _X);
        view_set_yport(view_current, _Y);
        
    }else {
    	
        Potencia_Tremer = 0;
        
        view_set_xport(view_current, 0);
        view_set_yport(view_current, 0);
    }
    
    Potencia_Tremer = lerp(Potencia_Tremer, 0, 0.1);
}