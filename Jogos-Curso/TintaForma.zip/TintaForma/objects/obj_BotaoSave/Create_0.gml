/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
image_alpha = 0.5;

sprite = spr_Player_Idle;