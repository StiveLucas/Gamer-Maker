/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
var _Mouse = position_meeting(mouse_x, mouse_y, id);

var _MouseLeft = mouse_check_button_pressed(mb_left);

if (_Mouse) {
	image_alpha = 0.9;
    image_xscale = lerp(image_xscale, 6, 0.07);
    image_yscale = lerp(image_yscale, 1.8, 0.07);
    
    if (_MouseLeft) {
    
        global.Save_Escolhido = NumeroSave;
       
   	    CarregarJogo();
       
        cria_transicao_inicia(global.RoomAtual);
    
    }
}else {
	image_alpha = 0.5;
    image_xscale = lerp(image_xscale, 5, 0.06);
    image_yscale = lerp(image_yscale, 1, 0.06);
}