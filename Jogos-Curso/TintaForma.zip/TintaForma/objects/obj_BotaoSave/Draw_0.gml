/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
draw_self();


//Desenhando play no botão.
var _Playerx = x - 70;
var _Playery = y + 12;
draw_sprite_ext(sprite, current_time * 0.01, _Playerx, _Playery, 1, 1, 0,  c_white, image_alpha);

var _Txt = "Save " +  string(NumeroSave);

draw_set_halign(1);
draw_set_valign(1);
draw_set_font(ft_Save);

draw_text(x, y, _Txt);

draw_set_halign(-1);
draw_set_valign(-1);
draw_set_font(-1);
