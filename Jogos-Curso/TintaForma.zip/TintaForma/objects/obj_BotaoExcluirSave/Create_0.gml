/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

image_xscale = 1.3;
image_yscale = image_xscale;

image_alpha = 0.5