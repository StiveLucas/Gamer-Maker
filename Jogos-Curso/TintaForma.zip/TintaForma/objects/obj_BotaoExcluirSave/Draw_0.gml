/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
draw_self();

var _MeuTexto = "Excluir"
draw_set_font(ft_Excluir);
draw_set_halign(1);
draw_set_valign(1);

draw_text(x, y, _MeuTexto)

draw_set_font(-1);
draw_set_halign(-1);
draw_set_valign(-1);