/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
var _Mouse = position_meeting(mouse_x, mouse_y, id);

var _MouseLeft = mouse_check_button_pressed(mb_left);

if (_Mouse) {
	image_alpha = 0.9;
    image_xscale = lerp(image_xscale, 1.7, 0.01);
    
    if (_MouseLeft) {
        global.Save_Escolhido = NumeroSave;
    	ApagarSave();
    }
}else { 
    image_alpha = 0.5;
    image_xscale = lerp(image_xscale, 1.3, 0.01);
}

image_yscale = image_xscale;