/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(Seguir_Player) exit;

//Faz o player ganhar as chaves.

//Isso aqui salva o id da Chave no array.
other.ChavesCaregadas[other.QntdChaves] = id;

other.QntdChaves++;
Seguir_Player = true;
Alvo = other.id;

Numero_Chave = Alvo.QntdChaves;