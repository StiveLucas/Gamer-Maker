/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Faz o player ganhar as chaves.
other.Chaves++;
instance_destroy();