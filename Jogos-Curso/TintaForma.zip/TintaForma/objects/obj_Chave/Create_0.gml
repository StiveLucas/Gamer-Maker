/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis da chave.
Seguir_Player = false;
Alvo = noone
Porta_Alvo = noone;

Numero_Chave = 0;

EstadoSeguindo_Player = function(){
    if(!Seguir_Player) return;
        
    var _Player = obj_Player;
    
    //Esse abs ele transforma o valor em um absoluto, o valor sempre vai ser positivo.
    var _Dist_PLayer = abs(x - _Player.x);
    
    var _EspacosChaves = (15 * Numero_Chave) * _Player.Direcao_Sprite;
    
    if (instance_exists(Alvo)) {
        if (_Dist_PLayer != 20 * _EspacosChaves){
            x = lerp(x, _Player.x - _EspacosChaves, 0.1); 
        }
        
        //Essa função sin cria um movimento de subir e descer.
        //Formula: <A quantidade de pixels que vai subir e descer> * sin(<a Velocidade que vai subir e descer>, current_time / 1000);
        var _Sinwave = 3 * sin((4 + Numero_Chave * 0.3)  * current_time / 1000);
        
        y = lerp(y, _Player.y - _Player.sprite_height / 2 + _Sinwave, 0.3);	
    }
}

EstadoAbrirPorta = function(){
    x = lerp(x, Porta_Alvo.x, 0.07);
    y = lerp(y, Porta_Alvo.y - Porta_Alvo.sprite_height / 2, 0.07);
    
    var _DistX = abs(x - Porta_Alvo.x);
    
    if(_DistX <= 1){
        instance_destroy();
        
        with (Porta_Alvo) { 
            Estado_Porta = Porta_Abrindo;	
        }
        
    }
}

EstadoChave = EstadoSeguindo_Player;