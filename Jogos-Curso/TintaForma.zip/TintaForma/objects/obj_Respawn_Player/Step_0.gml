/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

part_system_position(Ps, x, y);

Estado_Respawn();
show_debug_message(Dist_X);