/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Cria a Particula
Ps = part_system_create(ps_Respawn);

//Variaveis.
Dist_X = 0;
Dist_Y = 0;
test = 0;

Estado_MoverPlayer = function(){
    var _PosicaoRespawn = point_distance(x, y, Dist_X, Dist_Y);
    
    if (_PosicaoRespawn > 2) {
        x = lerp(x, Dist_X, 0.04);
        y = lerp(y, Dist_Y, 0.04);
        
        camera_set_view_target(view_camera[0], id);
        
    }else {
    	if (instance_exists(obj_Player)) {
        	obj_Player.x = x;
            obj_Player.y = y;
            
            with (obj_Player) {
                camera_set_view_target(view_camera[0], id);
            	Estado_Player = Estado_Parado_Player;
            }
        } 

        instance_destroy();
    }
}

Estado_Respawn = Estado_MoverPlayer;