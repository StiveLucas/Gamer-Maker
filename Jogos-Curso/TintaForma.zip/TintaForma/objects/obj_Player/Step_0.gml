/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Reseta jogo
if (keyboard_check_pressed(vk_enter)) {
	room_restart();
}

//Deixando o jogo em tela cheia.
if (keyboard_check_pressed(vk_f11)) {
    var _Full = window_get_fullscreen();
   
	window_set_fullscreen(!_Full);
}

//Pega os Inputs do Player.
Inputs_Player();

//Fazendo a sprite olhar para direção correta.
Ajustando_Escala();

Movimento_Player();

//Verifica se o Player está tocando o chão.
Checa_Chao();

//Fazo efeito de poder pular após sair de um plataforma ou chão por alguns frames.
Coyote_Jump();

Buffer_Pulo();

if(global.PoderCorrer) Correr_Player();

//Faz o obj voltar sempre para o tamanho original.
EscalaX = lerp(EscalaX, 1, 0.1);
EscalaY = lerp(EscalaY, 1, 0.1);

//Ativa e desliga os debugs.
Ativa_Debug();

//Metodo para abiri as portas
Abre_Porta();

//Estado do Player.
Estado_Player();

//Controla o Alpha pra o Shader sumir com o tempo.
Controlando_Alpha();

//Se o Player ficar preso dentro do obj ele sai.
Removendo_Parede();