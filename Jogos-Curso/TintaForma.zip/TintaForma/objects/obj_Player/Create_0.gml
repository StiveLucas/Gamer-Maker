/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis do Player.

//Estado do Player.
Estado_AtualPlayer = "Parado";

//Velocidade do Player
VelH_Player = 0;
MaxDefinida_VelH_Player = 2
Max_VelH_Player = MaxDefinida_VelH_Player;
Max_VelH_PlayerCorrendo = 4;

VelV_Player = 0;
MaxDefinida_VelY_Player = 4;
Max_VelV_Player = MaxDefinida_VelY_Player;

//Pulo Duplo.
QntdPulosDefinidos = 1;
QntdPulos = QntdPulosDefinidos;

//Coyote
CoyoteTime_Definido = 6;
CoyoteTime = CoyoteTime_Definido;

//Buffer do pulo
TimerDefinido_Buffer = 14;
Timer_Buffer = 0;

//Coner Correction
Coner_Pixels = 10;

//Abrir portas.
TempoDefinido_AbrirPorta = 60 * 5;
Tempo_AbrirPorta = 0;

EscalaX = 1;
EscalaY = 1;

Direcao_Sprite = 1;

//Variável da lista de objtos que quero colidir.
var _TileSet_Chao = layer_tilemap_get_id("tl_Level");
Colisoes = [obj_Parede, _TileSet_Chao];
Gravidade = 0.2;

ListaSprites = [spr_Player_Parando, spr_Player_Idle];
Indece_Sprite = 0;

//Variáveis de controle.
Chao = false;
Chao_Tinta = false;
Tile_Set_Tinta = layer_tilemap_get_id("tl_Tinta");

PoderTinta = global.Power_Tinta;
Estado_Player = noone;

//Itens
QntdChaves = 0;
ChavesCaregadas = [];

//Variáveis do efeito de brilho.
Variaveis_EfeitoCor();

#endregion

#region Debugs do Jogo.

View_Player = noone;

//Mostra os Debugs do jogo.
Roda_Debug = function(){
    
    //Mostra o FPS e desempenho do jogo.
    show_debug_overlay(1);
    
    //Esse cria a view, ele não é obrigatorio mas serve para fazer um metodo de desligar e ligar os debgs
    View_Player = dbg_view("View Player", 1, 50, 100, 300, 200);
    
    var _Ref_VelV = ref_create(id, "VelV_Player");
    
    //Pode acompanhar o valor pelo jogo
    dbg_watch(_Ref_VelV, "VelV_Player: ");
    
    //Esse Serve para fazer teste podendo alterar em jogo
    //Formula: dbg_slider(ref_create(id, "NomeVariavel"), ValorMinimo, ValorMaximo, "Nome que você desejar", QuantidadeSobe);
    dbg_slider(ref_create(id, "Max_VelV_Player"), 0, 10, "Max_VelV_Player:", 0.5);
    dbg_slider(ref_create(id, "Gravidade"), 0, 10, "Gravidade:", 0.1);
    
}

//Ativa e desativa os debugs
Ativa_Debug = function(){
    
    if (!DEBUG_MODE) return;
    
    if (keyboard_check_pressed(vk_tab)) {
        global.Debug = !global.Debug;
        
        if (global.Debug){
            Roda_Debug();
        }else { 
            
            //Desliga tudo
            show_debug_overlay(0);
            
        	if (dbg_view_exists(View_Player)) {
                dbg_view_delete(View_Player);
            }
        }
    }
    
}


#endregion

//Fazendo a sprite olhar para direção correta.
Ajustando_Escala = function(){
    
    if (VelH_Player != 0) {
        //A função sign faz o valor retorna 1 ou -1.
        Direcao_Sprite = sign(VelH_Player);
    }
   
}

#region Estados do Player.

//Troca sprite do Player.
Troca_Arte = function(_Sprite){
    
    if (sprite_index != _Sprite) {
        
    	sprite_index = _Sprite;
        image_index = 0;
    }
}

//Verifica se a Animação acabou para poder trocar.
Acabou_Animacao = function(){
    
    //Troca a animação sem causar erro de animação.
    var _Spd = sprite_get_speed(sprite_index) / FPS;
    
    if (image_index + _Spd >= image_number) {
    	return true;
    }
    
}

//Faz a transição das sprites qnd acaba uma muda para outra.
Transicao_Sprites = function(){
    
    //Definindo sprite dentro de um array
    Troca_Arte(ListaSprites[Indece_Sprite]);
    
    if (Acabou_Animacao()) { 
        var _Qnt = array_length(ListaSprites) - 1;
        
        if (Indece_Sprite < _Qnt) {
            Indece_Sprite++;
        }	
    }
}

//Troca de estado reseta o indece e define as novas sprites do novo estado.
Troca_Estado= function(_Estado, _Lista_Sprites){
    Indece_Sprite = 0;
    Estado_Player = _Estado;
    ListaSprites = _Lista_Sprites;
}

#region Estados Principais

//Esse estado é perfeito para controlar o Player.
Estado_SemControle = function(){
    Transicao_Sprites();
    Estado_AtualPlayer = "Sem Controle";
}

Estado_Parado_Player = function(){
    Estado_AtualPlayer = "Parado";
    
    Transicao_Sprites();
    
    //Método de Movimento.
    AplicaVelocidade_Player();
    
    if (Left != Right) {
        Troca_Estado(Estado_Movendo_Player, [spr_Player_ComecandoCorrer, spr_Player_Correr]);
    }
    
    if (Jump || Timer_Buffer > 0) {
        instance_create_layer(x, y, "ins_Player", obj_ParticulaPulo);
    	Troca_Estado(Estado_Pulando_Player, [spr_Player_InicioPulo, spr_Player_Pulo_Cima]);
    }
    
    if (Tinta && PoderTinta && Chao_Tinta) {
        instance_create_depth(x, y, depth - 1, obj_TintaParticulas_Entrando);
    	Troca_Estado(Estado_EntrandoTinta, [spr_Player_Tinta_Entrar]);
    }
}

Estado_Movendo_Player = function(){
    
    Estado_AtualPlayer = "Movendo";
    
    //Método de Movimento.
    AplicaVelocidade_Player()
    
    //Definindo sprite
    Transicao_Sprites();
    
    //Se a velocidade horizontal do player está zero, então ele ta parado.
    if (VelH_Player == 0 ) {
        Troca_Estado(Estado_Parado_Player, [spr_Player_Parando, spr_Player_Idle]);
    }
    
    if (Jump || VelV_Player != 0) {
        instance_create_layer(x, y, "ins_Player", obj_ParticulaPulo);
    	Troca_Estado(Estado_Pulando_Player, [spr_Player_InicioPulo, spr_Player_Pulo_Cima]);
        
    }
    
    if (Tinta && PoderTinta && Chao_Tinta) {
        instance_create_depth(x, y, depth - 1, obj_TintaParticulas_Entrando);
    	Troca_Estado(Estado_EntrandoTinta, [spr_Player_Tinta_Entrar]);
    }

}

Estado_Pulando_Player = function(){
    Estado_AtualPlayer = "Pulando";
    
    
    //Variável de controle para fazer pulo duplo.
    static _InicioPulo = true;
    
    if (_InicioPulo) {
    	_InicioPulo = false;
        
        //Diminui a quantidades de pulos 
        QntdPulos--;  
    }
    
    //Método de Movimento.
    AplicaVelocidade_Player();
    
    var _Layer = layer_tilemap_get_id("tl_Level")
    var _Colisoes = [obj_Parede, _Layer];
    var _Parar = true;
    if (place_meeting(x, y + sign(VelV_Player), _Colisoes)) {
        
        //Coner Correction para Direta.
        if (VelV_Player < 0) {
            
            if (VelH_Player >= 0) {
            	
               for (var i = 0; i < Coner_Pixels; i++) {
                   
                    var _LivreDireita = !place_meeting(x + i, y + VelV_Player, _Colisoes);
                   
                    if (_LivreDireita) {
                   	    x += i;
                        _Parar = false;
                        break;
                    } 
                }
            }
        }
        
        //Coner Correction para Esquerda.
        if (VelH_Player < 0) {
            
            for (var i = 0; i < Coner_Pixels; i++) {
            	
                var _LivreEsquerda = !place_meeting(x - i, y + VelV_Player, _Colisoes);
                
                if (_LivreEsquerda) {
                	x -= i;
                    _Parar = false;
                    break;
                }
            }
        }
        
        if(_Parar) VelV_Player = 0;
    }
    
    if (VelV_Player < 0) {

        Transicao_Sprites();
        
        //Verifica se o obj existe.
        if (array_contains(Colisoes, obj_Parede_OneWay)) {
            
            ///Deletando o obj no array.
            
            //Função para pegar o index da variavel automaticamente.
            var _Index = array_get_index(Colisoes, obj_Parede_OneWay);
            array_delete(Colisoes, _Index, 1);
        	
        }
        
        //Controla o pulo, se ele soltar o botão o player para de subir.
        if (keyboard_check_released(vk_space)) {
        	VelV_Player *= 0.5;
        }

        
    }else {
        ListaSprites = [spr_Player_InicioQueda, spr_Player_Pulo_Baixo];
        Transicao_Sprites();
        
        if (!place_meeting(x, y, obj_Parede_OneWay)) {
            
            //Verifica se existe o obj parede no array.
            if (!array_contains(Colisoes, obj_Parede_OneWay)) {
                
                //Se não tiver ele addc.
                array_push(Colisoes, obj_Parede_OneWay);	
            }
        }
    }
    
    //Pulo Duplo.
    if (Jump && QntdPulos > 0) {
        ListaSprites = [spr_Player_InicioPulo, spr_Player_Pulo_Cima]
        
        QntdPulos--;
        VelV_Player = -Max_VelV_Player;
    }
    
    //Efeito do Coyote.
    if (CoyoteTime > 0 && Jump) {
        instance_create_layer(x, y, "ins_Player", obj_ParticulaPulo);
        //show_message("aquii")
    	VelV_Player = -Max_VelV_Player;
    }
    
    if (Chao) {
        //Reinicia acontagem dos pulos qnd tocar ao chao.
        _InicioPulo = true;
        if (global.PuloDuplo) {
            QntdPulos = QntdPulosDefinidos + 1; 	
        }else {
        	QntdPulos = QntdPulosDefinidos;
        }
        
        //Esse depth cria a instancia na mesma camada mas pede a profundidade.
        instance_create_depth(x, y, depth - 1, obj_ParticulaPouso);
        
        Efeito_Mola(1.6, 0.8);
    	Troca_Estado(Estado_Parado_Player, [spr_Player_Pouso, spr_Player_Idle]);
    }
    
}

#endregion

#region Estados da Tinta.

Estado_EntrandoTinta = function(){
    //Zera pra não ocorrer bugs de efeitos de outros objetos.
    VelH_Player = 0;
    
    Transicao_Sprites();
    
    if (Acabou_Animacao()) {
        
        //Definindo sprite
        Troca_Estado(Estado_TintaAtiva, [spr_Tinta_Fim, spr_Tinta_Lop]);	
    }
}

Estado_TintaAtiva = function(){
    
    //Muda a mascara de colisão do obj.
    mask_index = spr_Tinta_Lop;
    
    AplicaVelocidade_Player();
    
    Transicao_Sprites();
    
    //Verifica se há tinta na direção que está indo.
    if (!place_meeting(x + (VelH_Player * 9), y + 1, Tile_Set_Tinta)) {
        VelH_Player = 0;
    	
    }
    
    if (Jump) {
    	VelV_Player = 0;
        EscalaX = 1;
        EscalaY = 1;
    }
    
    if (Tinta && !place_meeting(x, y - 10, obj_Parede)) {
        instance_create_depth(x, y, depth - 1, obj_TintaParticulas_Saindo);
        
        //Definindo sprite.
        Troca_Estado(Estado_SaindoTinta, [spr_Tinta_Fim, spr_Player_Idle]);
    
    }
    
}

Estado_SaindoTinta = function(){
    
    //Zera pra não ocorrer bugs de efeitos de outros objetos.
    VelH_Player = 0;
    
    //Definindo sprite.
    Troca_Arte(spr_Player_Tinta_Sair);
    
    //Muda a mascara de colisão do obj.
    mask_index = spr_Player_Idle;
    
    if (Acabou_Animacao() &&  Indece_Sprite < array_length(ListaSprites) - 1) {
        Troca_Estado(Estado_Parado_Player, [spr_Player_Idle]);
    }
    
}

#endregion

#region Estados Power-up

Pegou_PowerUp = function(){
    
    VelH_Player = 0;
    VelV_Player = 0;
    
    Estado_Player = Estado_PowerUp_Inicio;
}

Estado_PowerUp_Inicio = function(){
    
    //Troca a sprite.
    Troca_Arte(spr_Player_Powerup_Inicio);
    
    if (Acabou_Animacao()) {
        PoderTinta = global.Power_Tinta;
    	Estado_Player = Estado_PowerUp_Meio;
    }
    
}

Estado_PowerUp_Meio = function(){
    
    //Troca a sprite.
    Troca_Arte(spr_Player_Powerup_Meio);
    
    
    if (Acabou_Animacao() && !instance_exists(obj_Particula_PowerUp)) {
    	Estado_Player = Estado_PowerUp_Fim;
    }
}

Estado_PowerUp_Fim = function(){
    
    //Troca a sprite.
    Troca_Arte(spr_Player_Powerup_Final);
    
    if (Acabou_Animacao()) {
        VelH_Player = 0;
    	Estado_Player = Estado_Parado_Player;
    }
    
    
}

#endregion


//Estado do Player
Estado_Player = Estado_Parado_Player;

#endregion

#region Variáveis do Inputs
Left = false;
Right = false;
Jump = false;
Tinta = false;
Correr = false;

//Inputs do Player.
Inputs_Player = function(){
    
    //Variaveis de movimentos.
    Left = keyboard_check(ord("A")) || keyboard_check(vk_left);
    Right = keyboard_check(ord("D")) || keyboard_check(vk_right);
    Jump = keyboard_check_pressed(vk_space);
    Tinta = keyboard_check_pressed(ord("X"));
    Correr = keyboard_check(vk_shift);
}

#endregion

#region Métodos do Player

AplicaVelocidade_Player = function(){
   
    //Direção esquerda e direita.
    VelH_Player = (Right - Left) * Max_VelH_Player;
    
    //Se o Player não encosta no chão ele cai
    if(!Chao){
        VelV_Player += Gravidade;
        
    }else{
        
        VelV_Player = 0;
        
        //Arredonda o valor.
        y = round(y);
        
        //Pulo do Player.
        if(Jump || Timer_Buffer > 0){
            Aplica_EfeitoMola();
            VelV_Player = -Max_VelV_Player;
            
            Timer_Buffer = 0;
        }
    }
    
    VelV_Player = clamp(VelV_Player, -Max_VelV_Player, Max_VelV_Player)
    
}

Movimento_Player = function(){
    
    //Usando o move_and_collide para fazer o movimento e verificar a colisão ao mesmo tempo.
    
    //Movimento Horizontal.
    move_and_collide(VelH_Player, 0, Colisoes, 12);
    
    //Movimento Vertical.
    move_and_collide(0, VelV_Player, Colisoes, 10);
}

DefinirPosicao_Room = function(){
    x = global.PosicaoX_Player;
    y = global.PosicaoY_Player;
}

//Verifica se o Player está encostando no Chão.
Checa_Chao = function(){
    Chao = place_meeting(x, y  + 1, Colisoes);
    
    Chao_Tinta = place_meeting(x, y + 1, Tile_Set_Tinta);
    
}

Coyote_Jump = function(){
    
    Checa_Chao();
    
    if (!Chao) {
    	CoyoteTime--;
    }else {
    	CoyoteTime = CoyoteTime_Definido;
    }
}

Buffer_Pulo = function(){
    if (!Chao && Jump) {
    	Timer_Buffer = TimerDefinido_Buffer;
    }
    
    if(Timer_Buffer > 0 && !Chao) Timer_Buffer--;
}

Correr_Player = function(){
    
    if (Correr) {
    	Max_VelH_Player = Max_VelH_PlayerCorrendo;
    }else {
    	Max_VelH_Player = MaxDefinida_VelH_Player;
    }
}

Aplica_EfeitoMola = function(){
    
    EscalaX = 0.3;
    EscalaY = 2;
}

//Metodo para abiri as portas
Abre_Porta = function(){
    
    if(Tempo_AbrirPorta > 0) Tempo_AbrirPorta--;
    
    //O instace_plece serve quando você deseja executar uma ação naquele
    // obj especifico mesmo tendo vários dele repetidos.
    var _Porta = instance_place(x + VelH_Player, y, obj_Porta);
    
    if (_Porta && Tempo_AbrirPorta <= 0) {
    	
        if (QntdChaves > 0 && _Porta.Estado_Porta == _Porta.Porta_Fechada) {
            QntdChaves--;
            
            with (ChavesCaregadas[QntdChaves]) {
            	EstadoChave = EstadoAbrirPorta;
                Porta_Alvo = _Porta;
            }
            Tempo_AbrirPorta = TempoDefinido_AbrirPorta;
        }
    }
}

//Se o Player ficar preso dentro do obj ele sai.
Removendo_Parede = function(){
    if (place_meeting(x, y, obj_Parede_OneWay)) {
    	
        //Busca se tem o obj dentro do Array.
        if (array_contains(Colisoes, obj_Parede_OneWay)) {
            
            //Pega o index e remove do array.
            var _Index = array_get_index(Colisoes, obj_Parede_OneWay);
            array_delete(Colisoes, _Index, 1);
        }
    }
}

#endregion

DefinirPosicao_Room();