/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Desando Player.
draw_sprite_ext(sprite_index, image_index, x, y, EscalaX * Direcao_Sprite, EscalaY, image_angle, image_blend, image_alpha);

//Essa função aplicar o efeito de Shader na sprite, Deixando a cor muito intensa.
Efeito_Cor();

//Isso Desenha a mascara de colisão do obj.
//draw_rectangle(bbox_left, bbox_top, bbox_right, bbox_bottom, true);

//Desenhando dbugs, para melhorar a visibilidade.
draw_text(x, y - 40, Estado_AtualPlayer);