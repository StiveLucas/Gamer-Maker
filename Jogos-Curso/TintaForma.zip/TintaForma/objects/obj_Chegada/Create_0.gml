/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Mudar_Room = function(){
    if (place_meeting(x, y, obj_Player)) {
    	cria_transicao_inicia(Destino);
    }
}