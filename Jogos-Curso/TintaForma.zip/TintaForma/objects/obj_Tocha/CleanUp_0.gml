/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destroi a particula.
part_system_destroy(ps);