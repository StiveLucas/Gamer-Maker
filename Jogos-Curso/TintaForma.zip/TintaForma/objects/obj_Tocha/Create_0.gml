/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Criando meu Sistema de particulas
ps = part_system_create(ps_Brilho_Chama);

//Aqui coloca particulas em todos os objtos
part_system_position(ps, x, y);

layer_sprite_create("ins_Objetos_Level", x, y, sprite_index);