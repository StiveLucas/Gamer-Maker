/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Aqui Gera o brilho da tocha, Não use o draw_self para n desenhar a tocha e usar somente o brilho.

//GPU para dar uma saturação na luz.
gpu_set_blendmode(bm_add);

//Desenhamos o brilho!
draw_sprite_ext(spr_Luz_Tocha, 0, x, y, 0.4, 0.3, 0, c_white, 0.2);
gpu_set_blendmode(bm_normal);