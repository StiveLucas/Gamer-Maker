/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis.
Estado_Dado = noone;

Timer = 60 * Tempo;

Contador_Estados = function(_Estado){
    Timer--;
    
    if (Timer <= 0) {
        Timer = 60 * Tempo;
    	Estado_Dado = _Estado;
    }
}

#region Estados do dado.

Dado_Ativado = function(){
    image_index = 0;
    
    //Trazendo a mascara de colisão ao normal.
    mask_index = spr_Dado;
    
    Contador_Estados(Dado_Mudando_Destivado);
}

Dado_Mudando_Destivado = function(){
    
    if (image_index >= 8) {
    	Estado_Dado = Dado_Desativado;
    }
}

Dado_Mudando_Ativado = function(){
    
    if (image_index <= 8) {
    	Estado_Dado = Dado_Ativado;
    }
}

Dado_Desativado = function(){
    image_index = 8;
    
    //Colocando uma sprite vazia, onde a mascara de colisão dela é precisa para não causar erros.
    mask_index = spr_Vazio;
    
    Contador_Estados(Dado_Mudando_Ativado);
    
}

//Verifica a variavel adicionada no obj para saber se vai iniciar Ativada ou Desativada.
if (Estado_Inicial == "Ativado") {
	Estado_Dado = Dado_Ativado;
}else {
	Estado_Dado = Dado_Desativado;
}


#endregion