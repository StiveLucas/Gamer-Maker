/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_self();


if (!Exibir_Texto) return;
    

//draw_set_font(ft_CaixaTexto);
////Alinhando texto.
//draw_set_halign(0);
//draw_set_valign(0);
//
//draw_text_transformed(_X, _Y, Texto, 0.1, 0.1, 0);
//draw_set_font(-1);

var _Margem = 4;
var _X = x - sprite_width/2 + _Margem;
var _Y = y - sprite_height/2 + _Margem;

//Criando texto com Scribble(Documentos no proprio site no google).
var _Txt = scribble(Texto).starting_format("ft_CaixaTexto", c_white);

//Ajustando escala.
_Txt = _Txt.scale(0.09);

//Ajustando quebra de linha com o tamanho da sprite.
_Txt = _Txt.wrap(sprite_width - _Margem * 2);

_Txt.draw(_X, _Y, typist);