/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis.
Alpha = 0.6;
EscalaX = 2;
EscalaY = 1;

Exibir_Texto = false;
Me_Destruir = false;

Texto = noone;

//Efeitos do Texto.

typist = scribble_typist()
typist.in(0.4, 3);

//Efeito de movimento no texto
scribble_anim_wave(0.6, 0.5, 0.2);

scribble_anim_jitter(1, 1.2, 0.4);

//Abre o texto.
Abertura_Caixa = function(){
    
    if(Me_Destruir) return
    
    //Fazendo um efeito para abrir.
    image_alpha = lerp(image_alpha, Alpha, 0.1);
    image_xscale = lerp(image_xscale, EscalaX, 0.1);
    image_yscale = lerp(image_yscale, EscalaY, 0.1);
    
    //faz ela se movimentar.
    y = lerp(y, ystart -40, 0.07);
    
    if (y < ystart -35) {
    	Exibir_Texto = true;
    }
}

//Destruir a caixa de texto.
Destruir_CaixaTexto = function(){
    if (!Me_Destruir) return;
        
    //Faz um efeito de destrução.
    image_alpha = lerp(image_alpha, 1, 0.1);
    image_xscale = lerp(image_xscale, 0, 0.1);
    image_yscale = lerp(image_yscale, 0, 0.1);
    
    y = lerp(y, ystart - 5, 0.1);
    
    Exibir_Texto = false;
    
    if (image_xscale <= 0.02) {
    	instance_destroy();
    }

}