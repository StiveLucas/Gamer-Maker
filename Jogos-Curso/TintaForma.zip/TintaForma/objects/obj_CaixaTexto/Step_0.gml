/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
Abertura_Caixa();

Destruir_CaixaTexto();