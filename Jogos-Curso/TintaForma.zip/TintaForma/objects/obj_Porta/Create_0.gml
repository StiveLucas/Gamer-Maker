/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Estado_Porta = noone;

///Isso aqui tudo é a particula da fumasa, mas ela está salva
/// na memoria do jogo, ISSO NÃO É UMA INSTANCIA DAS PARTICULAS
/// É SOMENTE OS DADOS DELA.

//ps_Porta
Ps = part_system_create();
part_system_draw_order(Ps, true);

//Emitter
Ptype1 = part_type_create();
part_type_shape(Ptype1, pt_shape_smoke);
part_type_size(Ptype1, 1, 1, 0, 0);
part_type_scale(Ptype1, 0.2, 0.2);
part_type_speed(Ptype1, 0.1, 0.2, 0, 0);
part_type_direction(Ptype1, 80, 100, 0, 0);
part_type_gravity(Ptype1, 0, 270);
part_type_orientation(Ptype1, 0, 0, 0, 0, false);
part_type_colour3(Ptype1, $CCCCCC, $999999, $7F7F7F);
part_type_alpha3(Ptype1, 1, 1, 1);
part_type_blend(Ptype1, false);
part_type_life(Ptype1, 30, 60);

#region Estados da Porta.
Porta_Fechada = function(){
    //Aqui é apenas para deixar a porta sem utilidade, sendo tipo uma pedra, uma porta fechada.
}

Porta_Abrindo = function(){
    y -= 0.2;
    
    TremerTela(3);
    
    //if (Ps == noone) { 
        //Ps =part_system_create(ps_Porta);
        //part_system_position(Ps, x, y);
    //}
    
    //Criando a particulas manualmente para ter mais controles sobre elas
    var _X = x + random_range(-sprite_width / 1.5, sprite_width / 1.5);
    part_particles_create(Ps, _X, ystart - sprite_height, Ptype1, 1);
    
    //Verificando se já subiu 35 pixes
    if (y < ystart - 29) {
        alarm[0] = 60;
    	Estado_Porta = Porta_Abrerta;
        
    }
}

Porta_Abrerta = function(){
    vspeed = 0;
}

#endregion

Estado_Porta = Porta_Fechada;