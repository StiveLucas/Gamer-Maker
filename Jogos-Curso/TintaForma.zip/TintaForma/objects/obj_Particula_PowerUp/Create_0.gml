/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis.
Alvo = noone;
Voltar = false;

Efeito_Particula = function(){
    
    if (Voltar == false) {
        speed -= 0.1;
       
        if (speed <= 0) {
        	Voltar = true;
           
            //Defino a Direção aqui já que só vai rodar uma vez.
            var _X = obj_Player.x + random_range(0.5, 1.5);
            var _Y = obj_Player.y + random_range(-2, -3.5);
            var _Direcao = point_direction(x, y, _X, _Y);
           
            //Pega a posição em tempo Real de outro obj, no caso o Player.
            direction = _Direcao;
        }
        
    }else {
   	    speed += 0.1;
       
        //Aqui Verifica se houve colisão com o Player
        var _Player = instance_place(x, y, obj_Player);
           
        //Se Houve colisão ele executa.
        if (_Player){
               
            //Faz um efeito de mola no player.
            with (obj_Player) {
                var _EscalaX = 1 + random_range(0.1, 0.3);
                var _EscalaY = 1 + random_range(0.1, 0.3);
                
                Efeito_Mola(_EscalaX, _EscalaY);
                
                //Aplica o efeito do shader.
                var _ValorAlpha = random_range(0.5, 0.8);
                Aplicando_EfeitoCor(c_orange, _ValorAlpha);
            }
    
            instance_destroy();
            TremerTela(5);
        }
    }
}