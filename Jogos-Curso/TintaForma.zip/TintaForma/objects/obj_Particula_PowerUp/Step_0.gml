/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Causando um efeito de esticar as particulas.
image_xscale = lerp(image_xscale, speed * 3, 0.1);
image_angle = direction;

Efeito_Particula();

//Caso alguma particula não atinga o player ela vai se destroir.
alarm[0] = FPS * 2;