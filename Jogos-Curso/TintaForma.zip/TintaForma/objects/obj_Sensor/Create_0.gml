/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Sensor = function(_Objeto = obj_Player){
    var _Meu_Metodo = variable_instance_get(id, Metodo_Sensor);
    var _Player = place_meeting(x, y, obj_Player);

   if (_Player) {
       Estado_Sensor = _Meu_Metodo;
   }
}


#region Metodos Automaticos

Parando_Player = function(_Objeto = obj_Player){
    with (_Objeto) {
        VelH_Player = 0;
        Troca_Estado(Estado_SemControle, [spr_Player_Idle]);
    }
}

SalvandoDados_Player = function(){
    
    var _Player = place_meeting(x, y, obj_Player);

    if (_Player) {
        global.PosicaoX_Player = PosicaoX_Player;
        global.PosicaoY_Player = PosicaoY_Player;
        global.RoomAtual = Proxima_Room;
        SalvarJogo();
    }

}

Mover_Player = function(){
    
    var _Player = place_meeting(x, y, obj_Player);
     
    if (_Player) {
        var _PosicaoX = PosicaoX_Player;
        var _PosicaoY = PosicaoY_Player;
        
    	with (obj_Player) {
            Troca_Estado(Estado_SemControle, [spr_Player_Idle]);
            
            if (!instance_exists(obj_Respawn_Player)) {
            	var _Objto_Respawn = instance_create_layer(x, y, layer, obj_Respawn_Player);
                _Objto_Respawn.Dist_X = _PosicaoX;
                _Objto_Respawn.Dist_Y = _PosicaoY;
            }
        }  
    }
}

Estado_Sensor = Sensor;

#endregion