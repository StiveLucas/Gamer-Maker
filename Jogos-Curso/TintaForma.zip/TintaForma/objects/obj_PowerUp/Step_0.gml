/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
if (Alvo) {
    image_xscale -= 0.01;
    image_yscale -= 0.01;
}

if (image_xscale <= 0 && image_yscale <= 0) {
    instance_destroy();
}

//Essa função pegua o valor de uma variavel global. OBS:
// Formula: variable_global_set(<Nome da variável>, <Novo valor dela>);
if(variable_global_get(Habilidade) == true) instance_destroy();


if (part_system_exists(Ps)) {
    
	part_system_position(Ps, x, y);
}

