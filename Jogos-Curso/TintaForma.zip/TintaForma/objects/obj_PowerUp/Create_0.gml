/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis.
Alvo = noone;

//Move o Power-Up para cabeça do Player.
Movendo_PowerUp = function(){
    
    //Se não tiver um alvo, sai do codigo.
    if(!Alvo) return;
        
    x = Alvo.x;
    y = Alvo.y - 35;
}

//Cria um efeito de explosão de particulas quando pegar o Power-Up.
Explosao_Particulas = function(){
    repeat (40) {
        var _Particulas_PowerUp = instance_create_depth(x, y, depth - 4, obj_Particula_PowerUp);
        _Particulas_PowerUp.image_blend = c_orange;
        _Particulas_PowerUp.image_alpha = random_range(0.8, 1);
        _Particulas_PowerUp.speed = random_range(3, 4);
        _Particulas_PowerUp.direction = irandom(359);
    }
}


//Colocando o efeito de particulas do Power-Up.
Ps = part_system_create(ps_PowerUp);