/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Mensagem de morte.
//show_message("Power-Up");

//Destroi o efeito de particulas.
part_system_destroy(Ps);	
