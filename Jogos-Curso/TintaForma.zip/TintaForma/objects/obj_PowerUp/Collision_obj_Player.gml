/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Verifica se existe um alvo.
if (Alvo == noone) {
    other.Pegou_PowerUp();
    Alvo = other;
}

Movendo_PowerUp();
Explosao_Particulas();

//Com o player.
with (obj_Player) {
    
    //Aplica o efeito do shader.
    var _ValorAlpha = random_range(0.5, 0.8);
    Aplicando_EfeitoCor(c_orange, _ValorAlpha);
	
}