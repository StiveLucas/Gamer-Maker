/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Se o player já tem o power-up ele se destroi.
//if(global.Power_Up) instance_destroy();

//Verifica se existe um alvo.
if (Alvo == noone) {
    other.Pegou_PowerUp();
    Alvo = other;
}

Movendo_PowerUp();
Explosao_Particulas();

//Com o player.
with (obj_Player) {
    
    //Aplica o efeito do shader.
    var _ValorAlpha = random_range(0.5, 0.8);
    Aplicando_EfeitoCor(c_orange, _ValorAlpha);
}

//Essa função pegua o valor de uma variavel global e alterá.
// Formula: variable_global_set(<Nome da variável>, <Novo valor dela>);
variable_global_set(Habilidade, true);