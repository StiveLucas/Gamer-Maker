/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destroi o efeito de particulas.
part_system_destroy(Ps);