/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destroi no final da animação.
instance_destroy();