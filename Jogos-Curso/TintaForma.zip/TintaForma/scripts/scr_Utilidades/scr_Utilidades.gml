// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Verifica se o jogo é versão normal ou de dev.
#macro DEBUG_MODE false

#macro Modo_Normal:DEBUG_MODE false
#macro Modo_Debug:DEBUG_MODE true

#macro FPS game_get_speed(gamespeed_fps)

//Debug do jogo.
global.Debug = false;