// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações


//Tremer a tela.
function TremerTela(_Potencia_Tremer){
    
    with (obj_screensheke) {
        Potencia_Tremer = _Potencia_Tremer;
    }
}

#region Efeito de mola.

function Efeito_Mola(_X, _Y){
    EscalaX = _X;
    EscalaY = _Y;
}

#endregion

#region Efeito de Cor

//Create
function Variaveis_EfeitoCor(){
    Controle_Cor = noone;
    Controle_Alpha = 0;
}

function Aplicando_EfeitoCor(_Cor, _ValorAlpha){
    Controle_Cor = _Cor;
    Controle_Alpha = _ValorAlpha;
}

//Step
function Controlando_Alpha(){
    Controle_Alpha = lerp(Controle_Alpha, 0, 0.03);
}

//Draw.

//Essa função aplicar o efeito de Shader na sprite, Deixando a cor muito intensa.
function  Efeito_Cor(){
    
    if (Controle_Alpha < 0) return;
    
    //O Shader Muda da um briho na cor, deixando ela inteiramente da cor desejada.
    shader_set(sh_MudaCor);
    
    //desenha a Sprite de forma detalhada.
    draw_sprite_ext(sprite_index, image_index, x, y, EscalaX * Direcao_Sprite, EscalaY, image_angle, Controle_Cor, Controle_Alpha)
    
    //Sempre reset os shades.
    shader_reset();
}

#endregion