// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Powe_Ups.
global.Power_Tinta = false;
global.PoderCorrer = false;
global.PuloDuplo = false;