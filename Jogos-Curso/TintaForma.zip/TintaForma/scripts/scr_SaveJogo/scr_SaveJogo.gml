// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações


//Variáveis que serão salvas.
global.Save_Escolhido = 3;

global.PosicaoX_Player = 32;
global.PosicaoY_Player = 480;
global.RoomAtual = rm_Hub;

//Função de Salvar o jogo.
function SalvarJogo(){
    
    //Para salvar os dados do jogo, primeiro criamos um struct dos dados que vamos salvar.
    var _Struct_PowerUps = {
        PowerUp_Tinta: global.Power_Tinta,
        PowerUp_Correr: global.PoderCorrer,
        PowerUp_PuloDuplo: global.PuloDuplo
    };
        
    
    var _Struct_InfoPlayer ={
        PosicaoX_Player: global.PosicaoX_Player,
        PosicaoY_Player: global.PosicaoY_Player,
        RoomAtual: global.RoomAtual
    };
    
    var _Structs = {
        PowerUps: _Struct_PowerUps,
        Info_Player: _Struct_InfoPlayer
    };
  
    //Buffer(Nome tecnico mas é o save) de save.
     
    //Aqui criamos o Buffer(metodo de salvar o jogo)
    /*Formula: buffer_create(<Tamanho do save(coloque zero, explico no proximo.)>,
    <Tipo de save(abra o documento desta função para ver os tipos). você está usando
    o buffer_grow que aumenta o tamnho do espaço do jogo conforme o tamanho dele.>, 
    <Alinhamento(coloque 1)>);
    */
    var _MeuBuffer = buffer_create(0, buffer_grow, 1);
  
    //Depois temos que transformar os dados do struct em Texto usando o json_stringify();
    var _Dados = json_stringify(_Structs);
      
    //Aqui você coloca os dadoos dentro do Buffer(save).
    //Formula: buffer_write(<Seu buffer em uma variavel>, <Tipo de buffer>, <Os dados transformados para o Tipo>);
    buffer_write(_MeuBuffer, buffer_string, _Dados);
      
    //Aqui realmente salva na maquina o save.
    //Formula: buffer_save(<Seu buffer em uma variável>, <Nome do save>.json); 
    //Obs: O global.Save_Escolhido serve para poder ter mais de um save.
    buffer_save(_MeuBuffer, "SaveJogo" + string(global.Save_Escolhido) + ".json");
      
    //Não esqueça de deletar no final
    buffer_delete(_MeuBuffer);
}

function CarregarJogo(){

    //Arquivo de Save.
    var _AquivoSave = string("SaveJogo" + string(global.Save_Escolhido) + ".json");
    
    //Com essa função você carrega o Arquivo salvado.
    var _Buffer = buffer_load(_AquivoSave);
    
    //Caso o buffer(Save) não existir o valor vai ser -1 e não teria porque fazero resto, mas não vai travar o jogo.
    if(_Buffer == -1) return;
    
    //Transforma o arquivo salvado em texto.
    var _BufferTexto = buffer_read(_Buffer, buffer_string);
    
    //Transforma o _BufferTexto em arquivo json para a maquina poder ler.
    var _ArquivoJson = json_parse(_BufferTexto);
    
    //Passando todas as pegando todas as informações salvas.
    var _Struct_PowerUps = _ArquivoJson.PowerUps;
    var _Struct_InfoPlayer = _ArquivoJson.Info_Player;
    
    global.Power_Tinta = _Struct_PowerUps.PowerUp_Tinta;
    global.PoderCorrer = _Struct_PowerUps.PowerUp_Correr;
    global.PuloDuplo = _Struct_PowerUps.PowerUp_PuloDuplo;
    
    global.PosicaoX_Player = _Struct_InfoPlayer.PosicaoX_Player;
    global.PosicaoY_Player = _Struct_InfoPlayer.PosicaoY_Player;
    global.RoomAtual = _Struct_InfoPlayer.RoomAtual;
    
    //Não esqueça de deletar no final
    buffer_delete(_Buffer);
}

//Função de apagar save.
function ApagarSave(){
    //Arquivo de Save.
    var _AquivoSave = string("SaveJogo" + string(global.Save_Escolhido) + ".json");
    file_delete(_AquivoSave);
    
    show_message("Jogo apagado");
}