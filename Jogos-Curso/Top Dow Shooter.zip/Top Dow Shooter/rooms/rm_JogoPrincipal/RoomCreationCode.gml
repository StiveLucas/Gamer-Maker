if(!instance_exists(obj_ConfgJogo)){
    instance_create_layer(0, 0, "ins_ConfigJogo", obj_ConfgJogo);
}