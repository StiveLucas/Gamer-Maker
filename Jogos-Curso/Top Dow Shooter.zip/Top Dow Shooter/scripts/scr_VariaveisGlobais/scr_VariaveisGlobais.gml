// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Variáveis Globais do jogo.

global.VidaPlayer = 3;

global.Potencia_EfeitoTremer_Tela = 0;

global.LevelAtual = 1;
global.BonusDificultade = 3;