/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis do Player.

VelH_Player = 0;
MaxVelH_Player = 6;

VelV_Player = 0;
MaxVelV_Player = 6;

Lista_Inimgos = [obj_Inimigo1, obj_Inimigo2];

Verfica_EstadoAtual_Player = 0;

Ativar_MudarSprite = false;
Timer_MudarSprite = 20;
Tempo_MudarSprite = 0;

Timer_Atirar = 20;
Tempo_Atirar = 0;

TimerDefinitivo_Imortalidade_Player = 60 * 2;
Tempo_Imortalidade_Player = 0;
AlphaAfetado_Dano = 0.5;

#endregion

#region Inputs do Player.

Left = false;
Right = false;
Up = false;
Down = false;

Mouse_Left = false;

Inputs_Player = function(){
    Left = keyboard_check(vk_left) || keyboard_check(ord("A"));
    Right = keyboard_check(vk_right) || keyboard_check(ord("D"));
    Up = keyboard_check(vk_up) || keyboard_check(ord("W"));
    Down = keyboard_check(vk_down) || keyboard_check(ord("S"));
    
    Mouse_Left = mouse_check_button(mb_left);
}

#endregion

#region Estados do Player

EstadoParado_Player = function(){
    
    Verfica_EstadoAtual_Player = "Parado";
    
    AplicandoVelocidade_Player();
    Direcao_Player();
    
    if (VelH_Player != 0 || VelV_Player != 0) {
    	Estado_Player = EstadoMovimento_Player;
    }
    
    if(Mouse_Left && Tempo_Atirar > Timer_Atirar) Estado_Player = EstadoTiro_Player;
}

EstadoMovimento_Player = function(){
    
    Verfica_EstadoAtual_Player = "Movimento";
    
    AplicandoVelocidade_Player();
    Direcao_Player();
    
    if (VelH_Player == 0) {
    	Estado_Player = EstadoParado_Player;
    }
    
    if(Mouse_Left && Tempo_Atirar > Timer_Atirar) Estado_Player = EstadoTiro_Player;
        
}

EstadoTiro_Player = function(){
    
    Verfica_EstadoAtual_Player = "Atirando";
    
    sprite_index = spr_Player_Atirando;
    Ativar_MudarSprite = true;
    
    AplicandoVelocidade_Player();
    Direcao_Player()
    
    var _Tiro_Player = instance_create_layer(x, y, "ins_Player", obj_Tiro_Player);
    _Tiro_Player.Direcao_Tiro = image_angle;
     
    Tempo_Atirar = 0;
    
    Estado_Player = EstadoParado_Player;
}

Estado_Player = EstadoParado_Player;

#endregion

#region Métodos do Player.

Direcao_Player = function(){
    
    //Fazendo Player olhar o player para onde o mouse está.
    var _DirecaoPlayer = point_direction(x, y, mouse_x, mouse_y);
    image_angle = _DirecaoPlayer;
}

Times_Player = function(){
    
    //Timer para poder atirar.
    Tempo_Atirar++;
    
    //Timer para mudar a sprite Player.
    if(Ativar_MudarSprite){ 
        Tempo_MudarSprite++;
        
        if(Tempo_MudarSprite >= Timer_MudarSprite){
            sprite_index = spr_Player_Movimentando;
            Tempo_MudarSprite = 0;
            Ativar_MudarSprite = false
        }
    }
}

AplicandoVelocidade_Player = function(){
    VelH_Player = (Right - Left) * MaxVelH_Player;
    VelV_Player = (Down - Up) * MaxVelV_Player;
}

Movimentacao_Player = function(){
    
    //Impedindo do player sair da tela.
    x = clamp(x, sprite_width/2, room_width - sprite_width/2);
    
    y = clamp(y, sprite_height, room_height - sprite_height);
    
    //Movementação Horizontal.
    move_and_collide(VelH_Player, 0, obj_ConfgJogo);
    
    //Movimentação Vertical.
    move_and_collide(0, VelV_Player, obj_ConfgJogo);
    
    //Controla a animação do player.
    if (VelH_Player != 0 || VelV_Player != 0) image_speed = 1; else image_speed = 0;
        
}

PerderVida = function(){
    
    if(Tempo_Imortalidade_Player <= TimerDefinitivo_Imortalidade_Player) Tempo_Imortalidade_Player++;
    
    var _EncostouInimigo = place_meeting(x, y, Lista_Inimgos);
    
    if (_EncostouInimigo && Tempo_Imortalidade_Player >= TimerDefinitivo_Imortalidade_Player) {
    	global.VidaPlayer--;
        
        if(global.VidaPlayer <= 0){
            game_restart();
        }
        
        Tempo_Imortalidade_Player = 0;
    }
    
    //Faz efeito de picar quando o Player levar dano.
    if (Tempo_Imortalidade_Player < TimerDefinitivo_Imortalidade_Player) {
    	image_alpha += AlphaAfetado_Dano;
        
        if(image_alpha > 1) AlphaAfetado_Dano *= -1;
            
        if(image_alpha < 0) AlphaAfetado_Dano *= -1;
            
    }else {
    	image_alpha = 1;
    }
}

#endregion

AtivandoFuncoes_Player = function(){
    
    //Funcão que pega os Inputs do Player.
    Inputs_Player();
    
    Movimentacao_Player();
    
    Times_Player();
    
    PerderVida();
}