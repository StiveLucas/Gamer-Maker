/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

AtivandoFuncoes_Player();
Estado_Player();

if (keyboard_check_pressed(vk_enter)) {
	game_restart();
}