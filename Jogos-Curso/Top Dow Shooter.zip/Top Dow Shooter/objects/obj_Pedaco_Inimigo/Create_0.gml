/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

randomise();

//Variáveis do Pedaço do Inimigo.
Vel_Pedaco = random(29);
Direcao_Pedado = random(359);

//Controla se pode dar dano.
Dar_Dano = false

//Configurando o Pedaço do Inimigo.
Config_Pedaco_Inimigo = function(){
    direction = Direcao_Pedado
    image_angle = direction;
    speed = Vel_Pedaco;
    image_xscale = 0.5;
    image_yscale = image_xscale;
}

Colidindo_Inimigos = function(){
    
    if(!Dar_Dano) return;
    
    var _EncostouInimigo = instance_place(x, y, obj_InimigoPai);
    
    if (_EncostouInimigo && speed > 0.2) {
    	with (_EncostouInimigo) {
        	Vida_Inimigo -= 3;
        }
        
        instance_destroy();
    }
}

Destruindo_Pedacos = function(){
    
    speed = lerp(speed, 0, 0.09);
    image_alpha = lerp(image_alpha, 0, 0.03);
    
    if(image_alpha <= 0) instance_destroy();
}

Config_Pedaco_Inimigo();