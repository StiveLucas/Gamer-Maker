/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
draw_self();
draw_text(x, y - 20, Tempo_BotarOvo);