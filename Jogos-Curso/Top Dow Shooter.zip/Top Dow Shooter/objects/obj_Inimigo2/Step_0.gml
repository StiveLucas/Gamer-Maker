/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Funcoes_InimigoPai_Ativadas();

Ativando_FuncoesInimigo();