/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Herda tudo do objeto Pai.
event_inherited();

randomise();

#region Variáveis do Inimigo.
Vida_Inimigo = 8;

VelMin_Inimigo = 0.3;
VelMax_Inimigo = 0.6;

Direcao_Inimigo = random(359);

DistanciaDeteccao = 0;

TimerDefinitivo_MudarDirecao = 60 * random_range(3, 6);
Timer_MudarDirecao = TimerDefinitivo_MudarDirecao;
Tempo_MudarDirecao = 0;

TimerDefinitivo_BotarOvo = 60 * random_range(9, 14);
Timer_BotarOvo = TimerDefinitivo_BotarOvo;
Tempo_BotarOvo = 0;

EfeitoTremer_TomarDano_Inimigo = 10;
EfeitoTremer_Morte_Inimigo = 70;

#endregion

ConfigInicial_Inimigo();

#region Métodos do Inimigo.

GerandoOvo = function(){
    
    Tempo_BotarOvo++;
    
    if (Tempo_BotarOvo >= Timer_BotarOvo) {
    	
        //Coloca o ovo.
        var _OvoInimigo = instance_create_layer(x, y, "ins_Inimigos", obj_OvoInimigos);
        _OvoInimigo.direction = direction;
        _OvoInimigo.speed = random_range(0.3, 0.8);
        
        Tempo_BotarOvo = 0;
    }
}

#endregion

Ativando_FuncoesInimigo = function(){
    
    GerandoOvo();
}