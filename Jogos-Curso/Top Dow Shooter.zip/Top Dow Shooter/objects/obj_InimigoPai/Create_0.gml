/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

randomise();

#region Variáveis do Inimigo.
Vida_Inimigo = 0;

VelMin_Inimigo = 0;
VelMax_Inimigo = 0;

Direcao_Inimigo = 0;

DistanciaDeteccao = 0;

TimerDefinitivo_MudarDirecao = 0;
Timer_MudarDirecao = TimerDefinitivo_MudarDirecao;
Tempo_MudarDirecao = 0;

EfeitoTremer_TomarDano_Inimigo = 0;
EfeitoTremer_Morte_Inimigo = 0;

#endregion

#region Métodos do Inimigo.

ImpedirSairTela = function(){
    
    //Faz o Inimigo olhar para a direção que esta andando.
    image_angle = lerp(image_angle, direction, 0.05);
    
    if (y < 0 + sprite_height || y > room_height - sprite_height) vspeed *= -1;
        
    if(x < 0 + sprite_width || x >= room_width - sprite_width) hspeed *= -1;
}

MudarDirecao_Inimigo = function(){
    
    Tempo_MudarDirecao++;
    
    if (Tempo_MudarDirecao >= Timer_MudarDirecao) {
        speed = random_range(VelMin_Inimigo, VelMax_Inimigo);
    	direction = irandom(359);
        Timer_MudarDirecao = TimerDefinitivo_MudarDirecao;
        Tempo_MudarDirecao = 0;
    }
}

PerderVida_Inimigo = function(){
    if (instance_exists(obj_Tiro_Player) || instance_exists(obj_Player)) {
        //o instance_place verifica quem colidiu.
        var _Tiro_Player = instance_place(x, y, obj_Tiro_Player);
        
    	if (_Tiro_Player) { 
            
            var _Impacto_TiroPlayer = instance_create_depth(x, y, 2, obj_Impacto_TiroPlayer);
        	Vida_Inimigo -= obj_Tiro_Player.Dano_Tiro;
            global.Potencia_EfeitoTremer_Tela = EfeitoTremer_TomarDano_Inimigo;
            instance_destroy(_Tiro_Player);
            
            repeat (irandom(6) + 1) {
            	var _Pedaco_Inimigo = instance_create_depth(x, y, 1, obj_Pedaco_Inimigo);
            }
        }
        
        if(Vida_Inimigo <= 0){
                
            repeat (irandom_range(8, 15)) {
            	var _Pedaco_Inimigo = instance_create_depth(x, y, 1, obj_Pedaco_Inimigo);
                _Pedaco_Inimigo.Dar_Dano = true;
            }
            
            var _Rastro = instance_create_depth(x, y, 1, obj_Rastro_Inimigo);
            
            instance_destroy();
            global.Potencia_EfeitoTremer_Tela = EfeitoTremer_Morte_Inimigo;
        }
    }
}

#endregion

ConfigInicial_Inimigo = function(){
    
    image_speed = 0.3;
    
    direction = Direcao_Inimigo
    image_angle = Direcao_Inimigo;
    speed = random_range(VelMin_Inimigo, VelMax_Inimigo);
}

Funcoes_InimigoPai_Ativadas = function(){
    
    ImpedirSairTela();
    MudarDirecao_Inimigo();
    PerderVida_Inimigo();
}