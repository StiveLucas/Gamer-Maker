/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Função do inimigo pai.
Funcoes_InimigoPai_Ativadas();

Ativando_Funcoes_Inimigo1();