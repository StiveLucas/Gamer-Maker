/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Herda tudo do objeto Pai.
event_inherited();

randomise();

#region Variáveis do Inimigo.
Vida_Inimigo = 3;

VelMin_Inimigo = 1;
VelMax_Inimigo = 2;

Direcao_Inimigo = random(359);

DistanciaDeteccao = 220;

TimerDefinitivo_MudarDirecao = 60 * irandom_range(3, 7);
Timer_MudarDirecao = TimerDefinitivo_MudarDirecao;
Tempo_MudarDirecao = 0;

EfeitoTremer_TomarDano_Inimigo = 10;
EfeitoTremer_Morte_Inimigo = 40;

//Configuração do inimigo.
ConfigInicial_Inimigo();

#endregion

#region Métodos do Inimigo.

Detectando_Player = function(){
    if(!instance_exists(obj_Player)) return;
        
    var _Distancia_Player = point_distance(x, y, obj_Player.x, obj_Player.y);
    
    if (_Distancia_Player <= DistanciaDeteccao) {
    	var _Pocisao_Player = point_direction(x, y, obj_Player.x, obj_Player.y);
        
        direction = _Pocisao_Player;
    }
}

#endregion

ConfigInicial_Inimigo();

Ativando_Funcoes_Inimigo1 = function(){
    Detectando_Player();
}