/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Se destroi.
instance_destroy();

//Criando o inimigo 1.
instance_create_layer(x, y, "ins_Inimigos", obj_Inimigo1);