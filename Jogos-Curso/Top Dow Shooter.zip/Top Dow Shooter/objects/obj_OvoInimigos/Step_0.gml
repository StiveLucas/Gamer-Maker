/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
ConfigInicial_OvoInimigo();

speed = lerp(speed, 0, 0.01);