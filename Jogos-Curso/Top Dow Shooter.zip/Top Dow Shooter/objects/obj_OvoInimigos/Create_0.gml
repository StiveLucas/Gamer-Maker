/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

ConfigInicial_OvoInimigo = function(){
    
    image_speed = 0.02;
}