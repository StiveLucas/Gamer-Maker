/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Destruindo_Rastro = function(){
    image_alpha = lerp(image_alpha, 0, 0.01);
    
    if(image_alpha <= 0) instance_destroy();
}