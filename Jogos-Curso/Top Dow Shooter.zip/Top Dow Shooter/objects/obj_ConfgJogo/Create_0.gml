/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

randomise();

//Lista de Inimigos
Lista_Inimigos = [obj_Inimigo1];

Iniciando_Jogo = function(){
    
    //Alterando sempre as dimenções da room
    var _Width = irandom_range(2000, 4000);
    var _Hidth = irandom_range(2000, 4000);
    
    room_width = _Width;
    room_height = _Hidth;
    
    //Alterando Backgraud do jogo.
    var _IdLayer = layer_get_id("Bg");
    var _IdBackgraund = layer_background_get_id(_IdLayer);
    
    var _BGs = choose(spr_Bg1, spr_Bg2, spr_Bg3);
    
    layer_background_sprite(_IdBackgraund, _BGs);
    
    if (!instance_exists(obj_Screenshake)) instance_create_layer(0, 0, "ins_ConfigJogo", obj_Screenshake);
    
    if (!instance_exists(obj_Player)){
        
        var _PosicaoX_Aleatoria = irandom(room_width) - sprite_width;
        var _PosicaoY_Aleatoria = irandom(room_height) - sprite_height;
        
        instance_create_layer(_PosicaoX_Aleatoria, _PosicaoY_Aleatoria, "ins_Player", obj_Player);
    }
    
    
    Gerando_Inimigos();
}

Gerando_Inimigos = function(){
    
    var _Qntd = irandom_range(4, 8) + (global.LevelAtual * global.BonusDificultade);
    
    repeat (_Qntd) {
    	
        var _PosicaoX_Aleatoria = irandom(room_width) - sprite_width;
        var _PosicaoY_Aleatoria = irandom(room_height) - sprite_height;
    
        var _Inimigo = instance_create_layer(_PosicaoX_Aleatoria, _PosicaoY_Aleatoria, "ins_Inimigos", obj_Inimigo2);
        
        //Destruindo o inimigo se nascer muito proximo ao player.
        if (instance_exists(obj_Inimigo2) && instance_exists(obj_Player)) { 
            var _Distancia = point_distance(_Inimigo.x, _Inimigo.y, obj_Player.x, obj_Player.y);
        
            if (_Distancia < 400) { 
                instance_destroy(_Inimigo, false);
            }
        }
    }
}

Passando_Level = function(){
    
    //Verifica quantos inimigos vivos tem.
    var _Inimigo2Vivos = instance_number(obj_Inimigo2);
    var _Inimigo1Vivos = instance_number(obj_Inimigo1);
    
    if(_Inimigo1Vivos <= 0 && _Inimigo2Vivos <= 0){
        
        global.LevelAtual++;
        game_restart();
    }
}



Iniciando_Jogo()