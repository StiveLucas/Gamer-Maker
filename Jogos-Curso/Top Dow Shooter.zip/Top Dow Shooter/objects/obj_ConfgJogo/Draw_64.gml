/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_text(x + 10, y + 20, "Vida: " + string(global.VidaPlayer));
draw_text(x + 10, y + 50, "Level Atual: " + string(global.LevelAtual));


///Apontando a Seta para o inimigo mais proximo.

if (instance_exists(obj_Player) && instance_exists(obj_InimigoPai)) {
    
    with (obj_Player) {
        
        //Essa função entrega o inimigo mais proximo.
    	var _ImimigoProximo = instance_nearest(x, y, obj_InimigoPai);
        
        var _Direcao = point_direction(x, y, _ImimigoProximo.x, _ImimigoProximo.y);
        
        var _Width = camera_get_view_width(view_camera[0]);
        
        draw_sprite_ext(spr_Seta, 0, _Width - 150, 100, 1, 1, _Direcao, c_white, 1);
    }
}