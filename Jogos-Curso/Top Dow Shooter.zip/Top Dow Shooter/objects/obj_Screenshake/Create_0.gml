/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Tremer_Tela = function(){
    
    view_xport[0] = random_range(global.Potencia_EfeitoTremer_Tela, -global.Potencia_EfeitoTremer_Tela);
    view_yport[0] = random_range(global.Potencia_EfeitoTremer_Tela, -global.Potencia_EfeitoTremer_Tela);
    
    if (global.Potencia_EfeitoTremer_Tela > 0) {
    	global.Potencia_EfeitoTremer_Tela *= 0.8;
        
        if(global.Potencia_EfeitoTremer_Tela <= 0.1) global.Potencia_EfeitoTremer_Tela = 0;
    }
}