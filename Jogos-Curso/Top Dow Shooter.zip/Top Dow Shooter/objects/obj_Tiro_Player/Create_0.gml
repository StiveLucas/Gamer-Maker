/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis do Tiro.
Dano_Tiro = 1;
Velcidade_Tiro = 12;
Direcao_Tiro = 0;

image_xscale = 1.6;
image_yscale = image_xscale;

Timer_Destruir = 60 * 3;
Tempo_Destruir = 0;

#endregion

Config_Tiro = function(){
    
    Tempo_Destruir++;
    
    speed = Velcidade_Tiro;
    direction = Direcao_Tiro;
    
    if(Tempo_Destruir >= Timer_Destruir) instance_destroy();
        
    if(!instance_exists(obj_Player)) return;
        
    //Se atingir um inimigo ele se destroi e cria a particula de impacto.    
    var _Inimigos = place_meeting(x, y, obj_Player.Lista_Inimgos);
    if(_Inimigos){
        instance_destroy();
        instance_create_depth(x, y, 2, obj_Impacto_TiroPlayer);
    }
}

Efeito_Tiro = function(){
    
    draw_self();
    
    gpu_set_blendmode(bm_add);
    
    //gpu_set_blendmode(bm_add);
    draw_sprite_ext(spr_EfeitoTiro, 0, x, y, image_xscale * 1.4, image_yscale, image_angle, c_white, image_alpha);
    
    gpu_set_blendmode(bm_normal);
    
    image_xscale = lerp(image_xscale, 0.5, 0.08);
    image_yscale = image_xscale;
}

