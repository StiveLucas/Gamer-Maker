// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Variáveis da Bola
global.Velocidade_Bola = 5
global.Direcao_Bola = 0

//Variáveis da Barra
global.Velocidade_Barra = 4

//Variáveis da Barra Ia
global.Ia_Ligada = false
global.Velocidade_BarraIa = 3

//Pontuação
global.Pontuacao_Player1 = 0
global.Pontuacao_Player2 = 0