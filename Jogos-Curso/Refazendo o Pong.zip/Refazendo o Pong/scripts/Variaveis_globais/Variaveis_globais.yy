{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "Variaveis_globais",
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
}