/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if( x > 880){
	global.Pontuacao_Player1 += 1;
	x =xstart
	y =ystart

	speed = 0
	
	alarm[0] = 60
}

if(x < 15){
	room_goto(rm_GoalPlayer_um)
	
	y = global.Direcao_Bola
	speed = global.Velocidade_Bola
	
	/*
	global.Pontuacao_Player2 += 1;
	x =xstart
	y =ystart

	speed = 0
	
	alarm[0] = 60
	*/
}

//Reiniciando o jogo
global.Velocidade_Barra = 4
global.Velocidade_BarraIa = 3
global.Velocidade_Bola = 5