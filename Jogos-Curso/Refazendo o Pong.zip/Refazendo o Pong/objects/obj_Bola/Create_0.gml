/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Velocidade da bola no começo
speed = 0;

//Delay de 1 segundo para a bola se mexer
alarm[0] = 60;