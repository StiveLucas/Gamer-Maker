 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Direção da Bola
global.Direcao_Bola = vspeed


show_debug_message("Bola: "+ string(speed))