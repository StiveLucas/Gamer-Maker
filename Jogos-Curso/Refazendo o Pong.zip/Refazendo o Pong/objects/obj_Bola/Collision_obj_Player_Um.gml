 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Colando fisica na bola.
move_bounce_solid(true);

//Movimento da bola Aumenta
global.Velocidade_Bola += 0.50;