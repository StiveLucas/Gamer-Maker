/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deixando a direção da bola aleatória
randomize();
direction = choose(12, 83, 116, 213, 322);

speed = global.Velocidade_Bola