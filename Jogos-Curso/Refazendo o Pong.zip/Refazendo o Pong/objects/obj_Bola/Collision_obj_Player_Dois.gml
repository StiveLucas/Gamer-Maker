 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deixando a fisica de colisão 
move_bounce_solid(true)

//Movimento da bola Aumenta
global.Velocidade_Bola += 0.50;