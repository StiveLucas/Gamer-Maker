 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
draw_self()

//Sistema de Vitori
if(!global.Ia_Ligada){
	if(global.Pontuacao_Player1 >= 3){
		draw_text(375, 190, "Player 1 Venceu!")
	
	}else if(global.Pontuacao_Player2 >= 3){
		draw_text(375, 190, "Player 2 Venceu!")
	}
}else{
	if(global.Pontuacao_Player1 >= 3){
		draw_text(380, 190, "Player 1 Venceu!")
	
	}else if(global.Pontuacao_Player2 >= 3){
		draw_text(380, 190, "IA Venceu!")
	}
}