/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Configurndo imagem
image_speed = 0;
image_index = 0;