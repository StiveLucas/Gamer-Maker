/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_self();

if(global.Ia_Ligada){
	if(btn_Modo){
		draw_text(540, 297, "Modo:");
		draw_text(555, y, "IA");
	}else{
		draw_text(255, 310, "Jogar");
	}
}else{
	if(btn_Modo){
		draw_text(540, 297, "Modo:");
		draw_text(516, y, "2 Jogadores");
	}else{
		draw_text(255, 310, "Jogar");
	}
}