/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Mudando cor do botão.
image_index = 1;