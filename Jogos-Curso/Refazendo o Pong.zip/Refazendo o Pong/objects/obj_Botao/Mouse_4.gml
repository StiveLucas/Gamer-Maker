/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if(iniciar_Jogo){
	room_goto_next()
}else{
	global.Ia_Ligada = !global.Ia_Ligada
}