/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Mudando a cor
image_index = 0;