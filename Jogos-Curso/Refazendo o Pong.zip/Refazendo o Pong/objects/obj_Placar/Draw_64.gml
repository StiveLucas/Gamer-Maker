  /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

draw_text(x, y, "Placar: " + string(global.Pontuacao_Player1) + ":" + string(global.Pontuacao_Player2))