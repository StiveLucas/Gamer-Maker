/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definindo sprite
image_speed = 0;
image_index = 1;

//Velocidade da Barra
vel_barra = global.Velocidade_Barra;

//Variáveis da IA
vel_Ia = global.Velocidade_BarraIa;