/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

vel_Ia = global.Velocidade_BarraIa;

if(global.Ia_Ligada){
	vspeed = global.Direcao_Bola;
	if(vspeed >= vel_Ia){
		vspeed = vel_Ia;
	}
}

show_debug_message("IA: "+ string(vel_Ia))