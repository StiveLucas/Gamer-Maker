 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Movimentação da barra
if(!global.Ia_Ligada){
	direction = 90;
	vspeed = vel_barra;
}
