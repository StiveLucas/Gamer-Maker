 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deixando a barra parada
if(!global.Ia_Ligada){
	vspeed = 0
}