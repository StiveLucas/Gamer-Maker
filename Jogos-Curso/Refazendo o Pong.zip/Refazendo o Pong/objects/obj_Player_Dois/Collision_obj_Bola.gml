 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Aumentando Velocidade da Barra
if(global.Ia_Ligada){
	global.Velocidade_BarraIa += 0.25;
}else{
	global.Velocidade_Barra += 0.25;
}