/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Fazendo a barra parar.
vspeed = 0;