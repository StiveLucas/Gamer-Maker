/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definir movimentação
direction = 90;
vspeed = vel_barra;