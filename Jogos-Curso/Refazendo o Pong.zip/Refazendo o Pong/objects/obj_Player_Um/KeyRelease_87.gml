/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Fazendo a Barra ficar parada
vspeed = 0;