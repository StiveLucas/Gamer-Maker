/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

global.Velocidade_Barra += 0.25