/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definir a sptite da barra
image_speed = 0;
image_index = 0;

//Velocidade da Barra
vel_barra = global.Velocidade_Barra