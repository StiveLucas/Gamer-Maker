 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Definindo movimentação
direction = 90
vspeed = -vel_barra