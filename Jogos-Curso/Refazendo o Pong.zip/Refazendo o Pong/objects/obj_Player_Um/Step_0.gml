/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Deixando rolar
vel_barra = global.Velocidade_Barra

show_debug_message("Player 1: "+ string(vel_barra))