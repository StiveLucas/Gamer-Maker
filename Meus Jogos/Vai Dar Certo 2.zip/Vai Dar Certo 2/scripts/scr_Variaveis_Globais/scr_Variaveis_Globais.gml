// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

///Variáveis das Salas
global.Tamanho_Sala = 1200;
global.TamanhoCelula_Sala = 0;
global.SalasCriadas = 0;

global.ListaSalas_SpawmPlayer_Fase1 = 0;