

// Essa funcão cuida da colisão do objeto com a grid inteira do jogo.
function Colisao_Grid_Jogo(_X, _Y, _Tamanho_Sala, _TamanhoCelula_Sala, _Velocidade_Objeto){
    
    var _PosicaoX_Tiro_GridMapa = _X div _Tamanho_Sala;
    var _PosicaoY_Tiro_GridMapa = _Y div _Tamanho_Sala;
    
    var _OffsetX = _PosicaoX_Tiro_GridMapa * _Tamanho_Sala;
    var _OffsetY = _PosicaoY_Tiro_GridMapa * _Tamanho_Sala;
    
    var _VelX = lengthdir_x(_Velocidade_Objeto, direction);
    var _VelY = lengthdir_y(_Velocidade_Objeto, direction);
    
    var _DirecaoX_Tiro_Inimigo = sign(_VelX);
    var _DirecaoY_Tiro_Inimigo = sign(_VelY);
    
    var _PosicaoX_Tiro_GridSala = ((_X + ((sprite_width/3) * _DirecaoX_Tiro_Inimigo)) - _OffsetX) div _TamanhoCelula_Sala;
    var _PosicaoY_Tiro_GridSala = ((_Y + ((sprite_height/3) * _DirecaoY_Tiro_Inimigo)) - _OffsetY) div _TamanhoCelula_Sala;
    
    var _Futura_PosicaoX_Tiro_GridSala = ((_X + (((sprite_width/3) + _TamanhoCelula_Sala) * _DirecaoX_Tiro_Inimigo) - _OffsetX)) div _TamanhoCelula_Sala;
    var _Futura_PosicaoY_Tiro_GridSala = ((_Y + (((sprite_height/3) + _TamanhoCelula_Sala) * _DirecaoY_Tiro_Inimigo) - _OffsetY)) div _TamanhoCelula_Sala;
    
    var _Sala_Atual = global.Grid_Mapa[# _PosicaoX_Tiro_GridMapa, _PosicaoY_Tiro_GridMapa].Grid_Sala;
    
    if (_Sala_Atual[# _Futura_PosicaoX_Tiro_GridSala, _PosicaoY_Tiro_GridSala] == 2) {
    	instance_destroy();
    }
    
    if (_Sala_Atual[# _PosicaoX_Tiro_GridSala, _Futura_PosicaoY_Tiro_GridSala] == 2) {
    	instance_destroy();
    }
}