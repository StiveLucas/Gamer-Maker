
//Colocar Parede em volta da sala toda.
function Indice_ParedeEmVolta_Sala(_DS_Grid_Sala, _I, _J, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Indice_Parede_Sala){
    
    //Ordem das Paredes.
    
    //Cima e Baixo
    if ((_I <= _Largura_Grid_Sala && _J <= 0 + _Grossura_Parede) || (_I <= _Largura_Grid_Sala && _J >= _Altura_Grid_Sala - _Grossura_Parede)) {
    	_DS_Grid_Sala[# _I, _J] = _Indice_Parede_Sala;
    }
    
    //Esquerda e Direita.
    if ((_I <= 0 + _Grossura_Parede && _J <= _Altura_Grid_Sala) || (_I >= _Largura_Grid_Sala - _Grossura_Parede && _J <= _Altura_Grid_Sala)) {
    	_DS_Grid_Sala[# _I, _J] = _Indice_Parede_Sala;
    }
}

//Gera as saidas da sala.
function Gerar_Saidas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, _I, _J, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Tamanho_Saida, _Indece_Saida_Sala){
    
    //Esquerda.
    if (global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Saidas_Sala.Esquerda == true) {
        if ((_I <= 0 + _Grossura_Parede) && (_J >= (_Altura_Grid_Sala/2) - _Tamanho_Saida && _J <= (_Altura_Grid_Sala/2))){
            _DS_Grid_Sala[# _I, _J] = _Indece_Saida_Sala;
        }
    }
    
    //Direita.
    if (global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Saidas_Sala.Direita == true) {
        if ((_I >= _Largura_Grid_Sala - _Grossura_Parede) && (_J >= (_Altura_Grid_Sala/2) - _Tamanho_Saida && _J <= (_Altura_Grid_Sala/2))){ 
            _DS_Grid_Sala[# _I, _J] = _Indece_Saida_Sala;
        }
    }
                            
    //Cima.
    if (global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Saidas_Sala.Cima == true) {
        if ((_I <= (_Largura_Grid_Sala/2) + _Tamanho_Saida && _I >= (_Largura_Grid_Sala/2)) && (_J <= 0 + _Grossura_Parede)) {
        	_DS_Grid_Sala[# _I, _J] = _Indece_Saida_Sala;
        }
    }
    
    //Baixo.
    if (global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Saidas_Sala.Baixo == true) {
        if ((_I <= (_Largura_Grid_Sala/2) + _Tamanho_Saida && _I >= (_Largura_Grid_Sala/2)) && (_J >= _Altura_Grid_Sala - _Grossura_Parede)) {
        	_DS_Grid_Sala[# _I, _J] = _Indece_Saida_Sala;
        }
    }
}