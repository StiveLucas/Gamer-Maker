//Efeito de tremer tela do jogo.
function Efeito_TremerTela(__Valor_Potencia){
    
    if(!instance_exists(obj_ScreensSheke)) instance_create_layer(x, y, "ins_Config_Jogo", obj_ScreensSheke);
        
    with (obj_ScreensSheke) {
    	
        Potencia_TremeTela = __Valor_Potencia;
    }
}