
//Sistema para poder trocar entre a versão do jogo.
#macro DEBUG_MODE false
#macro Modo_Jogo:DEBUG_MODE false
#macro Modo_Debug:DEBUG_MODE true  

global.Debug_Contador = 0;

//Deubgs das Grids das salas
global.Debug_Exibir_Grid_Salas = false;