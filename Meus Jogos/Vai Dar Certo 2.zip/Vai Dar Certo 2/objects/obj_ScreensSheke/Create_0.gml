#region Variáveis

Potencia_TremeTela = 0;

#endregion

Efeito_Tremer_Tela = function(){
    
    //Faz o efeito de tremer a tela
    if (Potencia_TremeTela != 0) {
        var _X = irandom_range(Potencia_TremeTela, -Potencia_TremeTela);
        var _Y = irandom_range(Potencia_TremeTela, -Potencia_TremeTela);
        
        view_set_xport(view_current, _X);	
        view_set_yport(view_current, _Y);	
    }else {
        //Quando a potencia_tremeTela for 0 ele ajeita tudo pra ficar normal.
    	Potencia_TremeTela = 0
        
        view_set_xport(view_current, 0);	
        view_set_yport(view_current, 0);	
    }
    
    //Faz o efeito sempre a ir para zero.
    Potencia_TremeTela = lerp(Potencia_TremeTela, 0, 0.1);
}