//Deixando tudo Aléatorio.
randomise();

#region Variáveis.

Vida_Inimigo = 4;
Vel_Inimigo = 3;

Dano_Inimigo = 1;

DirecaoX_Sprite_Inimigo = 0;
DirecaoY_Sprite_Inimigo = 0;

Tipo_Movimentecao = "";

//Debugs
Debug_ExibirPosicao_Inimigo_Grid_Sala = false;

//Cooldown do inimigo.
TempoDefinido_Parado_Inimigo = 60 * irandom_range(2, 4);
Tempo_Parado_Inimigo = 0;

TempoDefinido_Movimento_Inimigo = 60 * irandom_range(3, 5);
Tempo_Movimento_Inimigo = 0;

TempoDefinido_TiroSimples_Inimigo = 60 * irandom_range(2, 3);
Tempo_TiroSimples_Inimigo = 0;

//Controles.
Direcao_Escolhida_Inimigo = false;

#endregion

#region Estados do Inimigo.

EstadoParado_Inimigo = function(){
    
    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    
    speed = 0;
    
    TiroSimples_Inimigo();
    
    //Controle do tempo de ficar parado.
    if(TempoDefinido_Parado_Inimigo > Tempo_Parado_Inimigo) Tempo_Parado_Inimigo++;
        
    if (Tempo_Parado_Inimigo >= TempoDefinido_Parado_Inimigo) {
        Tempo_Movimento_Inimigo = 0;
    	Estado_Inimigo = EstadoMovimento_Inimigo;
    }
    
}

EstadoMovimento_Inimigo = function(){
    
    if(!instance_exists(obj_Player)) return;
    
    //Movimentacão e Colisão.
    MovimentacaoColisao_Inimigo();
    
    TiroSimples_Inimigo();
    
    //Controle do tempo de ficar se movendo.
    if(TempoDefinido_Movimento_Inimigo > Tempo_Movimento_Inimigo) Tempo_Movimento_Inimigo++;
        
    if (Tempo_Movimento_Inimigo >= TempoDefinido_Movimento_Inimigo) {
        Tempo_Parado_Inimigo = 0;
        Direcao_Escolhida_Inimigo = false;
        
    	Estado_Inimigo = EstadoParado_Inimigo;
    }
}

Estado_Inimigo = EstadoMovimento_Inimigo;

#endregion

#region Métodos.

//Movimentacão e Colisão do inimigo
MovimentacaoColisao_Inimigo = function(){
    
    var _Player = obj_Player;
    var _Posicao_Player = point_direction(x, y, _Player.x, _Player.y);
    
    //Escolhendo a movimentacão do inimigo.
    if (!Direcao_Escolhida_Inimigo) {
        randomise();
        
        Tipo_Movimentecao = choose("Aléatoria", "Aléatoria", "Direcão_Player");
        
        switch (Tipo_Movimentecao) {
        	
            case "Aléatoria":
                direction = irandom(359);
            break;
        
            case "Direcão_Player":
                direction = _Posicao_Player;
            break;    
        }
        
        Direcao_Escolhida_Inimigo = true;	
    }
    
    var _VelX = lengthdir_x(Vel_Inimigo, direction);
    var _VelY = lengthdir_y(Vel_Inimigo, direction);
    
    DirecaoX_Sprite_Inimigo = sign(_VelX);
    DirecaoY_Sprite_Inimigo = sign(_VelY);
    
    var _PosicaoX_Inimigo_Grid_Mapa = x div global.Tamanho_Sala;
    var _PosicaoY_Inimigo_Grid_Mapa = y div global.Tamanho_Sala;
    
    // 1. Onde a sala atual começa no mundo em pixels:
    var _Sala_OffsetX = _PosicaoX_Inimigo_Grid_Mapa * global.Tamanho_Sala;
    var _Sala_OffsetY = _PosicaoY_Inimigo_Grid_Mapa * global.Tamanho_Sala;
    
    var _PosicaoX_Inimigo_Grid_Sala = ((x + ((sprite_width/3) * DirecaoX_Sprite_Inimigo)) - _Sala_OffsetX) div global.TamanhoCelula_Sala;
    var _PosicaoY_Inimigo_Grid_Sala = ((y + ((sprite_height/3) * DirecaoY_Sprite_Inimigo)) - _Sala_OffsetY) div global.TamanhoCelula_Sala;
    
    var _Futura_PosicaoX_Inimigo_Grid_Sala = ((x + (((sprite_width/3) + global.TamanhoCelula_Sala) * DirecaoX_Sprite_Inimigo)) - _Sala_OffsetX) div global.TamanhoCelula_Sala;
    var _Futura_PosicaoY_Inimigo_Grid_Sala = ((y + (((sprite_height/3) + global.TamanhoCelula_Sala) * DirecaoY_Sprite_Inimigo)) - _Sala_OffsetY) div global.TamanhoCelula_Sala;
    
    var _Atual_Grid_Sala = global.Grid_Mapa[# _PosicaoX_Inimigo_Grid_Mapa, _PosicaoY_Inimigo_Grid_Mapa].Grid_Sala;
    
    //Debug para ver Posicão do inimigo na grid da sala.
    if (DEBUG_MODE && Debug_ExibirPosicao_Inimigo_Grid_Sala) {
        show_debug_message("PosicaoX_GridSala_Atual: " + string(_PosicaoX_Inimigo_Grid_Sala));
        show_debug_message("PosicaoY_GridSala_Atual: " + string(_PosicaoY_Inimigo_Grid_Sala));
        show_debug_message("Futura_PosicaoX_GridSala: " + string(_Futura_PosicaoX_Inimigo_Grid_Sala));
        show_debug_message("Futura_PosicaoY_GridSala: " + string(_Futura_PosicaoY_Inimigo_Grid_Sala));
        show_debug_message("//////////////////////////////////////////////////////////////////////////////");
        show_debug_message("Futura_Grid x: " + string(_Atual_Grid_Sala[# _Futura_PosicaoX_Inimigo_Grid_Sala, _PosicaoY_Inimigo_Grid_Sala]));
        show_debug_message("Futura_Grid x: " + string(_Atual_Grid_Sala[# _Futura_PosicaoX_Inimigo_Grid_Sala, _PosicaoY_Inimigo_Grid_Sala]));
        show_debug_message("----------------------------");
    }
    
    ///Controla a colisão do inimigo com as paredes.
    if (_Atual_Grid_Sala[# _Futura_PosicaoX_Inimigo_Grid_Sala, _PosicaoY_Inimigo_Grid_Sala] != 2) {
    	   speed = Vel_Inimigo
    }else {
    	speed = 0;
    }
    
    if (_Atual_Grid_Sala[# _PosicaoX_Inimigo_Grid_Sala, _Futura_PosicaoY_Inimigo_Grid_Sala] != 2) {
    	   speed = Vel_Inimigo
    }else {
    	speed = 0;
    }
}

TiroSimples_Inimigo = function(){
    
    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    var _Direcao_Player = point_direction(x, y, _Player.x, _Player.y);
    
    if(TempoDefinido_TiroSimples_Inimigo > Tempo_TiroSimples_Inimigo) Tempo_TiroSimples_Inimigo++;
        
    if (Tempo_TiroSimples_Inimigo >= TempoDefinido_TiroSimples_Inimigo) {
    	
        var _Tiro_Inimigo = instance_create_layer(x, y, "ins_Tiros_Inimigos", obj_Tiro_Inimigo);
        _Tiro_Inimigo.direction = _Direcao_Player;
        _Tiro_Inimigo.Dano_Tiro_Inimigo = Dano_Inimigo;
        
        Tempo_TiroSimples_Inimigo = 0;
    }
}

Morte_Inimigo = function(){
    
    Vida_Inimigo--;
    
    if (Vida_Inimigo <= 0) {
    	instance_destroy(); 
    }
}

#endregion