Config_Tiro();
Acertou_Inimigo();