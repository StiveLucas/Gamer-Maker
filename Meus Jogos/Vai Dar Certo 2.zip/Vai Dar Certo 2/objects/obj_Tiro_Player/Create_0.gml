#region Variáveis.

Sprite_Tiro = 0;
Vel_Tiro = 0;
Dano_Tiro = 0;

#endregion

Config_Tiro = function(){
    
    sprite_index = Sprite_Tiro;
    speed = Vel_Tiro;
    
    Colisao_Grid_Jogo(x, y, global.Tamanho_Sala, global.TamanhoCelula_Sala, Vel_Tiro);
}

Acertou_Inimigo = function(){
    
    var _Acertou_Inimigo = instance_place(x, y, global.Inimigos_Jogo);
    
    if (_Acertou_Inimigo) {
    	instance_destroy();
        
        with (_Acertou_Inimigo) {
        	Morte_Inimigo();
        }
    }
}

Config_Tiro();