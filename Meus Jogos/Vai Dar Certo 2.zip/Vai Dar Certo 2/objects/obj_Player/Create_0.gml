/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis.

Cheat = true;

Estado_Player_Debug = "";

Vida_Player = 300;
VelDefinida_Player = 28;
Vel_Player = VelDefinida_Player;

Direcao_Sprite = 1;

#region Controles Debugs.
Debug_ExibirDirecao_Player = false;
Debug_ExibirPosicao_Player_Grid_Sala = false;
Debug_ExibirPosicao_Player_Grid_Mapa = false;

#endregion

#endregion
  
#region Inputs do Player.

//Movimentação.
Left = false;
Right = false;
Up = false;
Down = false;

//Tiro.
Shot = false;

Inputs_Player = function(){

    Left = keyboard_check(ord("A")) || keyboard_check(vk_left);
    Right = keyboard_check(ord("D")) || keyboard_check(vk_right);
    Up = keyboard_check(ord("W")) || keyboard_check(vk_up);
    Down = keyboard_check(ord("S")) || keyboard_check(vk_down);
    
    Shot = mouse_check_button(mb_left);
}

#endregion

#region Estados do Player.

Estado_SemControle_Player = function(){
    
    
}

EstadoParado_Player = function(){
    
    Estado_Player_Debug = "Parado";
    
    //Vai para o estado de movimento.
    if (Left || Right || Up || Down) {
    	Estado_Player = EstadoMovimento_Player;
    }
}

EstadoMovimento_Player = function(){
    
    Estado_Player_Debug = "Movimento"
    
    //Permite o player se mover
    AplicandoVelocidade_Player();
    
    //Vai para o estado de parado.
    if (Vel_Player == 0) {
    	Estado_Player = EstadoParado_Player;
    }
}

EstadoMorto_Player = function(){
    
    Estado_Player_Debug = "Morto";
    
    image_blend = c_red;
}

Estado_Player = EstadoParado_Player;

#endregion

#region Métodos do Player.

//Movimentação e Colisão do Player.
AplicandoVelocidade_Player = function(){
    
    if ((Left xor Right) || (Up xor Down)) {
        
        Vel_Player = VelDefinida_Player;
    	
        //Aqui faz o Sistema de Movimentacao.
        var _Direcao_Player = point_direction(0, 0, (Right - Left), (Down - Up));
        var _VelX = lengthdir_x(Vel_Player, _Direcao_Player);
        var _VelY = lengthdir_y(Vel_Player, _Direcao_Player);
        
        //Pegua a direcao que ele esta indo.
        DirecaoX_Sprite = sign(_VelX);
        DirecaoY_Sprite = sign(_VelY);
        
        if (DEBUG_MODE && Debug_ExibirDirecao_Player) {
        	show_debug_message("DireçãoX_Sprite: " + string(DirecaoX_Sprite));
            show_debug_message("DireçãoY_Sprite: " + string(DirecaoY_Sprite));
            show_debug_message("----------------------");
        }
        
        ///Sistema de Colisao e Movimentacao(Só irá se Movimentar se não for colidir com nehuma parede).
        var _PosicaoX_Player_Grid_Mapa = (x + ((sprite_width / 3)) * DirecaoX_Sprite) div global.Tamanho_Sala;
        var _PosicaoY_Player_Grid_Mapa = (y + ((sprite_height / 3)) * DirecaoY_Sprite) div global.Tamanho_Sala;
        
        if (DEBUG_MODE && Debug_ExibirPosicao_Player_Grid_Mapa) { 
            show_debug_message("PosicaoX_GridMapa_Atual: " + string(_PosicaoX_Player_Grid_Mapa));
            show_debug_message("PosicaoY_GridMapa_Atual: " + string(_PosicaoY_Player_Grid_Mapa));
        }
        
        // 1. Onde a sala atual começa no mundo em pixels:
        var _Sala_OffsetX = _PosicaoX_Player_Grid_Mapa * global.Tamanho_Sala;
        var _Sala_OffsetY = _PosicaoY_Player_Grid_Mapa * global.Tamanho_Sala;
        
        var _PosicaoX_Player_Sala = ((x + ((sprite_width / 3) * DirecaoX_Sprite)) - _Sala_OffsetX) div global.TamanhoCelula_Sala;
        var _PosicaoY_Player_Sala = ((y + ((sprite_height / 3) * DirecaoY_Sprite)) - _Sala_OffsetY) div global.TamanhoCelula_Sala;
        
        var _FuturaPosicaoX_Player_Sala = ((x + (((sprite_width / 3) + global.TamanhoCelula_Sala) * DirecaoX_Sprite)) - _Sala_OffsetX) div global.TamanhoCelula_Sala;
        var _FuturaPosicaoY_Player_Sala = ((y + (((sprite_height / 3) + global.TamanhoCelula_Sala) * DirecaoY_Sprite)) - _Sala_OffsetY) div global.TamanhoCelula_Sala;
        
        if (DEBUG_MODE && Debug_ExibirPosicao_Player_Grid_Sala) {
            show_debug_message("PosicaoX_GridSala_Atual: " + string(_PosicaoX_Player_Sala));
            show_debug_message("PosicaoY_GridSala_Atual: " + string(_PosicaoY_Player_Sala));
            show_debug_message("Futura_PosicaoX_GridSala: " + string(_FuturaPosicaoX_Player_Sala));
            show_debug_message("Futura_PosicaoY_GridSala: " + string(_FuturaPosicaoY_Player_Sala));
            show_debug_message("----------------------------");
        }

        //Sala atual onde o Player está.
        var _Atual_Grid_Sala = global.Grid_Mapa[# _PosicaoX_Player_Grid_Mapa, _PosicaoY_Player_Grid_Mapa].Grid_Sala;
        
        if (Vel_Player != 0) { 
            
            if (_Atual_Grid_Sala[# _FuturaPosicaoX_Player_Sala, _PosicaoY_Player_Sala] != 2 || Cheat) {
                x += _VelX;    	
            }   
             
            if (_Atual_Grid_Sala[# _PosicaoX_Player_Sala, _FuturaPosicaoY_Player_Sala] != 2 || Cheat) { 
                y += _VelY;
            }  
        }
        
    }else {
    	Vel_Player = 0;
    }
}

Morte_Player = function(_Dano_Inimigo){
    
    Vida_Player -= _Dano_Inimigo;
    
    Efeito_TremerTela(20);
    
    if (Vida_Player <= 0) {
        Efeito_TremerTela(80);
    	Estado_Player = EstadoMorto_Player;
    }
}

#endregion

#region Outros.

if(!instance_exists(obj_Arma_Player)) instance_create_layer(x, y, "ins_Player", obj_Arma_Player);

#endregion

AtivandoFuncoes_Player = function(){
    
    Inputs_Player();
}