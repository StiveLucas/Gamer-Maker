/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis.

Estado_Player_Debug = "";

VelDefinida_Player = 50
Vel_Player = VelDefinida_Player;

Direcao_Sprite = 1;

Colisoes_Player = [tls_ParedeTeste];

#endregion

#region Inputs do Player.

//Movimentação
Left = false;
Right = false;
Up = false;
Down = false;

Inputs_Player = function(){

    Left = keyboard_check(ord("A")) || keyboard_check(vk_left);
    Right = keyboard_check(ord("D")) || keyboard_check(vk_right);
    Up = keyboard_check(ord("W")) || keyboard_check(vk_up);
    Down = keyboard_check(ord("S")) || keyboard_check(vk_down);
}

#endregion

#region Estados do Player.

EstadoParado_Player = function(){
    
    Estado_Player_Debug = "Parado";
    
    if (Vel_Player != 0) {
    	Estado_Player = EstadoMovimento_Player;
    }
}

EstadoMovimento_Player = function(){
    
    Estado_Player_Debug = "Movimento"
    
    if (Vel_Player == 0) {
    	Estado_Player = EstadoParado_Player;
    }
}

Estado_Player = EstadoParado_Player;

#endregion

#region Métodos do Player.

//Movimentação e Colisão do Player.
AplicandoVelocidade_Player = function(){
    
    if ((Left xor Right) || (Up xor Down)) {
        
        Vel_Player = VelDefinida_Player;
    	
        var _Direcao_Player = point_direction(0, 0, (Right - Left), (Down - Up));
        var _VelX = lengthdir_x(Vel_Player, _Direcao_Player);
        var _VelY = lengthdir_y(Vel_Player, _Direcao_Player);
                                      
        if (Vel_Player != 0) {       
            x += _VelX;
            y += _VelY;
        }
    }else {
    	Vel_Player = 0;
    }
}

#endregion

AtivandoFuncoes_Player = function(){
    
    Inputs_Player();
    
    //Faz o Player se mover.
    AplicandoVelocidade_Player();
}