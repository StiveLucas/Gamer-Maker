//#region Variaveis.

EscalaX_Sensor = 0;
EscalaY_Sensor = 0;

//Posicoes do Sensor na Grid do Mapa.
PosicaoX_Sensor_Grid_Sala = x div global.Tamanho_Sala; 
PosicaoY_Sensor_Grid_Sala = y div global.Tamanho_Sala;

I_Grid_Mapa = 0;
J_Grid_Mapa = 0;

//Controles.
Player_Encostou = false;

#endregion
global.Debug_Contador++
show_debug_message(global.Debug_Contador)
#region Metodos

Config_Sensor = function(){
    
    image_xscale = EscalaX_Sensor;
    image_yscale = EscalaY_Sensor;
}

Inicializar_Sala_Atual = function(){
    
    if(!instance_exists(obj_Player) || !instance_exists(obj_Criar_Sala)) return;
        
    var _Cria_Sala = obj_Criar_Sala;
    var _Player = obj_Player;
    
    var _PosicaoX_Player_Grid_Mapa = _Player.x div global.Tamanho_Sala;
    var _PosicaoY_Player_Grid_Mapa = _Player.y div global.Tamanho_Sala;
    var _Player_Encostou = place_empty(x, y, obj_Player);
    
    if (_Player_Encostou) {
        Player_Encostou = true;
    }
    
    if (Player_Encostou) {
        
        if (_PosicaoX_Player_Grid_Mapa == PosicaoX_Sensor_Grid_Sala && _PosicaoY_Player_Grid_Mapa == PosicaoY_Sensor_Grid_Sala) { 
            var _PosicaoX_Mapa = I_Grid_Mapa * global.Tamanho_Sala;
            var _PosicaoY_Mapa = J_Grid_Mapa * global.Tamanho_Sala;
            
            _Cria_Sala.Salas_Prontas.Salas_Fase1.Salas_Inimigas.SalaInimiga_1.Inicializar_Objetos_Sala(global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa);
            instance_destroy();
        }
    }
}

#endregion

Ativando_Funcoes_Sensor = function(){
    
    Config_Sensor();
    
    Inicializar_Sala_Atual();
}