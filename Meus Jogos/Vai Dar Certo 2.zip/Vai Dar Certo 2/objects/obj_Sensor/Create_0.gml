#region Variaveis.


#endregion
global.Debug_Contador++
show_debug_message(global.Debug_Contador)
#region Metodos

Inicializar_Sala_Atual = function(){
    
    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    
    var _Player_Encostou = place_empty(x, y, _Player);
    
    if (_Player_Encostou) {

    }
}

#endregion