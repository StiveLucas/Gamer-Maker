#region Variaveis.

//Tamanhos do Sensor.
EscalaX_Sensor = 0;
EscalaY_Sensor = 0;

Id_Sensor_Atual = 0;

//Controles.
Player_Encostou_Sensor = false;

//Cooldown.
TempoDefinitivo_Inicializar_Sala = 60 * 2;
Tempo_Inicializar_Sala = 0;

#endregion

#region Metodos

Config_Sensor = function(){
    
    //Ajusta o tamanho do sensor.
    image_xscale = EscalaX_Sensor;
    image_yscale = EscalaY_Sensor;
}

Inicializar_Sala_Atual = function(){
    
    if(!instance_exists(obj_Player) || !instance_exists(obj_Criar_Sala)) return;
        
    var _Cria_Sala = obj_Criar_Sala;
    var _Player = obj_Player;
    
    //Posicão do Sensor na grid do Mapa.
    var _PosicaoX_Sensor_Grid_Mapa = x div global.Tamanho_Sala;
    var _PosicaoY_Sensor_Grid_Mapa = y div global.Tamanho_Sala;
    
    var _I_Grid_Mapa = _PosicaoX_Sensor_Grid_Mapa;
    var _J_Grid_Mapa = _PosicaoY_Sensor_Grid_Mapa;
    
    //Pegando a posicao do player na grid do mapa.
    var _PosicaoX_Player_Grid_Mapa = _Player.x div global.Tamanho_Sala;
    var _PosicaoY_Player_Grid_Mapa = _Player.y div global.Tamanho_Sala;
    
    //Verifica se o player encostou no sensor
    var _Player_Encostou = instance_place(x, y, obj_Player);
    
    //Se o player encostar, ele executa o sensor.
    if (_Player_Encostou) {
        Player_Encostou_Sensor = true;
        Id_Sensor_Atual = id;
    }
    
    if (Player_Encostou_Sensor && id == Id_Sensor_Atual) {
        
        if(TempoDefinitivo_Inicializar_Sala > Tempo_Inicializar_Sala) Tempo_Inicializar_Sala++;
    	
        var _PosicaoX_Grid_Mapa = _I_Grid_Mapa * global.Tamanho_Sala;
        var _PosicaoY_Grid_Mapa = _J_Grid_Mapa * global.Tamanho_Sala;
            
        if (Tempo_Inicializar_Sala >= TempoDefinitivo_Inicializar_Sala) {
            
            //Verificar se a sala é a de invorcar inimigos.
            if (global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Sala_Grid == _Cria_Sala.Salas_Prontas.Salas_Fase1.Salas_Inimigas.SalaInimiga_1) {
                _Cria_Sala.Salas_Prontas.Salas_Fase1.Salas_Inimigas.SalaInimiga_1.Inicializar_Objetos_Sala(global.Grid_Mapa[# _I_Grid_Mapa, _J_Grid_Mapa].Grid_Sala, _PosicaoX_Grid_Mapa, _PosicaoY_Grid_Mapa, _I_Grid_Mapa, _J_Grid_Mapa);	
            }
              
            with (obj_Sensor) {
                
                //Calculo a posicao dos sensores novamente para não usarem a posicao do sensor tocado pelo player.
                _PosicaoX_Sensor_Grid_Mapa = x div global.Tamanho_Sala;
                _PosicaoY_Sensor_Grid_Mapa = y div global.Tamanho_Sala;
              
                _I_Grid_Mapa = _PosicaoX_Sensor_Grid_Mapa;
                _J_Grid_Mapa = _PosicaoY_Sensor_Grid_Mapa;
              
                //No final destroi todos os sensores da sala.
                if(_I_Grid_Mapa == _PosicaoX_Player_Grid_Mapa && _J_Grid_Mapa == _PosicaoY_Player_Grid_Mapa) instance_destroy();	
            }	
            
            Player_Encostou_Sensor = false;
        }
    }
}

#endregion

Ativando_Funcoes_Sensor = function(){
    
    Config_Sensor();
    
    Inicializar_Sala_Atual();
}