#region Variaveis.

//Tamanhos do Sensor.
EscalaX_Sensor = 0;
EscalaY_Sensor = 0;

//Posicoes do Sensor na Grid do Mapa.
PosicaoX_Sensor_Grid_Sala = x div global.Tamanho_Sala; 
PosicaoY_Sensor_Grid_Sala = y div global.Tamanho_Sala;

//Posicão na grid do mapa.
I_Grid_Mapa = 0;
J_Grid_Mapa = 0;

#endregion

#region Metodos

Config_Sensor = function(){
    
    //Ajusta o tamanho do sensor.
    image_xscale = EscalaX_Sensor;
    image_yscale = EscalaY_Sensor;
}

Inicializar_Sala_Atual = function(){
    
    if(!instance_exists(obj_Player) || !instance_exists(obj_Criar_Sala)) return;
        
    var _Cria_Sala = obj_Criar_Sala;
    var _Player = obj_Player;
    
    //Pegando a posicao do player na grid do mapa.
    var _PosicaoX_Player_Grid_Mapa = _Player.x div global.Tamanho_Sala;
    var _PosicaoY_Player_Grid_Mapa = _Player.y div global.Tamanho_Sala;
    
    //Verifica se o player encostou no sensor
    var _Player_Encostou = place_meeting(x, y, obj_Player);
    
    //Se o player encostar, ele executa o sensor.
    if (_Player_Encostou) {
        
        var _PosicaoX_Mapa = I_Grid_Mapa * global.Tamanho_Sala;
        var _PosicaoY_Mapa = J_Grid_Mapa * global.Tamanho_Sala;
        
        var _PosicaoX_Grid_Mapa = _PosicaoX_Mapa div global.Tamanho_Sala;
        var _PosicaoY_Grid_Mapa = _PosicaoY_Mapa div global.Tamanho_Sala;
            
        //Verificar se a sala é a de invorcar inimigos.
        if (global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Sala_Grid == _Cria_Sala.Salas_Prontas.Salas_Fase1.Salas_Inimigas.SalaInimiga_1) {
            _Cria_Sala.Salas_Prontas.Salas_Fase1.Salas_Inimigas.SalaInimiga_1.Inicializar_Objetos_Sala(global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, I_Grid_Mapa, J_Grid_Mapa);	
        }
            
        //No final destroi todos os sensores da sala.
        with (obj_Sensor) {
            if(_PosicaoX_Player_Grid_Mapa == I_Grid_Mapa && _PosicaoY_Player_Grid_Mapa == J_Grid_Mapa) instance_destroy();
        }
    }
}

#endregion

Ativando_Funcoes_Sensor = function(){
    
    Config_Sensor();
    
    Inicializar_Sala_Atual();
}