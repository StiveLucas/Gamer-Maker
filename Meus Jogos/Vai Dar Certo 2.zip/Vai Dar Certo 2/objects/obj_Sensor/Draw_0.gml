draw_self();

draw_text(x, y, I_Grid_Mapa);
draw_text(x + 10, y, J_Grid_Mapa);