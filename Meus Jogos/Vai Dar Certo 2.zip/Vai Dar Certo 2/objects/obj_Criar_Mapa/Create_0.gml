/// @description Inserir descrição aqui  
// Você pode escrever seu código neste editor

#region Variáveis

TamanhoCelula_Mapa = global.Tamanho_Sala;
Colunas_Mapa = 9;
Linhas_Mapa = 9;

room_width = Colunas_Mapa * global.Tamanho_Sala;
room_height = Linhas_Mapa * global.Tamanho_Sala;

// Debug no Console do GameMaker (sem travar a tela com popups)
if (DEBUG_MODE) {
    show_debug_message("Largura da Room: " + string(room_width));
    show_debug_message("Grid_Mapa: " + string(Colunas_Mapa) + "x" + string(Linhas_Mapa));
}

//Criando a ds_grid do Mapa.
global.Grid_Mapa = ds_grid_create(Colunas_Mapa, Linhas_Mapa);

//Definindo um valor para a ds_grid inteira.
ds_grid_clear(global.Grid_Mapa, 0);

#endregion

Configuracao_Mapa = function(){

}

Desenhando_Mapa = function(){

        
    //Pegando as Dimensôes da camera.
    var _Camera_X = camera_get_view_x(view_camera[0]);
    var _Camera_Y = camera_get_view_y(view_camera[0]);
    var _Camera_W = camera_get_view_width(view_camera[0]);
    var _Camera_H = camera_get_view_height(view_camera[0]);
    
    ///Convertendo os Valores da posicao das cameras em Celulas.
    var _Coluna_Inicial = _Camera_X div global.Tamanho_Sala;
    var _Coluna_Final = (_Camera_X + _Camera_W) div global.Tamanho_Sala;
    
    var _Linha_Inicial = _Camera_Y div global.Tamanho_Sala;
    var _Linha_Final = (_Camera_Y + _Camera_H) div global.Tamanho_Sala;
    
    show_debug_message("Coluna Inicial: " + string(_Coluna_Inicial));
    
    for (var i = _Coluna_Inicial; i <= _Coluna_Final; i++) {
    	
        for (var j = _Linha_Inicial; j <= _Linha_Final; j++) {
        	
            if ((i >= 0 && i < Colunas_Mapa) && (j >= 0 && j < Linhas_Mapa)) {
            	
                var _X1, _Y1, _X2, _Y2, _Cor;
                
                _X1 = i * global.Tamanho_Sala;
                _Y1 = j * global.Tamanho_Sala;
                _X2 = (i + 1) * global.Tamanho_Sala;
                _Y2 = (j + 1) * global.Tamanho_Sala;
                
                _Cor = c_purple;
                draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, false);
                
                _Cor = c_black;
                draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
            }
        }
    }
}