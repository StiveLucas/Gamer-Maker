#region Variaveis.

Estado_Porta_Debug = "";

Posicao_Porta = "";

EscalaX_Porta = 0
EscalaY_Porta = 0

I_Grid_Mapa = x div global.Tamanho_Sala;
J_Grid_Mapa = y div global.Tamanho_Sala;

EspacamentoX_Sensor = 70;
EspacamentoY_Sensor = 70;

//Controles.
Gerar_Sensores = false;
Player_Escostou_Porta = false;

//Cooldowns
TempoDefinido_Passar_Porta = 60 * 2;
Tempo_Passar_Porta = 0;

#endregion

#region Estados da Porta.

EstadoTrancada_Porta = function(){
    
    Estado_Porta_Debug = "Trancada";
    
    image_index = 0;
    
    Condicoes_Porta_Trancada();
}

EstadoDestrancada_Porta = function(){
    
    Estado_Porta_Debug = "Destrancada";
    
    image_index = 1;
    
    Condicoes_Porta_Trancada();
    
}

Estado_Porta = EstadoTrancada_Porta;

#endregion

#region Metodos.

Config_Porta = function(){
    
    switch (Posicao_Porta) {
    
        case "Direita / Esquerda":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _SensorDireita = instance_create_layer(x - EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _SensorDireita.EscalaX_Sensor = EscalaX_Porta;
                _SensorDireita.EscalaY_Sensor = EscalaY_Porta;
                
                var _SensorEsquerda = instance_create_layer(x + EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _SensorEsquerda.EscalaX_Sensor = EscalaX_Porta;
                _SensorEsquerda.EscalaY_Sensor = EscalaY_Porta;
                
                Gerar_Sensores = true;
            }
            
        break;
        
        case "Cima / Baixo":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
            	var _SensorCima = instance_create_layer(x, y - EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _SensorCima.EscalaX_Sensor = EscalaX_Porta;
                _SensorCima.EscalaY_Sensor = EscalaY_Porta;
                
                var _SensorBaixo = instance_create_layer(x, y + EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _SensorBaixo.EscalaX_Sensor = EscalaX_Porta;
                _SensorBaixo.EscalaY_Sensor = EscalaY_Porta;
                
                Gerar_Sensores = true;
            }
            
        break;
    }
    
    image_speed = 0;
    
    image_xscale = EscalaX_Porta;
    image_yscale = EscalaY_Porta;
}

Condicoes_Porta_Trancada = function(){
    
    if(!instance_exists(obj_Criar_Sala)) instance_create_layer(0, 0, "ins_Config_Jogo", obj_Criar_Sala);
        
    var _Criar_Sala = obj_Criar_Sala;
    
    var _Largura_Grid_Mapa = ds_grid_width(global.Grid_Mapa) - 1;
    var _Altura_Grid_Mapa = ds_grid_height(global.Grid_Mapa) - 1;
    
    var _SalaAtual_TemInimigos = false;
    var _SalaDireita_TemInimigos = false;
    var _SalaEsquerda_TemInimigos = false;
    var _SalaCima_TemInimigos = false;
    var _SalaBaixo_TemInimigos = false;
    
    //Sala onde a porta estar.
    if (global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Quantidade_Inimigos_Sala > 0) {
        _SalaAtual_TemInimigos = true;
    }
    
    //Verifica a sala Direita.
    if (_Largura_Grid_Mapa >= I_Grid_Mapa + 1 && global.Grid_Mapa[# I_Grid_Mapa + 1, J_Grid_Mapa].Sala_Grid != _Criar_Sala.Salas_Prontas.Salas_Fase1.Sala_Preenchimento) {
        if (global.Grid_Mapa[# I_Grid_Mapa + 1, J_Grid_Mapa].Quantidade_Inimigos_Sala > 0) {
            _SalaDireita_TemInimigos = true;
        }
    }

    //Verifica a sala Esquerda.
    if (I_Grid_Mapa - 1 >= 0 && global.Grid_Mapa[# I_Grid_Mapa - 1, J_Grid_Mapa].Sala_Grid != _Criar_Sala.Salas_Prontas.Salas_Fase1.Sala_Preenchimento) {
        if (global.Grid_Mapa[# I_Grid_Mapa - 1, J_Grid_Mapa].Quantidade_Inimigos_Sala > 0) {
            _SalaEsquerda_TemInimigos = true;
        }
    }
    
    //Verifica a sala Cima.
    if (J_Grid_Mapa - 1 >= 0 && global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa - 1].Sala_Grid != _Criar_Sala.Salas_Prontas.Salas_Fase1.Sala_Preenchimento) {
        if (global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa - 1].Quantidade_Inimigos_Sala > 0) {
            _SalaCima_TemInimigos = true;
        }
    }
    
    //Verifica a sala Baixo.
    if (_Altura_Grid_Mapa >= J_Grid_Mapa + 1 && global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa + 1].Sala_Grid != _Criar_Sala.Salas_Prontas.Salas_Fase1.Sala_Preenchimento) {
        if (global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa + 1].Quantidade_Inimigos_Sala > 0) {  
            _SalaBaixo_TemInimigos = true;
        }
    }
    
    if (_SalaAtual_TemInimigos || _SalaEsquerda_TemInimigos || _SalaDireita_TemInimigos || _SalaCima_TemInimigos || _SalaBaixo_TemInimigos) {
    	Estado_Porta = EstadoTrancada_Porta;
    }else {
    	Estado_Porta = EstadoDestrancada_Porta;
    }
}

#endregion