#region Variaveis.

Estado_Porta_Debug = "";

Posicao_Porta = "";

EscalaX_Porta = 0
EscalaY_Porta = 0

EspacamentoX_Sensor = 70;
EspacamentoY_Sensor = 70;

I_Grid_Mapa = x div global.Tamanho_Sala;
J_Grid_Mapa = y div global.Tamanho_Sala;

Direcao_Porta = "Não escolhida";

//Controles.
Gerar_Sensores = false;

#endregion

#region Estados da Porta.

Estado_Trancada = function(){
    
    Estado_Porta_Debug = "Trancada";
    
    if(global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Quantidade_Inimigos_Sala <= 0){
        Estado_Porta = Estado_Destrancada;
    }
}

Estado_Destrancada = function(){
    
    Estado_Porta_Debug = "Destrancada";
    
    Abrindo_Porta();
}

Estado_Porta = Estado_Trancada;

#endregion

#region Metodos.

Config_Porta = function(){
    
    switch (Posicao_Porta) {
    	
        case "Esquerda":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _Sensor = instance_create_layer(x + EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    
        case "Direita":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _Sensor = instance_create_layer(x - EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
        
        case "Cima":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
                var _Sensor = instance_create_layer(x, y + EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    
        case "Baixo":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
                var _Sensor = instance_create_layer(x, y - EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    }
    
    image_speed = 0;
    
    image_xscale = EscalaX_Porta;
    image_yscale = EscalaY_Porta;
}

Abrindo_Porta = function(){

    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    
    var _Player_Encostou = instance_place(x, y, obj_Player);
    
    if (_Player_Encostou) {
        
        _Player.Estado_Player = _Player.Estado_SemControle_Player;
        
        var _Centralizando_Horizontal = 0;
        var _Centralizando_Vertical = 0;

        switch (Posicao_Porta) {
        	
            case "Direita":
                _Centralizando_Horizontal = x + (EscalaX_Porta * 7);
                _Centralizando_Vertical = y + (EscalaY_Porta * 7);
                
                _Player.x = lerp(_Player.x, _Centralizando_Horizontal, 0.05);
                _Player.y = lerp(_Player.y, _Centralizando_Vertical, 0.05);       
            break;
        }
        
        image_index = 1;
    }
}

#endregion