#region Variaveis.

EscalaX_Porta = 0
EscalaY_Porta = 0

Posicao_Porta = 0;

EspacamentoX_Sensor = 90;
EspacamentoY_Sensor = 70;

I_Grid_Mapa = 0;
J_Grid_Mapa = 0;

//Controles.
Gerar_Sensores = false;

#endregion

#region Metodos

Config_Porta = function(){
    
    switch (Posicao_Porta) {
    	
        case "Esquerda":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _Sensor = instance_create_layer(x - EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    
        case "Direita":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _Sensor = instance_create_layer(x + EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
        
        case "Cima":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
                var _Sensor = instance_create_layer(x, y + EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    
        case "Baixo":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
                var _Sensor = instance_create_layer(x, y - EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _Sensor.EscalaX_Sensor = EscalaX_Porta;
                _Sensor.EscalaY_Sensor = EscalaY_Porta;
                _Sensor.I_Grid_Mapa = I_Grid_Mapa;
                _Sensor.J_Grid_Mapa = J_Grid_Mapa;
                
                Gerar_Sensores = true;
            }
            
        break;
    }
    
    image_xscale = EscalaX_Porta;
    image_yscale = EscalaY_Porta;
}

Abrindo_Porta = function(){

    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    
    var _Player_Encostou = instance_place(x, y, obj_Player);
    
    if (_Player_Encostou) {
        instance_destroy();
    }
}

#endregion