#region Variaveis.

Estado_Porta_Debug = "";

Posicao_Porta = "";

EscalaX_Porta = 0
EscalaY_Porta = 0

EspacamentoX_Sensor = 70;
EspacamentoY_Sensor = 70;

//Controles.
Gerar_Sensores = false;
Player_Escostou_Porta = false;

//Cooldowns
TempoDefinido_Passar_Porta = 60 * 2;
Tempo_Passar_Porta = 0;

#endregion

#region Estados da Porta.

Estado_Trancada = function(){
    
    Estado_Porta_Debug = "Trancada";
    
    if(global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Quantidade_Inimigos_Sala <= 0){
        Estado_Porta = Estado_Destrancada;
    }
}

Estado_Destrancada = function(){
    
    Estado_Porta_Debug = "Destrancada";
    
}

Estado_Porta = Estado_Trancada;

#endregion

#region Metodos.

Config_Porta = function(){
    
    switch (Posicao_Porta) {
    
        case "Direita":
            EscalaX_Porta = 3;
            EscalaY_Porta = 5;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) {
            	var _SensorDireita = instance_create_layer(x - EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _SensorDireita.EscalaX_Sensor = EscalaX_Porta;
                _SensorDireita.EscalaY_Sensor = EscalaY_Porta;
                
                var _SensorEsquerda = instance_create_layer(x + EspacamentoX_Sensor, y, "ins_Sensores", obj_Sensor);
                _SensorEsquerda.EscalaX_Sensor = EscalaX_Porta;
                _SensorEsquerda.EscalaY_Sensor = EscalaY_Porta;
                
                Gerar_Sensores = true;
            }
            
        break;
        
        case "Cima":
            EscalaX_Porta = 5;
            EscalaY_Porta = 3;
            
            //Gerando Sensor de Inicializacao da Sala
            if (!Gerar_Sensores) { 
            	var _SensorCima = instance_create_layer(x, y - EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _SensorCima.EscalaX_Sensor = EscalaX_Porta;
                _SensorCima.EscalaY_Sensor = EscalaY_Porta;
                
                var _SensorBaixo = instance_create_layer(x, y + EspacamentoY_Sensor, "ins_Sensores", obj_Sensor);
                _SensorBaixo.EscalaX_Sensor = EscalaX_Porta;
                _SensorBaixo.EscalaY_Sensor = EscalaY_Porta;
                
                Gerar_Sensores = true;
            }
            
        break;
    }
    
    image_speed = 0;
    
    image_xscale = EscalaX_Porta;
    image_yscale = EscalaY_Porta;
}

#endregion