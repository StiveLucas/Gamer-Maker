Config_Porta();
Abrindo_Porta();