Config_Porta();
Estado_Porta();