draw_self();

draw_text(x, y, global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Quantidade_Inimigos_Sala)
draw_text(x - 20, y - 50, Estado_Porta_Debug)