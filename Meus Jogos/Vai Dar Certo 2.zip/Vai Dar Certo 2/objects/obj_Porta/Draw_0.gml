draw_self();

draw_text(x, y, global.Grid_Mapa[# I_Grid_Mapa, J_Grid_Mapa].Quantidade_Inimigos_Sala)