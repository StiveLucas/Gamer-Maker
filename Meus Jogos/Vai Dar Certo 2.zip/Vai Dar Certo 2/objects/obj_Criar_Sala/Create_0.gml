/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis

global.Tamanho_Sala = 1200;
global.TamanhoCelula_Sala = 16;

#endregion

Salas_Prontas = {
    
    Salas_Fase1: {
        
        Sala_Preenchimento:{
            
            Construcao_Sala: function(_DS_Grid_Sala, _I, _J){
                
                var _Largura_Grid = ds_grid_width(_DS_Grid_Sala) - 1;
                var _Altura_Grid = ds_grid_height(_DS_Grid_Sala) - 1;
                
                ds_grid_clear(_DS_Grid_Sala, 2);
                
                ///             Tabelas de Indeces
                    /* 
                     * 0 - Vazio.
                     * 1 - Chao.
                     * 2 - Parede.
                     * 3 - Player.
                    */
                
            },
            
            Desenho_Sala: function(_DS_Grid_Sala, _I, _J){
                    
                var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                
                if(!DEBUG_MODE) return;
                    
            }
            
        },
        
        Spawm_Player: {
            
            Sala_1:{
                
                Construcao_Sala: function(_DS_Grid_Sala, _I_Grid_Mapa, _J_Grid_Mapa){
                    var _Largura_Grid_Sala = ds_grid_width(_DS_Grid_Sala) - 1;
                    var _Altura_Grid_Sala = ds_grid_height(_DS_Grid_Sala) - 1;
                    
                    var _Grossura_Parede = 3;
                    var _Tamanho_Saida = 4;
                    var _EspacamentoH_Porta = 2;
                    var _EspacamentoV_Porta = 4;
                    
                    //Definindo 1(Chao) para toda a sala.
                    ds_grid_clear(_DS_Grid_Sala, 1);
                    
                    ///             Tabelas de Indices
                    /* 
                     * 0 - Vazio.
                     * 1 - Chao.
                     * 2 - Parede.
                     * 3 - Player.
                     * 4 - Porta.
                    */
                    
                    
                    for (var i = 0; i <= _Largura_Grid_Sala; i++) {
                    	
                        for (var j = 0; j <= _Altura_Grid_Sala; j++) {
                            
                            var _PosicaoX_Mapa, _PosicaoY_Mapa;
                            
                            _PosicaoX_Mapa = (_I_Grid_Mapa * global.Tamanho_Sala) + (i * global.TamanhoCelula_Sala);
                            _PosicaoY_Mapa = (_J_Grid_Mapa * global.Tamanho_Sala) + (j * global.TamanhoCelula_Sala);
                            
                            #region Definindo Indices na Grid_Sala(Paredes, Chão, Buracos).
                            
                                    ///             Tabelas de Indices
                            /* 
                            * 0 - Vazio.
                            * 1 - Chao.
                            * 2 - Parede.
                            * 3 - Player.
                             * 4 - Porta.
                            */
                            
                            //Colocando parede em volta da sala.
                            Indice_ParedeEmVolta_Sala(_DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, 2);
                            
                            //Gerando Saidas da Sala.
                            Gerar_Saidas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Tamanho_Saida, 4);
                            
                            if (_DS_Grid_Sala[# i, j] == 1 || _DS_Grid_Sala[# i, j] == 4) {
                                instance_create_layer(_PosicaoX_Mapa, _PosicaoY_Mapa, "ins_Parede", obj_Chao);
                            }
                            
                            if (_DS_Grid_Sala[# i, j] == 2) {
                                instance_create_layer(_PosicaoX_Mapa, _PosicaoY_Mapa, "ins_Parede", obj_Parede);
                            }
                            
                            //Gerando as Portas da sala.
                            Gerar_Portas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, _EspacamentoH_Porta, _EspacamentoV_Porta);
                            
                            #endregion
                        }
                    }
                    
                },
                
                Inicializar_Objetos_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                    
                    for (var i = 0; i < _Largura_Grid; i++) {
                        
                        for (var j = 0; j < _Altura_Grid; j++) {
                            
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);
                            
                            //  Posicao do Player.
                            if (i == (_Largura_Grid div 2) && j == (_Altura_Grid div 2)) {
                                _DS_Grid_Sala[# i, j] = 3;
                            }
                            
                            //Gerando Player.
                            if (_DS_Grid_Sala[# i, j] == 3) {
                            	if(!instance_exists(obj_Player)) instance_create_layer(_X1, _Y1, "ins_Player", obj_Player);
                            }
                        }
                    }
                },
                
                Desenho_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
  
                    if(!DEBUG_MODE || !global.Debug_Exibir_Grid_Salas) exit;
                    for (var i = 0; i < _Largura_Grid; i++) {
                    	
                        for (var j = 0; j < _Altura_Grid; j++) {
                        	
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);

                            _Cor = c_green;
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, false);
                            
                            _Cor = c_black
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
                            
                            draw_text(_X1, _Y1, _DS_Grid_Sala[# i, j]);
                        }
                    }
                }
            }
        },
        
        Salas_Inimigas: {
            
            SalaInimiga_1:{
                
                Construcao_Sala: function(_DS_Grid_Sala, _I_Grid_Mapa, _J_Grid_Mapa){
                    var _Largura_Grid_Sala = ds_grid_width(_DS_Grid_Sala) - 1;
                    var _Altura_Grid_Sala = ds_grid_height(_DS_Grid_Sala) - 1;
                    
                    var _Grossura_Parede = 3;
                    var _Tamanho_Saida = 4;
                    var _EspacamentoH_Porta = 2;
                    var _EspacamentoV_Porta = 4;
                    
                    //Definindo 1(Chao) para toda a sala.
                    ds_grid_clear(_DS_Grid_Sala, 1);

                        ///             Tabelas de Indices
                    /* 
                    * 0 - Vazio.
                    * 1 - Chao.
                    * 2 - Parede.
                    * 3 - Player.
                    * 4 - Porta.
                     * 
                     * 6 - Inimigo
                    */
                    
                     for (var i = 0; i <= _Largura_Grid_Sala; i++) {
                    	
                        for (var j = 0; j <= _Altura_Grid_Sala; j++) {
                            
                            var _PosicaoX_Mapa, _PosicaoY_Mapa;
                            
                            _PosicaoX_Mapa = (_I_Grid_Mapa * global.Tamanho_Sala) + (i * global.TamanhoCelula_Sala);
                            _PosicaoY_Mapa = (_J_Grid_Mapa * global.Tamanho_Sala) + (j * global.TamanhoCelula_Sala);
                            
                            //Colocando parede em volta da sala.
                            Indice_ParedeEmVolta_Sala(_DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, 2);
                            
                            Gerar_Saidas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Tamanho_Saida, 4);
                            
                            if (_DS_Grid_Sala[# i, j] == 1 || _DS_Grid_Sala[# i, j] == 4) {
                                instance_create_layer(_PosicaoX_Mapa, _PosicaoY_Mapa, "ins_Parede", obj_Chao);
                            }
                            
                            if (_DS_Grid_Sala[# i, j] == 2) {
                                instance_create_layer(_PosicaoX_Mapa, _PosicaoY_Mapa, "ins_Parede", obj_Parede);
                            }
                            
                            //Gerando as Portas da sala.
                            
                            Gerar_Portas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, _EspacamentoH_Porta, _EspacamentoV_Porta);
                        }
                    }
                },
                
                Inicializar_Objetos_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);

                    for (var i = 0; i < _Largura_Grid; i++) {
                        
                        for (var j = 0; j < _Altura_Grid; j++) {
                            
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);

                            
                            if (i == _Largura_Grid/2 && j == _Altura_Grid/2) {
                                _DS_Grid_Sala[# i, j] = 6;
                                show_message("Foi")
                            }
                            
                            if (_DS_Grid_Sala[# i, j] == 6) {
                                show_message("inimigo")
                                instance_create_layer(_X1, _Y1, "ins_Inimigos", obj_Inimigo1);
                            }
                            
                        }
                    }
                },
                
                Desenho_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                    
                    if(!DEBUG_MODE || !global.Debug_Exibir_Grid_Salas) exit;
                        
                    for (var i = 0; i < _Largura_Grid; i++) {
                    	
                        for (var j = 0; j < _Altura_Grid; j++) {
                        	
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);
                            
                            _Cor = c_green;
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, false);
                            
                            _Cor = c_black
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
                            
                            draw_text(_X1, _Y1, _DS_Grid_Sala[# i, j]);
                        }
                    }
                }
            }
        }
    }
}