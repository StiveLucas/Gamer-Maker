/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis

global.TamanhoCelula_Sala = 16;

#endregion

Salas_Prontas = {
    
    Salas_Fase1: {
        
        Sala_Preenchimento:{
            
            Construcao_Sala: function(_DS_Grid_Sala, _I, _J){
                
                var _Largura_Grid = ds_grid_width(_DS_Grid_Sala) - 1;
                var _Altura_Grid = ds_grid_height(_DS_Grid_Sala) - 1;
                
                ds_grid_clear(_DS_Grid_Sala, 2);
                
                ///             Tabelas de Indeces
                    /* 
                     * 0 - Vazio.
                     * 1 - Chao.
                     * 2 - Parede.
                     * 3 - Player.
                    */
                
            },
            
            Desenho_Sala: function(_DS_Grid_Sala, _I, _J){
                    
                var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                
                if(!DEBUG_MODE) return;
                    
            }
            
        },
        
        Spawm_Player: {
            
            Sala_1:{
                
                Construcao_Sala: function(_DS_Grid_Sala, _I_Grid_Mapa, _J_Grid_Mapa){
                    
                    var _Largura_Grid_Sala = ds_grid_width(_DS_Grid_Sala) - 1;
                    var _Altura_Grid_Sala = ds_grid_height(_DS_Grid_Sala) - 1;
                    
                    // Criando e TileMap
                    var _Id_TileMap_Paredes_Salas = layer_tilemap_get_id("tls_Paredes_Salas");
                    var _Id_TileMap_Chao_Salas = layer_tilemap_get_id("tls_Chao_Salas");
                    
                    //Define o tamanho da grid do teliMap
                    if (_Id_TileMap_Paredes_Salas != -1) {
                        // Garante que o tilemap tem largura e altura suficientes para suportar o mapa procedural
                        tilemap_set_width(_Id_TileMap_Paredes_Salas, room_width);
                        tilemap_set_height(_Id_TileMap_Paredes_Salas, room_height);
                        
                        tilemap_set_width(_Id_TileMap_Chao_Salas, room_width);
                        tilemap_set_height(_Id_TileMap_Chao_Salas, room_height);
                    }
                    
                    var _Grossura_Parede = 3;
                    var _Tamanho_Saida = 4;
                    var _EspacamentoH_Porta = 2;
                    var _EspacamentoV_Porta = 4;
                    
                    
                    //Definindo 1(Chao) para toda a sala.
                    ds_grid_clear(_DS_Grid_Sala, 1);
                    
                    ///             Tabelas de Indices
                    /* 
                     * 0 - Vazio.
                     * 1 - Chao.
                     * 2 - Parede.
                     * 3 - Player.
                     * 4 - Porta.
                    */
                    
                    
                    for (var i = 0; i <= _Largura_Grid_Sala; i++) {
                    	
                        for (var j = 0; j <= _Altura_Grid_Sala; j++) {
                            
                            var _PosicaoX_Mapa, _PosicaoY_Mapa;
                            
                            _PosicaoX_Mapa = (_I_Grid_Mapa * global.Tamanho_Sala) + (i * global.TamanhoCelula_Sala);
                            _PosicaoY_Mapa = (_J_Grid_Mapa * global.Tamanho_Sala) + (j * global.TamanhoCelula_Sala);
                            
                            #region Definindo Indices na Grid_Sala(Paredes, Chão, Buracos).
                            
                                    ///             Tabelas de Indices
                            /* 
                            * 0 - Vazio.
                            * 1 - Chao.
                            * 2 - Parede.
                            * 3 - Player.
                             * 4 - Porta.
                            */
                            
                            //Colocando parede em volta da sala.
                            Indice_ParedeEmVolta_Sala(_DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, 2);
                            
                            //Gerando Saidas da Sala.
                            Gerar_Saidas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Tamanho_Saida, 4);
                            
                            #region Definindo TileMap da Sala.
                                if (!global.Debug_Exibir_Grid_Salas) {
                                   var _num_celulas_x = _Largura_Grid_Sala + 1;
                                   var _num_celulas_y = _Altura_Grid_Sala + 1;
                               
                                   //TileMap do Chão da Sala.
                                   if (_DS_Grid_Sala[# i, j] == 1 || _DS_Grid_Sala[# i, j] == 4) {
                                       // Calcula a célula exata no tilemap global considerando o índice da sala no mapa
                                       var _x_global = (_I_Grid_Mapa * _num_celulas_x) + i;
                                       var _y_global = (_J_Grid_Mapa * _num_celulas_y) + j;
                                         
                                       tilemap_set(_Id_TileMap_Chao_Salas, 6, _x_global, _y_global);
                                   }
                               
                                   //TileMap das Paredes da Sala.
                                   if (_DS_Grid_Sala[# i, j] == 2) {
                                       // Calcula a célula exata no tilemap global considerando o índice da sala no mapa
                                       var _x_global = (_I_Grid_Mapa * _num_celulas_x) + i;
                                       var _y_global = (_J_Grid_Mapa * _num_celulas_y) + j;
                                       
                                       tilemap_set(_Id_TileMap_Paredes_Salas, 3, _x_global, _y_global);
                                   }
                                }
                            #endregion
                            
                            //Gerando as Portas da sala.
                            Gerar_Portas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, _EspacamentoH_Porta, _EspacamentoV_Porta);
                            
                            #endregion
                        }
                    }
                    
                },
                
                Inicializar_Objetos_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                    
                    for (var i = 0; i < _Largura_Grid; i++) {
                        
                        for (var j = 0; j < _Altura_Grid; j++) {
                            
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);
                            
                            //  Posicao do Player.
                            if (i == (_Largura_Grid div 2) && j == (_Altura_Grid div 2)) {
                                _DS_Grid_Sala[# i, j] = 3;
                            }
                            
                            //Gerando Player.
                            if (_DS_Grid_Sala[# i, j] == 3) {
                            	if(!instance_exists(obj_Player)) instance_create_layer(_X1, _Y1, "ins_Player", obj_Player);
                            }
                        }
                    }
                },
                
                Desenho_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
  
                    if(!DEBUG_MODE || !global.Debug_Exibir_Grid_Salas) exit;
                        
                    for (var i = 0; i < _Largura_Grid; i++) {
                    	
                        for (var j = 0; j < _Altura_Grid; j++) {
                        	
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);

                            _Cor = c_green;
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, false);
                            
                            _Cor = c_black
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
                            
                            draw_text(_X1, _Y1, _DS_Grid_Sala[# i, j]);
                        }
                    }
                }
            }
        },
        
        Salas_Inimigas: {
            
            SalaInimiga_1:{
                
                Construcao_Sala: function(_DS_Grid_Sala, _I_Grid_Mapa, _J_Grid_Mapa){
                    
                    var _Largura_Grid_Sala = ds_grid_width(_DS_Grid_Sala) - 1;
                    var _Altura_Grid_Sala = ds_grid_height(_DS_Grid_Sala) - 1;
                    
                    // Criando e TileMap
                    var _Id_TileMap_Paredes_Salas = layer_tilemap_get_id("tls_Paredes_Salas");
                    var _Id_TileMap_Chao_Salas = layer_tilemap_get_id("tls_Chao_Salas");
                    
                    //Define o tamanho da grid do teliMap
                    if (_Id_TileMap_Paredes_Salas != -1) {
                        // Garante que o tilemap tem largura e altura suficientes para suportar o mapa procedural
                        tilemap_set_width(_Id_TileMap_Paredes_Salas, room_width);
                        tilemap_set_height(_Id_TileMap_Paredes_Salas, room_height);
                        
                        tilemap_set_width(_Id_TileMap_Chao_Salas, room_width);
                        tilemap_set_height(_Id_TileMap_Chao_Salas, room_height);
                    }
                    
                    var _Grossura_Parede = 3;
                    var _Tamanho_Saida = 4;
                    var _EspacamentoH_Porta = 2;
                    var _EspacamentoV_Porta = 4;
                    
                    //Definindo 1(Chao) para toda a sala.
                    ds_grid_clear(_DS_Grid_Sala, 1);

                        ///             Tabelas de Indices
                    /* 
                    * 0 - Vazio.
                    * 1 - Chao.
                    * 2 - Parede.
                    * 3 - Player.
                    * 4 - Porta.
                     * 
                     * 6 - Inimigo
                    */
                    
                     for (var i = 0; i <= _Largura_Grid_Sala; i++) {
                    	
                        for (var j = 0; j <= _Altura_Grid_Sala; j++) {
                            
                            var _PosicaoX_Mapa, _PosicaoY_Mapa;
                            
                            _PosicaoX_Mapa = (_I_Grid_Mapa * global.Tamanho_Sala) + (i * global.TamanhoCelula_Sala);
                            _PosicaoY_Mapa = (_J_Grid_Mapa * global.Tamanho_Sala) + (j * global.TamanhoCelula_Sala);
                            
                            //Colocando parede em volta da sala.
                            Indice_ParedeEmVolta_Sala(_DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, 2);

                            Gerar_Saidas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _Grossura_Parede, _Tamanho_Saida, 4);
                            
                            #region Definindo TileMap da Sala.
                                if (!global.Debug_Exibir_Grid_Salas) {
                                    var _num_celulas_x = _Largura_Grid_Sala + 1;
                                    var _num_celulas_y = _Altura_Grid_Sala + 1;
                               
                                    //TileMap do Chão da Sala.
                                    if (_DS_Grid_Sala[# i, j] == 1 || _DS_Grid_Sala[# i, j] == 4) {
                                        // Calcula a célula exata no tilemap global considerando o índice da sala no mapa
                                        var _x_global = (_I_Grid_Mapa * _num_celulas_x) + i;
                                        var _y_global = (_J_Grid_Mapa * _num_celulas_y) + j;
                                            
                                        tilemap_set(_Id_TileMap_Chao_Salas, 6, _x_global, _y_global);
                                    }
                               
                                    //TileMap das Paredes da Sala.
                                    if (_DS_Grid_Sala[# i, j] == 2) {
                                        // Calcula a célula exata no tilemap global considerando o índice da sala no mapa
                                        var _x_global = (_I_Grid_Mapa * _num_celulas_x) + i;
                                        var _y_global = (_J_Grid_Mapa * _num_celulas_y) + j;
                                           
                                        tilemap_set(_Id_TileMap_Paredes_Salas, 3, _x_global, _y_global);
                                    }
                                }
                            #endregion
                            
                            #region Objetos da Sala.
                                //Gerando as Portas da sala.
                                Gerar_Portas_Sala(_I_Grid_Mapa, _J_Grid_Mapa, _DS_Grid_Sala, i, j, _Largura_Grid_Sala, _Altura_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, _EspacamentoH_Porta, _EspacamentoV_Porta);
                            #endregion
                            

                        }
                    }
                },
                
                Inicializar_Objetos_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa, _I_Grid_Sala, _J_Grid_Sala){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala) - 1;
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala) - 1;
                    
                    randomise(); 
                    
                    var _Quantidades_Inimigos_Sala = irandom_range(3, 7);
                    
                    repeat (_Quantidades_Inimigos_Sala) {
                    	
                        randomise();
                    
                        var _SpawnI_Inimigo = irandom_range(((_Largura_Grid div 2) - irandom(30)), ((_Largura_Grid div 2) + irandom(30)));
                        var _SpawnJ_Inimigo = irandom_range(((_Altura_Grid div 2) - irandom(30)), ((_Altura_Grid div 2) + irandom(30)));
    
                        for (var i = 0; i < _Largura_Grid; i++) {
                            
                            for (var j = 0; j < _Altura_Grid; j++) {
                                
                                var _X1, _Y1, _X2, _Y2, _Cor;
                                _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                                _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                                _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                                _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);
    
                                //Indice de spawnar inimigo.
                                if (i == _SpawnI_Inimigo && j == _SpawnJ_Inimigo) {
                                    instance_create_layer(_X1, _Y1, "ins_Inimigos", obj_Inimigo1);
                                    global.Grid_Mapa[# _I_Grid_Sala, _J_Grid_Sala].Quantidade_Inimigos_Sala++;
                                }
                            }
                        }
                    }
                },
                
                Desenho_Sala: function(_DS_Grid_Sala, _PosicaoX_Mapa, _PosicaoY_Mapa){
                    var _Largura_Grid = ds_grid_width(_DS_Grid_Sala);
                    var _Altura_Grid = ds_grid_height(_DS_Grid_Sala);
                    
                    if(!DEBUG_MODE || !global.Debug_Exibir_Grid_Salas) exit;
                        
                    for (var i = 0; i < _Largura_Grid; i++) {
                    	
                        for (var j = 0; j < _Altura_Grid; j++) {
                        	
                            var _X1, _Y1, _X2, _Y2, _Cor;
                            _X1 = _PosicaoX_Mapa + (i * global.TamanhoCelula_Sala);
                            _Y1 = _PosicaoY_Mapa + (j * global.TamanhoCelula_Sala);
                            _X2 = _PosicaoX_Mapa + ((i + 1) * global.TamanhoCelula_Sala);
                            _Y2 = _PosicaoY_Mapa + ((j + 1) * global.TamanhoCelula_Sala);
                            
                            _Cor = c_green;
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, false);
                            
                            _Cor = c_black
                            draw_rectangle_colour(_X1, _Y1, _X2, _Y2, _Cor, _Cor, _Cor, _Cor, true);
                            
                            draw_text(_X1, _Y1, _DS_Grid_Sala[# i, j]);
                        }
                    }
                }
            }
        }
    }
}