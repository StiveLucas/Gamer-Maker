#region Variáveis.

Vel_Tiro_Inimigo = 15;
Dano_Tiro_Inimigo = 0;

DirecaoX_Tiro_Inimigo = 0;
DirecaoY_Tiro_Inimigo = 0;

#endregion

#region Métodos.

Config_Tiro_Inimigo = function(){
    speed = Vel_Tiro_Inimigo;    
}

Colisao_Tiro_Grid_Sala = function(){
    
    //Colisão com a grid do jogo.
    Colisao_Grid_Jogo(x, y, global.Tamanho_Sala, global.TamanhoCelula_Sala, Vel_Tiro_Inimigo);
}

Dano_Player = function(){
    
    if(!instance_exists(obj_Player)) return;
        
    var _Player = obj_Player;
    
    var _Encostou_Player = instance_place(x, y, obj_Player);
    
    if (_Encostou_Player) {
        _Player.Morte_Player(Dano_Tiro_Inimigo);
        
        instance_destroy();
    }
}

#endregion

Config_Tiro_Inimigo();

Ativando_Funcoes_Tiro_Inimigo = function(){
    
    Colisao_Tiro_Grid_Sala();
    
    Dano_Player();
}