#region Variáveis.

#region Structs das Armas.

Armas_Player = {
    
    Arma_Simples : {
        
        Sprite_Arma: spr_Arma_Simples_Player,
        Sprite_Tiro_Arma: spr_Tiro_Player,
        Velocidade_Arma: 16,
        Dano_Arma: 2,
        Cooldown_Tiro_Arma: 35,
        
        Funcao_Tiro_Arma: function(_Sprite_Tiro_ArmaAtual, _Vel_Tiro, _Dano_Tiro){
            
            if(!instance_exists(obj_Player)) return;
                
            var _Player = obj_Player;
            var _Arma_Player = obj_Arma_Player;
            
            var _Direcao_Mouse = point_direction(_Arma_Player.x, _Arma_Player.y, mouse_x, mouse_y);
        
            var _Tiro_Player = instance_create_layer(_Player.x, _Player.y, "ins_Tiros_Player", obj_Tiro_Player);
            _Tiro_Player.Sprite_Tiro = _Sprite_Tiro_ArmaAtual;
            _Tiro_Player.Vel_Tiro = _Vel_Tiro;
            _Tiro_Player.Dano_Tiro = _Dano_Tiro;
        
            _Tiro_Player.direction = _Direcao_Mouse;
        }
    }
}

ArmaAtual = Armas_Player.Arma_Simples;

Tempo_Recarga = 0;

#endregion

#endregion

#region Métodos

Config_ArmaAtual_Player = function(){
    
    if(!instance_exists(obj_Player)) return;
                
    var _Player = obj_Player;
    
    x = _Player.x - 20;
    y = _Player.y - 20;
    
    image_angle = point_direction(x, y, mouse_x, mouse_y)
    
    sprite_index = ArmaAtual.Sprite_Arma;
    
    #region Cooldown do tiro da arma.
    
        if(Tempo_Recarga < ArmaAtual.Cooldown_Tiro_Arma) Tempo_Recarga++;

        if (Tempo_Recarga >= ArmaAtual.Cooldown_Tiro_Arma && _Player.Shot) {
            ArmaAtual.Funcao_Tiro_Arma(ArmaAtual.Sprite_Tiro_Arma, ArmaAtual.Velocidade_Arma, ArmaAtual.Dano_Arma);
        
            Tempo_Recarga = 0;
        }
    #endregion
}
 
#endregion