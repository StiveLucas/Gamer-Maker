/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Pega o meio da tela.
Meio_Tela = display_get_width();