/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


draw_set_font(fnt_Placar);

draw_text(175, 50, "You Dead!");

draw_text(40, 150, "Pontuação: " + string(global.Pontuacao_Atual));
draw_text(40, 220, "Inimigos Eliminados: " + string(global.Inimigos_Eliminados));

draw_set_font(-1);