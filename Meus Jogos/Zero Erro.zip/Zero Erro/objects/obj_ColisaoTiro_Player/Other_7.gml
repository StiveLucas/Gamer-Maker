/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destroindo objeto
instance_destroy();