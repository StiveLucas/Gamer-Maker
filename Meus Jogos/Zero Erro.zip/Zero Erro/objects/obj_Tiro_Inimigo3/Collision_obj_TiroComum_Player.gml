 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destruindo o Tiro do Player
instance_destroy(other);

Vida_Barreira--;

if(Vida_Barreira <=0){
	instance_destroy() ;
}