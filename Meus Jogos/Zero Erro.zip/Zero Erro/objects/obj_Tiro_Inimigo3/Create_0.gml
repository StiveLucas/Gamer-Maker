/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Vida da Barreira
Vida_Barreira = 5;

//Velocidade do tiro.
Vel_Tiro = -7;
Tiro_Configurado = false;

Config_TiroEsticado_Inimigo = function(){
	
	//Sistema para verificar se o tiro encostou no mapa
	if(y >= room_height - sprite_height/2){
		vspeed = 0;
		hspeed = Vel_Tiro;
	}

	if(y <= 0 + sprite_height/2){
		vspeed = 0;
		hspeed = Vel_Tiro;
	}
	
	//Sistema Para fazer o tiro esticar.
	if(vspeed == 0){
		if(!Tiro_Configurado){
			Tiro_Configurado = true;
			Limite_yscale = irandom_range(10, 12);
		}
		
		image_yscale = lerp(image_yscale, Limite_yscale, 0.02);
	}

}