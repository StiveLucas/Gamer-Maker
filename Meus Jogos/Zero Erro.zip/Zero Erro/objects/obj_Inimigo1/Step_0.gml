/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Verifica os estados do Inimigo.
Maquina_Estado_Inimigo();

//Traz a sprite original.
Sprite_Original(spr_Inimigo1);