/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Faz o Player perder
if(instance_exists(obj_Player)){
	obj_Player.Config_PerdaVida_Player();
}