/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Destruindo o Tiro do Player
instance_destroy(other);

//Executa a Tremedeira.
Executar_Efeito_Tremer(5);

if(instance_exists(obj_Player)){
	//Tira a vida do Inimigo1
	Vida_Inimigo -= obj_Player.Dano_Tiro_Player;
}

//Elimina o Inimigo
if(Vida_Inimigo <= 0){
	EliminandoInimigo();
}