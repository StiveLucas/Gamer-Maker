/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Config do tiro do Inimigo
Config_Tiro_Inimigo(spr_Amc_Tiro_Inimigo1);

//Tempo atirar novamente.
alarm[0] = 60 * Temp_Tiro_Inimigo;