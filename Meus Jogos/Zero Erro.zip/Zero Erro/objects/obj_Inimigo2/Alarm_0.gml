/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Config da animação do tiro do Inimigo
Animacao_Tiro();

//Tempo atirar novamente.
alarm[0] = 60 * Temp_Tiro_Inimigo;