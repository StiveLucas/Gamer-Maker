/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

image_xscale = -1;
image_speed = 0;

//Variáveis do Inimigo1
#region Variáveis do Inimigo1
Vida_Inimigo = 5;
Temp_Tiro_Inimigo = 5;

Vel_Inimigo = -1.8;
Vel_Tiro_Inimigo = -11;

Estado_Inimigo = "Se movendo para tela"
Tempo_MudarEstado_Inimigo = 60 * random(9);
Timer_MudarEstado_Inimigo = 0;

PosicaoX_Inimigo = irandom_range(550, 1070);
PosicaoY_Inimigo = irandom_range(90, 500);
Destino_X = false;
Destino_Y = false;
Direcao_MovimentoEscolhida_Inimigo = false;

#endregion

//Maquina de estado do Inimigo1
#region Maquina de estado do Inimigo1
Maquina_Estado_Inimigo = function(){
	
	switch(Estado_Inimigo){
		
		case "Se movendo para tela":
			if(x >= PosicaoX_Inimigo){
				hspeed = Vel_Inimigo;
			}else{
				Destino_X = true;
			}
			
			if(y > PosicaoY_Inimigo){
				vspeed = Vel_Inimigo;
			}
			
			if(y < 0){
				vspeed = -Vel_Inimigo;
			}
			
			if(y < PosicaoY_Inimigo && y > 0){
				Destino_Y = true;
			}
			
			if(Destino_X == true && Destino_Y == true){
				Estado_Inimigo = "Parado";
			}
			
		break;
		
		case "Parado":
			hspeed = 0;
			vspeed = 0;
			
		break;

	}
	
}

#endregion

//Configuração do Inimigo
#region  Configuração do Inimigo

//Configuração do Tiro do Inimigo1.

//Tiro do Inimigo.
alarm[0] = 60 * 2;

Config_Tiro_Inimigo = function(){
	
	if(instance_exists(obj_Player)){
		var _Direcao_Player = point_direction(x, y, obj_Player.x, obj_Player.y);
	}
	
	var _Tiro1Inimigo = instance_create_layer(x, y, "ins_Tiros_Inimigos", obj_Tiro_Inimigo2);
	var _Tiro2Inimigo = instance_create_layer(x, y, "ins_Tiros_Inimigos", obj_Tiro_Inimigo2);
	var _Tiro3Inimigo = instance_create_layer(x, y, "ins_Tiros_Inimigos", obj_Tiro_Inimigo2);
	
	_Tiro1Inimigo.hspeed = Vel_Tiro_Inimigo;
	_Tiro2Inimigo.hspeed = Vel_Tiro_Inimigo;
	_Tiro3Inimigo.hspeed = Vel_Tiro_Inimigo;
	
	_Tiro1Inimigo.direction = _Direcao_Player + 18;
	_Tiro2Inimigo.direction = _Direcao_Player;
	_Tiro3Inimigo.direction = _Direcao_Player - 18;

}

Animacao_Tiro = function(){
	image_speed = 0.1;
}

#endregion