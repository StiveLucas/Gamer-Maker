/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Verifica os estados do Inimigo.
Maquina_Estado_Inimigo();

//Verifica se pode atirar
if(image_index >= 6 && image_speed > 0){
	Config_Tiro_Inimigo();
	image_speed = -0.1;
}

//Verifica se o Player exista.
if(instance_exists(obj_Player)){
	//Sempre apontando para o Player
	image_angle = point_direction(x, y, obj_Player.x, obj_Player.y);
}