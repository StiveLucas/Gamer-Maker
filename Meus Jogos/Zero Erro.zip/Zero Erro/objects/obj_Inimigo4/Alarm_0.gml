/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Config_Tiro_Inimigo();

//Tempo atirar novamente.
alarm[0] = 60 * Temp_Tiro_Inimigo;