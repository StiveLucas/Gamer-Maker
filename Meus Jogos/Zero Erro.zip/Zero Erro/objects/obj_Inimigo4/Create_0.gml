  /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Colocando imagem sprite na direção certa.
image_xscale = -1;

//Variáveis do Inimigo1
#region Variáveis do Inimigo1
Vida_Inimigo = 4;
Temp_Tiro_Inimigo = 0.3;

Vel_Inimigo = -4.6;
Vel_Tiro_Inimigo = -18;

Estado_Inimigo = "Se movendo para tela"
Tempo_MudarEstado_Inimigo = 60 * random(5);
Timer_MudarEstado_Inimigo = 0;

PosicaoX_Inimigo = irandom_range(400, 1070);
PosicaoY_Inimigo = irandom_range(90, 500);
Destino_X = false;
Destino_Y = false;

Direcao_MovimentoEscolhida_Inimigo = false;

#endregion

//Maquina de estado do Inimigo1
#region Maquina de estado do Inimigo1
Maquina_Estado_Inimigo = function(){
	
	switch(Estado_Inimigo){
		
		case "Se movendo para tela":
			if(x >= PosicaoX_Inimigo){
				hspeed = Vel_Inimigo;
			}else{
				Destino_X = true;
			}
			
			if(y > PosicaoY_Inimigo){
				vspeed = Vel_Inimigo;
			}
			
			if(y < 0){
				vspeed = -Vel_Inimigo;
			}
			
			if(y < PosicaoY_Inimigo && y > 0){
				Destino_Y = true;
			}
			
			if(Destino_X == true && Destino_Y == true){
				Estado_Inimigo = "Parado";
			}
			
		break;
		
		case "Parado":
			hspeed = 0;
			vspeed = 0;
			Timer_MudarEstado_Inimigo++;
			if(Timer_MudarEstado_Inimigo >= Tempo_MudarEstado_Inimigo){
				Timer_MudarEstado_Inimigo = 0;
			}
		break;
		
	}
	
}

#endregion

//Configuração do Inimigo
#region Configuração do Inimigo

//Configuração do Tiro do Inimigo1.

//Tiro do Inimigo.
alarm[0] = 60 * 4;

Config_Tiro_Inimigo = function(){
	
	var _Direcao_Player = point_direction(x, y, obj_Player.x, obj_Player.y);
	
	image_index = 0;
	image_speed = 0.1;
	
	var _TiroInimigo1 = instance_create_layer(x, y, "ins_Tiros_Inimigos", obj_Tiro_Inimigo4);
	
	_TiroInimigo1.hspeed = Vel_Tiro_Inimigo;
	_TiroInimigo1.direction = _Direcao_Player;
}

#endregion