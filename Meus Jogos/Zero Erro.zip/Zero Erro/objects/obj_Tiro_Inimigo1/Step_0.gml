/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


//Se o Objeto sair pra fora do mapa ele se destroi.
if(x <= -100){
	instance_destroy();
}