/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Se Destroindo ao encostar no play.
instance_destroy();

//Reduzindo a vida e destroindo o inimigo.
other.Config_PerdaVida_Player();