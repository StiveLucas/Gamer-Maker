/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis do Player.
//Vida e Velocidadae do Player.
Vida_Player = 3;
Vel_Player = 5.5;

//Condições do Player.
InverterControle = false;

//Tiros do Player
Dano_Tiro_Player = 1;
Vel_Tiro = 16;

//Cooldown de Invelsibilidade do Player
Cooldown_Invencivel_Player = 60;
Timer_Cooldown_Invencivel_Player = 0;

//Cooldown dos tiros.
Cooldown_Tiro_Player = 10;
Timer_Cooldown_Tiro_Player = 0;

//Cooldown para reduzir o Pow_Up.
Cooldown_PowUp = 60 * 8;
Timer_Cooldown_PowUP = 0;

//Cooldown para tirar o efeito do reverso.
Cooldown_EfeitoReverso = 60 * 1.5;
Timer_Cooldown_EfeitoReverso = 0;

#endregion

#region Métodos.

Desenhando_Iconis = function(_Qnt_Repetir, _Sprite, _Index, _X, _Y){
	var Distancia_Segura = 0
	repeat(_Qnt_Repetir){
		draw_sprite(_Sprite, _Index, _X + Distancia_Segura , _Y);
		
		Distancia_Segura += 100;
	}
}

#endregion

#region Configurações do Player.
//Configurações da vida do Player.
Config_PerdaVida_Player = function(){

	//Verifica se o Player está invencivel.
	if(Timer_Cooldown_Invencivel_Player > Cooldown_Invencivel_Player){
		Vida_Player--;
		
		//Destoce o player.
		image_xscale = 2.5;
		image_yscale = 2.5;
		
		Executar_Efeito_Tremer(30);
		Timer_Cooldown_Invencivel_Player = 0;
		
	}else{
		return;
	}
	
	//Se o Player perder todas vidas ele é destruido.
	if(Vida_Player <= 0){
		Executar_Efeito_Tremer(90);
		instance_destroy();
		
		//Trancisão para ir para outra tela
		layer_sequence_create("ass_Trancisoes", room_width / 2, room_height / 2, sqc_Trancisao1);
	} 
}

//Movimentação do Player
Config_Movimento_Player = function(){
	
	//Teclas e variáveis de moviemntação do Player
	var _left, _rigth, _up, _down;
	
	//Movimentação do Player/ Verifica se o efeito reverso está ativo
	if(!InverterControle){
		_up = keyboard_check(ord("W")) || keyboard_check(vk_up);
		_down = keyboard_check(ord("S")) || keyboard_check(vk_down);
		_left = keyboard_check(ord("A")) || keyboard_check(vk_left);
		_rigth = keyboard_check(ord("D")) || keyboard_check(vk_right);
		
	}else{
		_up = keyboard_check(ord("S")) || keyboard_check(vk_down);
		_down = keyboard_check(ord("W")) || keyboard_check(vk_up);
		_left = keyboard_check(ord("D")) || keyboard_check(vk_right);
		_rigth = keyboard_check(ord("A")) || keyboard_check(vk_left);
	}
	
	//Movendo do Player na Vertical.
	var _velV = (_down - _up) * Vel_Player;
	y += _velV;
	
	//Impedindo o player sair da tela
	y = clamp(y, (sprite_height/2 - 40), room_height - (sprite_height/2 - 30));
	
	//Movimento do Player na Horizontal.
	var _velH = (_rigth - _left) * Vel_Player;
	x += _velH;
	
	//Impedindo o player sair da tela
	x = clamp(x, (sprite_width/2 - 10), room_width - (sprite_width/2 - 30));
	
	//Timer de Invencibilidade do Player.
	Timer_Cooldown_Invencivel_Player++;
	
	//Timer para reduzir o nivel do tiro.
	if(global.Tipo_Tiro > 0){
		Timer_Cooldown_PowUP++;
		
		if(Timer_Cooldown_PowUP >= Cooldown_PowUp){
			global.Tipo_Tiro--;
			Timer_Cooldown_PowUP = 0;
		}
	}else{
		Timer_Cooldown_PowUP = 0;
	}
	
	//Timer para Tirar o efeito de inverter controle.
	if(InverterControle){
		Timer_Cooldown_EfeitoReverso++
	
		if(Timer_Cooldown_EfeitoReverso >= Cooldown_EfeitoReverso){
			InverterControle = false;
			Timer_Cooldown_EfeitoReverso = 0;
		}
	}
}

//Configurações do Tiro do Player
Config_Tiro_Player = function(){
	var _shot = keyboard_check(vk_space);
	Timer_Cooldown_Tiro_Player++;
	
	//Se o botão for precionado e o cooldown tiver carregado ele atira.
	if(_shot && Timer_Cooldown_Tiro_Player >= Cooldown_Tiro_Player){
		switch(global.Tipo_Tiro){
			case 0:
				ModoTiroComum_Player();
			break;
			
			case 1:
				ModoTiroDuplo_Player();
			break;
			
			case 2:
				ModoTiroTriplo_Player();
			break;
		}

		Timer_Cooldown_Tiro_Player = 0;
	}
	
	//Tiro Comum do tiro.
	ModoTiroComum_Player = function(){
		Dano_Tiro_Player = 1;
		var _TiroComum_Player = instance_create_layer(x, y, "ins_Tiros_Player", obj_TiroComum_Player);
		
		_TiroComum_Player.hspeed = Vel_Tiro;
	}
	
	//Tiro Duplo do Player
	ModoTiroDuplo_Player = function(){
		Dano_Tiro_Player = 1;
		
		var _TiroTriplo1 = instance_create_layer(x + 50, y + 20, "ins_Tiros_Player", obj_TiroComum_Player);
		var _TiroTriplo2 = instance_create_layer(x + 50, y, "ins_Tiros_Player", obj_TiroComum_Player);
		
		_TiroTriplo1.hspeed = Vel_Tiro;
		_TiroTriplo2.hspeed = Vel_Tiro;
	}
	
		//Tiro Duplo do Player
	ModoTiroTriplo_Player = function(){
		Dano_Tiro_Player = 1;
		
		var _TiroTriplo1 = instance_create_layer(x + 50, y + 20, "ins_Tiros_Player", obj_TiroComum_Player);
		var _TiroTriplo2 = instance_create_layer(x + 50, y, "ins_Tiros_Player", obj_TiroComum_Player);
		var _TiroTriplo3 = instance_create_layer(x + 50, y - 20, "ins_Tiros_Player", obj_TiroComum_Player);
		
		_TiroTriplo1.hspeed = Vel_Tiro;
		_TiroTriplo2.hspeed = Vel_Tiro;
		_TiroTriplo3.hspeed = Vel_Tiro;
	}
	
}
#endregion	