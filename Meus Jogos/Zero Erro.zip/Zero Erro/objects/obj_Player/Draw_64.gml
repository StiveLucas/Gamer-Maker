/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


/* Aqui você vai definir
1.Qauntidade de vezes que vai repetir a sprite.
2.Nome da sprite.
3.Index da sprite.
4.O X da sprite.
5.O Y da sprite.
*/
Desenhando_Iconis(Vida_Player, spr_Player, 0, 70, 550);