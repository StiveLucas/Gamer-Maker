/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Verificar as informações
if(keyboard_check_pressed(vk_tab)){
	global.Debug_Jogo = !global.Debug_Jogo;
}

image_xscale = lerp(image_xscale, 1, 0.1);
image_yscale = lerp(image_yscale, 1, 0.1);

//Movimento do Player.
Config_Movimento_Player();

//Tiros do Player.
Config_Tiro_Player();