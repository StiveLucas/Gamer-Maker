/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor



AtivandoEfeito = function(){
	hspeed = 4;	
}