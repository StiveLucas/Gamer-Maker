/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

/*Sistema de Spaw dos inimigos.
Informe:
Posicao minima do x.
Posicao maxima do x.
Posicao minima do y.
Posicao maxima do y.
Quantidade de inimigos eliminadas necessarias.
obj
*/
Controle_Spaw_Inimigos(500, 1000, 100, 545, 20, obj_Inimigo2);

alarm[1] = 60 * irandom_range(global.TempMin_Spawn_Inimigo2, global.TempMax_Spawn_Inimigo2);
