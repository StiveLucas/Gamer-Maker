/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

/*Sistema de Spaw dos inimigos.
Informe:
Posicao minima do x.
Posicao maxima do x.
Posicao minima do y.
Posicao maxima do y.
Quantidade de inimigos eliminadas necessarias.
obj
*/
Controle_Spaw_Inimigos(650, 1000, 130, 480, 40, obj_Inimigo3);

alarm[2] = 60 * irandom_range(global.TempMin_Spawn_Inimigo3, global.TempMax_Spawn_Inimigo3);
