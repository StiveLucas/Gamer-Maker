/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Ativando font do jogo.
draw_set_font(fnt_Jogo);

//Ativando os dubugs do jogo.
if(global.Debug_Jogo){
	if(instance_exists(obj_Player)){
		draw_text(x + 10, y + 10, "Vida: "+string(obj_Player.Vida_Player));
	}else{
		draw_text(x + 10, y, "You Dead!");
	}
		draw_text(x + 10, y + 40, "Pontuação: " + string(global.Pontuacao_Atual));
		draw_text(x + 10, y + 90, "Inimigos Eliminados: " + string(global.Inimigos_Eliminados));
}

//Resetando a font.
draw_set_font(-1);