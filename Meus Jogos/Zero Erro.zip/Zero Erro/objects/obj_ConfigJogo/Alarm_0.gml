/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

/*Sistema de Spaw dos inimigos.
Informe:
Posicao minima do x.
Posicao maxima do x.
Posicao minima do y.
Posicao maxima do y.
Quantidade de inimigos eliminadas necessarias.
obj
*/
Controle_Spaw_Inimigos(450, 1000, 80, 545, 0, obj_Inimigo1);

alarm[0] = 60 * irandom_range(global.TempMin_Spawn_Inimigo1, global.TempMax_Spawn_Inimigo1);