/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Faz a pontuação do jogo crescer.
if(instance_exists(obj_Player)){
	global.Pontuacao_Atual++;
}