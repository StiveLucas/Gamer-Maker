/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Sistema de Spaw dos inimigos.
Controle_Spaw_Inimigos = function(_PosicaoMaxX, _PosicaoMinX, _PosicaoMinY, _PosicaoMaxY, _QtndEliminada_Inimigos, _Obj){
	
	if(global.Inimigos_Eliminados >= _QtndEliminada_Inimigos){
		//Escolhe de forma aleatória o Spawn.
		var _Local_Spawn = choose("Vertical", "Horizontal");
	
		if(_Local_Spawn == "Horizontal"){
			
			//Posição aleatória para o y
			var _PosicaoY = random_range(_PosicaoMinY, _PosicaoMaxY);
			
			//Criando o inimigo
			instance_create_layer(1380, _PosicaoY, "ins_Inimigos", _Obj);
		}else{
				
			//Posição aleatória para o y
			var _PosicaoX = random_range(_PosicaoMinX, _PosicaoMaxX);
			
			//Criando o inimigo
			instance_create_layer(_PosicaoX, 650, "ins_Inimigos", _Obj);
		}
	}
}

//Spawna Pow_up de Vida na parte superior.
alarm[11] = 60 * random_range(global.TempMin_Spawn_PowUp, global.TempMax_Spawn_PowUp);

//Inimigo 1
alarm[0] = 60 * 2;

//Inimigo 2
alarm[1] = 60 * 2;

//Inimigo 3
alarm[2] = 60 * 2;

//Inimigo 4
alarm[3] = 60 * 2;