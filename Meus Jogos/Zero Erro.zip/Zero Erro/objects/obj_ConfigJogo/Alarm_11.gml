/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

var _Posicao_X = random_range(250, 950);

var _Vida_Player = instance_create_layer(_Posicao_X, 50, "ins_Pow_Up", obj_Pow_Up);

_Vida_Player.image_index = 1;
_Vida_Player.vspeed = 2;

alarm[11] = 60 * random_range(global.TempMin_Spawn_PowUp, global.TempMax_Spawn_PowUp);