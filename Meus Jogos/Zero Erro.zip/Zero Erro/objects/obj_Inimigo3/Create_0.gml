/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Colocando imagem sprite na direção certa.
image_xscale = -1;

//Variáveis do Inimigo1
#region Variáveis do Inimigo1
Vida_Inimigo = 3;
Temp_Tiro_Inimigo = 3;

Vel_Inimigo = -2;
Vel_Tiro_Inimigo = -5;

Estado_Inimigo = "Se movendo para tela"
Tempo_MudarEstado_Inimigo = 60 * random(5);
Timer_MudarEstado_Inimigo = 0;

PosicaoX_Inimigo = irandom_range(400, 1070);
PosicaoY_Inimigo = irandom_range(90, 500);
Destino_X = false;
Destino_Y = false;

Direcao_MovimentoEscolhida_Inimigo = false;

#endregion

//Maquina de estado do Inimigo1
#region Maquina de estado do Inimigo1
Maquina_Estado_Inimigo = function(){
	
	switch(Estado_Inimigo){
		
		case "Se movendo para tela":
			if(x >= PosicaoX_Inimigo){
				hspeed = Vel_Inimigo;
			}else{
				Estado_Inimigo = "Em movimento";
			}
		break;
		
		case "Em movimento":
			hspeed = 0;
			
			var _Direcao_Movimento = choose("Cima", "Baixo");
			
			if(!Direcao_MovimentoEscolhida_Inimigo){
				if(_Direcao_Movimento == "Cima"){
					vspeed = Vel_Inimigo;
					Direcao_MovimentoEscolhida_Inimigo = true;
				}else{
					vspeed = +Vel_Inimigo;
					Direcao_MovimentoEscolhida_Inimigo = true;
				}
			}
		
			if(y >= 410){
				vspeed = Vel_Inimigo; 
			}
			
			if(y <= 60){
				vspeed = Vel_Inimigo * -1;
			}
			
			Timer_MudarEstado_Inimigo++;
			if(Timer_MudarEstado_Inimigo >= Tempo_MudarEstado_Inimigo){
				
				Timer_MudarEstado_Inimigo = 0;
			}
		break;
		
	}
	
}

#endregion

//Configuração do Inimigo
#region Configuração do Inimigo

//Configuração do Tiro do Inimigo1.

//Tiro do Inimigo.
alarm[0] = 60 * 2;

Config_Tiro_Inimigo = function(Sprite_Tiro){
	var _Direcao_Tiro = choose("Cima", "Baixo");
	
	if(_Direcao_Tiro == "Cima"){
		Tiro_Inimigo = instance_create_layer(x, y - 10, "ins_Tiros_Inimigos", obj_Tiro_Inimigo3);
		
		Tiro_Inimigo.vspeed = Vel_Tiro_Inimigo;
		
	}else{
		Tiro_Inimigo = instance_create_layer(x, y + 10, "ins_Tiros_Inimigos", obj_Tiro_Inimigo3);
		
		Tiro_Inimigo.vspeed = Vel_Tiro_Inimigo * -1;
	}
		
}

#endregion