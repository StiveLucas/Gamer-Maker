/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Escolhe de forma aleátoria a cor da sprite.
cor = choose(c_blue, c_red);

//Aumenta o tamnho da sprite no começo.
image_xscale = 4.2;
image_yscale = 4;