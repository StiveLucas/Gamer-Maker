/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//show_debug_message("Destroido");

//Efeito de colisão.
instance_create_layer(x, y, "ins_Efeitos", obj_ColisaoTiro_Player);