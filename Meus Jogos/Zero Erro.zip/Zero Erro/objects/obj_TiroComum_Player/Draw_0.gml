/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Desenhando a sprite.
draw_self();

//Ativa um brilho na sprite
gpu_set_blendmode(bm_add);

//Modifica sprite
draw_sprite_ext(sprite_index, image_index, x, y, image_xscale + 1, image_yscale + 1, image_angle, cor, image_alpha);

gpu_set_blendmode(bm_normal);