/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


//Se o Objeto sair pra fora do mapa ele se destroi.
if(x > 1200){
	instance_destroy();
}

//Traz o tamanho original aos poucos.
image_xscale = lerp(image_xscale, 1, 0.1);
image_yscale = image_xscale;