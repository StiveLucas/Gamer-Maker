/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Posicao_X = random_range(250, 950);

var _Vida_Player = instance_create_layer(PosicaoX_Inimigo, -50, "Pow_Up", obj_Pow_Up);

_Vida_Player.image_index = 1;
_Vida_Player.vspeed = 2;