 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


//Configurações do Pow-Up
Config_Queda_Pow_Up();