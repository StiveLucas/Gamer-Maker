 /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Sistema do Pow_Up.
Config_Pow_UP();