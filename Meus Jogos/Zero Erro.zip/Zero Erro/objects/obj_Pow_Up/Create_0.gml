  /// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis
image_speed = 0;
Vel_Queda = 2;

#endregion


#region Configurações do Pow-Up

Config_Queda_Pow_Up = function(){
	vspeed = Vel_Queda;
}

Config_Pow_UP = function(){
	
	//Pow_Up de aumentar o nivel do tiro
	if(image_index == 0){
		if(global.Tipo_Tiro <= 1){
			global.Tipo_Tiro++;
		}
	}
	
	with(obj_Player){
		Timer_Cooldown_PowUP = 0;
	}
		
	//Pow_Up de aumentar a vida do Player.
	if(image_index == 1){
		with(obj_Player){
			
			//Se a vida do player for menor que 3 ele aumenta a vida.
			if(Vida_Player < 3){
				Vida_Player++;
			}
		} 
	}
	
	instance_destroy();
}

#endregion