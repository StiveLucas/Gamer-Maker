/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Efeito some no final.
instance_destroy();