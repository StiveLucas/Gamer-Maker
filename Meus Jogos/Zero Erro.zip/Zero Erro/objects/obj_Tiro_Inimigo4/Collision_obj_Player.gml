/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Ativa o efeito Player.
with(obj_Player){
	InverterControle = true;
}