/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

if( x < -50){
	instance_destroy();
}

//Faz o Tiro crescer.
image_xscale = lerp(image_xscale, 2, 0.1);
image_yscale = image_xscale;