/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Tamanho da sprite.
image_xscale = 0.5;
image_yscale = image_xscale;