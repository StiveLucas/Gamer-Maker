/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

//Variáveis.
Efeito_Tremer = 0;