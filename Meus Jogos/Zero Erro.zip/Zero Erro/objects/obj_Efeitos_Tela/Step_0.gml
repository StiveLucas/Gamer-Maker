/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor


//Config para Tremer a tela.
if(Efeito_Tremer > 0){
	
	//Faz o efeito de tremer de forma aleatoria.
	var _x = random_range(-Efeito_Tremer, Efeito_Tremer);
	var _y = random_range(-Efeito_Tremer, Efeito_Tremer);
	
	view_set_xport(view_current, _x);
	view_set_yport(view_current, _y);
}else{
	
	//Coloca tudo de volta no lugar.
	Efeito_Tremer = 0;
	view_set_xport(view_current, 0);
	view_set_yport(view_current, 0);
}

//Faz o efeito parar aos poucos.
Efeito_Tremer = lerp(Efeito_Tremer, 0, 0.1);