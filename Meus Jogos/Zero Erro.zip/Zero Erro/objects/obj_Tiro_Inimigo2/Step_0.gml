/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

// Inherit the parent event
event_inherited();

Tamanho = lerp(Tamanho, 4, 0.01);

//Define o tamanho para seguir a variáel Tamanho.
image_xscale = Tamanho;
image_yscale = Tamanho;