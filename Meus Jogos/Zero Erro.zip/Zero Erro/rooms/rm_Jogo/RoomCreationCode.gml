//Informa que o jogo está em tramcisão.
global.Trancisao = true;

//Define o proximo destino
global.Destino = rm_Placar;