//Trancisão de tela
layer_sequence_create("ass_Trancisoes", room_width / 2, room_height / 2, sqc_Trancisao2);

//Desfine o proximo destino.
global.Destino = rm_Jogo;