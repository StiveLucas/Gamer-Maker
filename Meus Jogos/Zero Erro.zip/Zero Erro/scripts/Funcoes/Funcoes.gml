// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

function Sprite_Original(SpriteOriginal){
	if(image_index  >= image_number){
		sprite_index = SpriteOriginal;
	}
}

function EliminandoInimigo(){
	//Destroi Inimigo
	instance_destroy();
	
	//Efeito de explosão.
	instance_create_layer(x, y, "ins_Efeitos", obj_Efeito_Explosao);
	
	//Chance dropar um Pow-Up
	var Chance_Drop = 80;
	
	if(Chance_Drop < irandom(100)){
		instance_create_layer(x, y, "ins_Pow_Up", obj_Pow_Up);
	}
	
	global.Inimigos_Eliminados++;
}
	

#region Efeitor de Tremer a Tela.

//Executa o efeito.
function Executar_Efeito_Tremer(_Potencia_Tremer){
	if(instance_exists(obj_Efeitos_Tela)){
		with(obj_Efeitos_Tela){
			if(_Potencia_Tremer > Efeito_Tremer){
				Efeito_Tremer = _Potencia_Tremer;	
			}
		}
	}
}

#endregion

#region Trancisoes
	function MudarRoom_Inicio(){
		
		room_goto(global.Destino);
	
		global.Trancisao = true;
	}
	
	function MudarRoom_Final(){
	
		global.Trancisao = false;
	}

#endregion