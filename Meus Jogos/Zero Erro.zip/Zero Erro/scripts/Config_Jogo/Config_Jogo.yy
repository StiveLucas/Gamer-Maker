{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "Config_Jogo",
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
}