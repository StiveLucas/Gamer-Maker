// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Verifica se está em trancisão.
global.Trancisao = false;

//Jogo
global.Pontuacao_Atual = 0;
global.Pontuacao_Atual = 0;

global.Inimigos_Eliminados = 0;
global.MaxInimigos_Eliminados = 0;

//Pow-Up.
global.TempMin_Spawn_PowUp = 10;
global.TempMax_Spawn_PowUp = 20;

//Inimigos eliminados pelo Player.
global.Inimigos_Eliminados = 0;

//Inimigos 1.
global.TempMin_Spawn_Inimigo1 = 1;
global.TempMax_Spawn_Inimigo1 = 2;

//Inimigo 2.
global.TempMin_Spawn_Inimigo2 = 5;
global.TempMax_Spawn_Inimigo2 = 7;

//Inimigo 3.
global.TempMin_Spawn_Inimigo3 = 6;
global.TempMax_Spawn_Inimigo3 = 7;

//Inimigo 4.
global.TempMin_Spawn_Inimigo4 = 10;
global.TempMax_Spawn_Inimigo4 = 12;