// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

//Serve para ver infomações ocultas do jogo.
global.Debug_Jogo = false;

//Varável para definir o tiro do player.
global.Tipo_Tiro = 0;

//Destino
global.Destino = rm_Jogo;