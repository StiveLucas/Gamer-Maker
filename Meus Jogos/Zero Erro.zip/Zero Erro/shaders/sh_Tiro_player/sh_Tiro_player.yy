{
  "resourceType": "GMShader",
  "resourceVersion": "1.0",
  "name": "sh_Tiro_player",
  "type": 1,
  "parent": {
    "name": "Shaders",
    "path": "folders/Shaders.yy",
  },
}