if(!instance_exists(obj_Foguete)) instance_create_layer(1300, 2000, "ins_Foguete", obj_Foguete);

#region Variaveis.

#endregion

#region Metodos.

Gerando_PainelExibicao = function(){
    
    if (!instance_exists(obj_Painel_Exibicao)) instance_create_layer(2950, 1408, "ins_Painel_Exibicao", obj_Painel_Exibicao);
}

#endregion