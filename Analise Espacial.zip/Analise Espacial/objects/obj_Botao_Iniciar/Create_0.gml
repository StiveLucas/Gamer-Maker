
#region Variaveis.

EscalaX = 0;
EscalaY = 0;

Texto_Botao = 0;

Aumentar_Velocidade = false;
Diminuir_Velocidade = false;

Aumentar_Angulo = false;
Diminuir_Angulo = false;

#endregion

#region Metodos.

Exibir_Texto = function(){
    
    draw_set_font(fnt_Painel_Exibicao);
    draw_set_valign(fa_center);
    draw_set_halign(fa_center);
    
    draw_text(x, y, Texto_Botao);
    
    draw_set_font(-1);
    draw_set_valign(-1);
    draw_set_halign(-1);
}

Ativando_Botao = function(){
    
    var _MousePorCima_Botao = position_meeting(mouse_x, mouse_y, id);
    var _Clicou = mouse_check_button_released(mb_left);

    if (Iniciar_Jogo) {
        
        EscalaX = 4; 
       	EscalaY = 4; 
        
        Texto_Botao = "Lançar"
        
       if (_MousePorCima_Botao) {
       
           EscalaX = 7;    
           EscalaY = 5;    
           
           if (_Clicou) {
               
               EscalaX = 8;
               EscalaY = 8;
               
               with (obj_Foguete) {
               	Lancar_Foguete = true;
               }
               
               instance_destroy();
           }
       }else {
       	EscalaX = 6; 
       	EscalaY = 4; 
       }
        
        image_xscale = lerp(image_xscale, EscalaX, 0.1);
        image_yscale = lerp(image_yscale, EscalaY, 0.1);
    }
    
    if (Aumentar_Velocidade) {
    	
        EscalaX = 1.4;
        EscalaY = 1.4;
        
        Texto_Botao = "+";
        
        if (_MousePorCima_Botao) {
        	
            EscalaX = 2;
            EscalaY = 2;
            
            if (_Clicou) {
            	
                EscalaX = 2.8;
                EscalaY = 2.8;
                
                with (obj_Foguete) {
                	
                    Max_VelDefinida_Foguete++;
                }
            }
        }
        
        image_xscale = lerp(image_xscale, EscalaX, 0.1);
        image_yscale = lerp(image_yscale, EscalaY, 0.1);
    }
    
    if (Diminuir_Velocidade) {
    	
        EscalaX = 1.4;
        EscalaY = 1.4;
        
        Texto_Botao = "-";
        
        if (_MousePorCima_Botao) {
        	
            EscalaX = 2;
            EscalaY = 2;
            
            if (_Clicou) {
            	
                EscalaX = 2.6;
                EscalaY = 2.6;
                
                with (obj_Foguete) {
                	
                    if(Max_VelDefinida_Foguete >= 0) Max_VelDefinida_Foguete--;
                }
            }
        }
        
        image_xscale = lerp(image_xscale, EscalaX, 0.1);
        image_yscale = lerp(image_yscale, EscalaY, 0.1);
    }
    
    if (Aumentar_Angulo) {
    	
        EscalaX = 1.4;
        EscalaY = 1.4;
        
        Texto_Botao = "+";
        
        if (_MousePorCima_Botao) {
        	
            EscalaX = 2;
            EscalaY = 2;
            
            if (_Clicou) {
            	
                EscalaX = 2.6;
                EscalaY = 2.6;
                
                with (obj_Foguete) {
                	if(Angulo_Foguete < 355) Angulo_Foguete += 5;
                }
            }
        }
        
        image_xscale = lerp(image_xscale, EscalaX, 0.1);
        image_yscale = lerp(image_yscale, EscalaY, 0.1);
    }
    
    if (Diminuir_Angulo) {
    	
        EscalaX = 1.4;
        EscalaY = 1.4;
        
        Texto_Botao = "-";
        
        if (_MousePorCima_Botao) {
        	
            EscalaX = 2;
            EscalaY = 2;
            
            if (_Clicou) {
            	
                EscalaX = 2.6;
                EscalaY = 2.6;
                
                with (obj_Foguete) {
                	
                    if(Angulo_Foguete >= 0) Angulo_Foguete -= 5;
                }
            }
        }
        
        image_xscale = lerp(image_xscale, EscalaX, 0.1);
        image_yscale = lerp(image_yscale, EscalaY, 0.1);
    }
}
#endregion