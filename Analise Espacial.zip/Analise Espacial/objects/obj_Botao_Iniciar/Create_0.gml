
#region Variaveis.

EscalaX = 0;
EscalaY = 0;

#endregion

#region Metodos.

Exibir_Texto = function(){
    
    draw_set_font(fnt_Painel_Exibicao);
    draw_set_valign(fa_center);
    draw_set_halign(fa_center);
    
    draw_text(x, y, Texto_Botao);
    
    draw_set_font(-1);
    draw_set_valign(-1);
    draw_set_halign(-1);
}

Ativando_Botao = function(){
    
    var _Precionou_Botao = position_meeting(mouse_x, mouse_y, id);
    var _Clicou = mouse_check_button_released(mb_left);

    if (_Precionou_Botao) {
    
        EscalaX = 7;    
        EscalaY = 5;    
        
        if (_Clicou) {
            
            EscalaX = 8;
            EscalaY = 8;
            
            with (obj_Foguete) {
            	Lancar_Foguete = true;
            }
            
            instance_destroy();
        }
    }else {
    	EscalaX = 6; 
    	EscalaY = 4; 
    }
    
    image_xscale = lerp(image_xscale, EscalaX, 0.1);
    image_yscale = lerp(image_yscale, EscalaY, 0.1);
}
#endregion