draw_self();

Exibir_Texto();