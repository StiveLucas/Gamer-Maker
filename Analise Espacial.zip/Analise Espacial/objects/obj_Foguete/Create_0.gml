/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

#region Variáveis.

Max_VelH_Foguete = 8;
VelH_Foguete = 0;

Max_VelV_Foguete = 9;
VelV_Foguete = 0;

Angulo_Foguete = 90;

Gravidade = 0.1;
Contador_Velocidade = 0;

direction = 0;
#endregion

#region Métodos.

#region Inputs do Foguete.
Left = false;
Right = false;

Inputs_Foguete = function(){

   Left = keyboard_check(ord("A")) || keyboard_check(vk_left);
   Right = keyboard_check(ord("D")) || keyboard_check(vk_right);
}
#endregion

//Movimentação do Foguete.
Movimentacao_Foguete = function(){
    
    //Movimentação Horizontal.
    VelH_Foguete = (Right - Left) * Max_VelH_Foguete;
    
    if (VelH_Foguete != 0) {
        hspeed = VelH_Foguete;
    }else {
    	hspeed = 0;
    }
    
    //Movimentação Vertical.
    
    if(!instance_exists(obj_Lua)) return;
    
    var _Lua = obj_Lua;
    
    var _Direcao_Foguete = Angulo_Foguete;
    
    direction = 123;
    
    if(VelV_Foguete < Max_VelV_Foguete){
        
        VelV_Foguete = lerp(VelV_Foguete, -Max_VelV_Foguete, 0.01)
    }
    
    speed = -VelV_Foguete;
}

#endregion

Visualisando_Debugs = function(){
    
    if(!DEBUG_MODE) exit;
        
    show_debug_message("VEL_V: " + string(VelV_Foguete));
}

Ativando_Funcoes = function(){
    
    Inputs_Foguete();
    Movimentacao_Foguete();
    Visualisando_Debugs();
}