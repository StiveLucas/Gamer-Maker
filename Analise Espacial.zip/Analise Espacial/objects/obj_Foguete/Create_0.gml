/// @description Foguete

#region Variáveis

Max_Vel_Foguete = 10;
Vel_Foguete = 0;

Angulo_Foguete = 150;

VX_Fogute = 0;
VY_Fogute = 0;

EscalaX = 0.5;
EscalaY = 0.5;

Lancar_Foguete = false;
Foguete_Decolou = false;
Particula = false;

#endregion


#region Métodos

Config_Foguete = function(){
    if(room != rm_Mapa_Apresentacao) return;

    image_xscale = EscalaX;
    image_yscale = EscalaY;

    if(x < -sprite_width) x = room_width;
    if(x > room_width + sprite_width) x = -sprite_width;
    if(y < -sprite_height) y = 2850;
}


Movimentacao_Foguete = function(){
    if(room == rm_Mapa_Apresentacao) Lancar_Foguete = true;
    if(!Lancar_Foguete) return;

    if(!Particula){
        Ps = part_system_create(ps_SaidaFogo_Foguete);
        Particula = true;
    }

    if(!Foguete_Decolou) direction = 90;

    if(Vel_Foguete > -Max_Vel_Foguete) Vel_Foguete = lerp(Vel_Foguete, -Max_Vel_Foguete, 0.01);

    if(Vel_Foguete < -4){
        direction = lerp(direction, Angulo_Foguete, 0.004);
        Foguete_Decolou = true;
    }

    VX_Fogute = Vel_Foguete * dcos(Angulo_Foguete);
    VY_Fogute = Vel_Foguete * dsin(Angulo_Foguete);

    speed = -Vel_Foguete;
	image_angle = direction - 90;
}


Visualizar_Debugs = function(){
    show_debug_message("VX: " + string(VX_Fogute));
    show_debug_message("VY: " + string(VY_Fogute));
    show_debug_message("Direction: " + string(direction));
    show_debug_message("Velocidade: " + string(Vel_Foguete));
    show_debug_message("-------------------------------");
}

#endregion


Ativando_Funcoes = function(){
    Config_Foguete();
    Movimentacao_Foguete();
    Visualizar_Debugs();
}