draw_self();

var _TamanhoVetor = abs(Vel_Foguete) * 20;
var _TamanhoPonta = 22;
var _EscalaComponentes = 20;

var _FimX = x + lengthdir_x(_TamanhoVetor, direction);
var _FimY = y + lengthdir_y(_TamanhoVetor, direction);

var _DesenharSeta = function(_X1, _Y1, _X2, _Y2, _Direcao, _Tamanho){
    var _BaseX = _X2 + lengthdir_x(_Tamanho, _Direcao + 180);
    var _BaseY = _Y2 + lengthdir_y(_Tamanho, _Direcao + 180);
    var _Lado1X = _BaseX + lengthdir_x(_Tamanho * 0.55, _Direcao + 90);
    var _Lado1Y = _BaseY + lengthdir_y(_Tamanho * 0.55, _Direcao + 90);
    var _Lado2X = _BaseX + lengthdir_x(_Tamanho * 0.55, _Direcao - 90);
    var _Lado2Y = _BaseY + lengthdir_y(_Tamanho * 0.55, _Direcao - 90);

    draw_line_width(_X1, _Y1, _X2, _Y2, 4);
    draw_triangle(_X2, _Y2, _Lado1X, _Lado1Y, _Lado2X, _Lado2Y, false);
};


draw_set_font(fnt_Painel_Exibicao);

draw_set_color(c_red);
_DesenharSeta(x, y, _FimX, _FimY, direction, _TamanhoPonta);


var _VX = VX_Fogute * _EscalaComponentes;
var _VY = VY_Fogute * _EscalaComponentes;

var _VxFimX = x + _VX;
var _VxFimY = y;

var _VyFimX = _VxFimX;
var _VyFimY = y + _VY;

var _DirVx = (_VX >= 0) ? 0 : 180;
var _DirVy = (_VY >= 0) ? 90 : 270;


draw_set_color(c_aqua);
_DesenharSeta(x, y, _VxFimX, _VxFimY, _DirVx, _TamanhoPonta);


draw_set_color(c_yellow);
_DesenharSeta(_VxFimX, _VxFimY, _VyFimX, _VyFimY, _DirVy, _TamanhoPonta);


draw_set_halign(fa_left);
draw_set_valign(fa_middle);

draw_set_color(c_red);
draw_text(_FimX + 15, _FimY, "VL");

draw_set_color(c_aqua);
draw_text(_VxFimX + 15, _VxFimY, "Vx");

draw_set_color(c_yellow);
draw_text(_VyFimX + 15, _VyFimY, "Vy");


draw_set_font(-1);
draw_set_color(-1);
draw_set_halign(-1);
draw_set_valign(-1);