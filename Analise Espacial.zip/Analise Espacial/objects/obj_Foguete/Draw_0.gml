draw_self();

var _TamanhoVetor = abs(Vel_Foguete) * 20;
var _TamanhoPonta = 55;

var _FimX = x + lengthdir_x(_TamanhoVetor, direction);
var _FimY = y + lengthdir_y(_TamanhoVetor, direction);


draw_set_font(fnt_Painel_Exibicao);
draw_set_color(c_red);
draw_line_width(x, y, _FimX, _FimY, 3);

var _Ponta1X = _FimX + lengthdir_x(_TamanhoPonta, direction + 150);
var _Ponta1Y = _FimY + lengthdir_y(_TamanhoPonta, direction + 150);
var _Ponta2X = _FimX + lengthdir_x(_TamanhoPonta, direction - 150);
var _Ponta2Y = _FimY + lengthdir_y(_TamanhoPonta, direction - 150);

draw_line(_FimX, _FimY, _Ponta1X, _Ponta1Y);
draw_line(_FimX, _FimY, _Ponta2X, _Ponta2Y);

draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_middle);

draw_text(_FimX + 10, _FimY, "V₀ = " + string_format(abs(Vel_Foguete), 0, 2) + " m/s");

draw_set_color(c_aqua);
draw_text(x + 25, y - 35, "Vx = " + string_format(abs(VX_Fogute), 0, 2) + " m/s");

draw_set_color(c_yellow);
draw_text(x + 25, y + 35, "Vy = " + string_format(abs(VY_Fogute), 0, 2) + " m/s");

draw_set_font(-1);
draw_set_color(-1);
draw_set_halign(-1);
draw_set_valign(-1);