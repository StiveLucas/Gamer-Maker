//Destroi a particula.
part_system_destroy(Ps);