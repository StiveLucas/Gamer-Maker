Ativando_Funcoes();

if(Lancar_Foguete){
    var _DistanciaParticula = 120;

    var _XParticula = x + lengthdir_x(_DistanciaParticula, direction + 180);
    var _YParticula = y + lengthdir_y(_DistanciaParticula, direction + 180);

    part_system_position(Ps, _XParticula, _YParticula);
    part_system_angle(Ps, direction - 90);
}