/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Ativando_Funcoes();
show_debug_message("Direção: " + string(direction));