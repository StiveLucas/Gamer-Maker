/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor

Ativando_Funcoes();
if(Lancar_Foguete) {
    var _DistanciaParticula = 120;
    var _XParticula = x + lengthdir_x(_DistanciaParticula, direction + 90);
    var _YParticula = y + lengthdir_y(_DistanciaParticula, direction + 90);

    part_system_position(Ps, _XParticula, _YParticula);
}