#region Variaveis.

Escala_X = 4;
Escala_Y = 3;

image_xscale = 0;

#endregion

#region Métodos.

Config_Painel = function(){
    
    image_xscale = lerp(image_xscale, Escala_X, 0.04);
    image_yscale = Escala_Y;
}

ExibindoInfo_Painel = function(){
    draw_self();
    
    var _MargemX = 40;
    var _MargemY = 250;
    var _EspacamentoY = 70;
    
    var _Foguete = obj_Foguete;
    
    draw_set_font(fnt_Painel_Exibicao);
    draw_set_color(c_white);
    draw_set_valign(fa_center);
    draw_set_halign(fa_left);
    
    draw_text(
        x - (sprite_width - _MargemX),
        y - _MargemY,
        "Angulo: " + string(_Foguete.Angulo_Foguete) + "°"
    );
    
    draw_text(
        x - (sprite_width - _MargemX),
        y - (_MargemY - _EspacamentoY),
        "Velocidade: " + string_format(abs(_Foguete.Vel_Foguete), 0, 2) + " m/s"
    );
    
    _EspacamentoY *= 2;
    
    draw_text(
        x - (sprite_width - _MargemX),
        y - (_MargemY - _EspacamentoY),
        "Vetor X: " + string_format(abs(_Foguete.VX_Fogute), 0, 2) + " m/s"
    );
    
    _EspacamentoY += 70;
    
    draw_text(
        x - (sprite_width - _MargemX),
        y - (_MargemY - _EspacamentoY),
        "Vetor Y: " + string_format(abs(_Foguete.VY_Fogute), 0, 2) + " m/s"
    );
    
    draw_set_font(-1);
    draw_set_color(-1);
    draw_set_valign(-1);
    draw_set_halign(-1);
}
#endregion