#region Variaveis.

Escala_X = 5.5;
Escala_Y = 4.5;

Quantidade_Botoes_Painel = 0;

image_xscale = 0;

#endregion


#region Métodos.

Config_Painel = function(){
    
    image_xscale = lerp(image_xscale, Escala_X, 0.04);
    image_yscale = Escala_Y;
}


ExibindoInfo_Painel = function(){
    draw_self();
    
    var _MargemX = -50;
    var _MargemY = 350;
    var _EspacamentoY = 80;
    var _PosicaoX = x - (sprite_width - _MargemX - 100);
    
    var _Foguete = obj_Foguete;
    
    draw_set_font(fnt_Painel_Exibicao);
    draw_set_color(c_white);
    draw_set_valign(fa_center);
    draw_set_halign(fa_left);
    
    draw_text(_PosicaoX, y - _MargemY, "Angulo: " + string(_Foguete.Angulo_Foguete) + "°");
    
    draw_text(_PosicaoX, y - (_MargemY - _EspacamentoY), "Velocidade: " + string_format(abs(_Foguete.Vel_Foguete), 0, 2) + " m/s");
    
    _EspacamentoY *= 2;
    
    draw_text(_PosicaoX, y - (_MargemY - _EspacamentoY), "Vetor X: " + string_format(abs(_Foguete.VX_Fogute), 0, 2) + " m/s");
    
    _EspacamentoY += 70;
    
    draw_text(_PosicaoX, y - (_MargemY - _EspacamentoY), "Vetor Y: " + string_format(abs(_Foguete.VY_Fogute), 0, 2) + " m/s");
    
    draw_set_font(fnt_Painel_2);
    
    draw_text(2200, 1550, "Velocidade");
    draw_text(1970, 1550, "Angulo");
    
    draw_set_font(-1);
    draw_set_color(-1);
    draw_set_valign(-1);
    draw_set_halign(-1);
}


Invocando_Botoes_Configuracao = function(){

    if (Quantidade_Botoes_Painel < 4) {
        
        if (Quantidade_Botoes_Painel < 2) {
            
            var _X = 0;
            var _Y = 0;
            var _Botao = 0;
            
            if(Quantidade_Botoes_Painel == 0){
                _X = 2300;
                _Y = 1650;
                
                _Botao = instance_create_layer(_X, _Y, "ins_Botoes_Painel", obj_Botao_Iniciar);
                _Botao.Aumentar_Velocidade = true;   
            }
            
            if(Quantidade_Botoes_Painel == 1){ 
                _X = 2300;
                _Y = 1770;
                
                _Botao = instance_create_layer(_X, _Y, "ins_Botoes_Painel", obj_Botao_Iniciar);
                _Botao.Diminuir_Velocidade = true;   
            }
        }
        
        if (Quantidade_Botoes_Painel >= 2) {
            
            var _X = 0;
            var _Y = 0;
            var _Botao = 0;
            
            if (Quantidade_Botoes_Painel == 2) {
                
                _X = 2040;
                _Y = 1650;
                
                _Botao = instance_create_layer(_X, _Y, "ins_Botoes_Painel", obj_Botao_Iniciar);
                _Botao.Aumentar_Angulo = true; 
            }
            
            if (Quantidade_Botoes_Painel == 3) {
                
                _X = 2040;
                _Y = 1770;
                
                _Botao = instance_create_layer(_X, _Y, "ins_Botoes_Painel", obj_Botao_Iniciar);
                _Botao.Diminuir_Angulo = true; 
            }
        }
        
        Quantidade_Botoes_Painel++;
    }
}

#endregion