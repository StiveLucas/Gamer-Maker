
#region Variaveis

//Controles.
Gerar_Painel = false;


#endregion

#region Metodos.

Iniciando_Jogo = function(){
    
    if(!instance_exists(obj_Foguete)) return;
        
    var _Foguete = obj_Foguete;
    
    if (_Foguete.y < 0 - (sprite_height + 500)){
        room_goto(rm_Mapa_Apresentacao);
    }
}

#endregion