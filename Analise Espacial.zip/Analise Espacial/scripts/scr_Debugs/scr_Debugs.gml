// Os recursos de script mudaram para a v2.3.0; veja
// https://help.yoyogames.com/hc/en-us/articles/360005277377 para obter mais informações

#macro DEBUG_MODE false

#macro DEBUG:DEBUG_MODE true
#macro JOGO_NORMAL:DEBUG_MODE false 